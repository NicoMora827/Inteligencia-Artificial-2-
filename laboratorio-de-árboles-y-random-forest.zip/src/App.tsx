import React, { useState, useMemo } from 'react';
import { AppMode, Header } from './components/Header';
import { HyperparameterControls } from './components/HyperparameterControls';
import { DecisionBoundaryCanvas } from './components/DecisionBoundaryCanvas';
import { RegressionPlotCanvas } from './components/RegressionPlotCanvas';
import { TreeDiagramSvg } from './components/TreeDiagramSvg';
import { MetricsPanel } from './components/MetricsPanel';
import { EnsembleInspector } from './components/EnsembleInspector';
import { PedagogicalGuideView } from './components/PedagogicalGuideView';
import {
  generateHeartDiseaseDataset,
  generateCreditApprovalDataset,
  generateHousePricesDataset,
  generateEnergyConsumptionDataset,
  generateFraudDetectionDataset,
} from './ml/datasetGenerator';
import {
  DecisionTree,
  evaluateClassification,
  evaluateRegression,
} from './ml/decisionTree';
import {
  RandomForest,
  evaluateRandomForestClassification,
  evaluateRandomForestRegression,
} from './ml/randomForest';
import { diagnoseModelFit } from './ml/hyperparameterImpact';
import { Hyperparameters, TaskType, DataPoint } from './types/ml';

const DEFAULT_PARAMS: Hyperparameters = {
  maxDepth: 4,
  minSamplesSplit: 6,
  minSamplesLeaf: 4,
  criterion: 'gini',
  nEstimators: 20,
  bootstrap: true,
  maxFeatures: 'sqrt',
};

export default function App() {
  const [currentMode, setCurrentMode] = useState<AppMode>('classification_tree');
  const [selectedDatasetId, setSelectedDatasetId] = useState<string>('heart');
  const [params, setParams] = useState<Hyperparameters>(DEFAULT_PARAMS);
  const [selectedProbe, setSelectedProbe] = useState<{ x1: number; x2: number } | null>(null);
  const [selectedRfTreeIndex, setSelectedRfTreeIndex] = useState<number>(-1); // -1 = consensus

  // Pre-generate practical datasets
  const datasets = useMemo(() => {
    return {
      heart: generateHeartDiseaseDataset(42),
      credit: generateCreditApprovalDataset(101),
      housing: generateHousePricesDataset(77),
      energy: generateEnergyConsumptionDataset(88),
      fraud: generateFraudDetectionDataset(123),
    };
  }, []);

  // Available datasets per mode
  const datasetOptions = useMemo(() => {
    if (currentMode === 'classification_tree') {
      return [
        { id: 'heart', name: datasets.heart.name, taskType: 'classification' as TaskType },
        { id: 'credit', name: datasets.credit.name, taskType: 'classification' as TaskType },
      ];
    } else if (currentMode === 'regression_tree') {
      return [
        { id: 'housing', name: datasets.housing.name, taskType: 'regression' as TaskType },
        { id: 'energy', name: datasets.energy.name, taskType: 'regression' as TaskType },
      ];
    } else {
      // Random Forest: supports fraud, heart, and housing
      return [
        { id: 'fraud', name: datasets.fraud.name, taskType: 'classification' as TaskType },
        { id: 'heart', name: datasets.heart.name, taskType: 'classification' as TaskType },
        { id: 'housing', name: datasets.housing.name, taskType: 'regression' as TaskType },
      ];
    }
  }, [currentMode, datasets]);

  // Current active dataset
  const activeDataset = useMemo(() => {
    return datasets[selectedDatasetId as keyof typeof datasets] || datasets.heart;
  }, [selectedDatasetId, datasets]);

  const taskType = activeDataset.taskType;
  const isRandomForest = currentMode === 'random_forest';

  // Handle switching tabs
  const handleSelectMode = (mode: AppMode) => {
    setCurrentMode(mode);
    setSelectedProbe(null);
    setSelectedRfTreeIndex(-1);

    // Auto switch dataset if current dataset is incompatible with new mode
    if (mode === 'classification_tree' && taskType !== 'classification') {
      setSelectedDatasetId('heart');
      setParams(prev => ({ ...prev, criterion: 'gini' }));
    } else if (mode === 'regression_tree' && taskType !== 'regression') {
      setSelectedDatasetId('housing');
      setParams(prev => ({ ...prev, criterion: 'mse' }));
    } else if (mode === 'random_forest') {
      if (selectedDatasetId !== 'fraud' && selectedDatasetId !== 'heart' && selectedDatasetId !== 'housing') {
        setSelectedDatasetId('fraud');
      }
    }
  };

  const handleSelectDataset = (id: string) => {
    setSelectedDatasetId(id);
    setSelectedProbe(null);
    setSelectedRfTreeIndex(-1);
    const newDs = datasets[id as keyof typeof datasets];
    if (newDs) {
      setParams(prev => ({
        ...prev,
        criterion: newDs.taskType === 'classification' ? 'gini' : 'mse',
      }));
    }
  };

  const handleResetParams = () => {
    setParams({
      ...DEFAULT_PARAMS,
      criterion: taskType === 'classification' ? 'gini' : 'mse',
    });
    setSelectedProbe(null);
    setSelectedRfTreeIndex(-1);
  };

  // Train Decision Tree
  const singleTree = useMemo(() => {
    const tree = new DecisionTree(taskType, params);
    tree.fit(activeDataset.trainData);
    return tree;
  }, [taskType, params, activeDataset.trainData]);

  // Train Random Forest
  const randomForest = useMemo(() => {
    if (!isRandomForest) return null;
    const rf = new RandomForest(taskType, params);
    rf.fit(activeDataset.trainData);
    return rf;
  }, [isRandomForest, taskType, params, activeDataset.trainData]);

  // Active prediction function for Canvas
  const activePredictFn = useMemo(() => {
    if (isRandomForest && randomForest) {
      if (selectedRfTreeIndex >= 0 && randomForest.trees[selectedRfTreeIndex]) {
        return (x1: number, x2: number) =>
          randomForest.trees[selectedRfTreeIndex].predictPoint(x1, x2);
      }
      return (x1: number, x2: number) => randomForest.predictPoint(x1, x2);
    }
    return (x1: number, x2: number) => singleTree.predictPoint(x1, x2);
  }, [isRandomForest, randomForest, singleTree, selectedRfTreeIndex]);

  // Probability function for smooth classification contours
  const activePredictProbFn = useMemo(() => {
    if (taskType !== 'classification') return undefined;
    if (isRandomForest && randomForest && selectedRfTreeIndex === -1) {
      return (x1: number, x2: number) => randomForest.predictProbabilities(x1, x2);
    }
    return undefined;
  }, [taskType, isRandomForest, randomForest, selectedRfTreeIndex]);

  // Active tree for SVG structure diagram
  const activeDisplayTree = useMemo(() => {
    if (isRandomForest && randomForest) {
      if (selectedRfTreeIndex >= 0 && randomForest.trees[selectedRfTreeIndex]) {
        return randomForest.trees[selectedRfTreeIndex];
      }
      // In consensus mode, show Tree #1 as representative example
      return randomForest.trees[0] || singleTree;
    }
    return singleTree;
  }, [isRandomForest, randomForest, selectedRfTreeIndex, singleTree]);

  // Prediction probe trace
  const activePredictionTrace = useMemo(() => {
    if (!selectedProbe || !activeDisplayTree) return [];
    const featureNames: [string, string] = [activeDataset.x1Name, activeDataset.x2Name];
    const trace = activeDisplayTree.predictPointWithTrace(
      selectedProbe.x1,
      selectedProbe.x2,
      featureNames
    );
    return trace.path;
  }, [selectedProbe, activeDisplayTree, activeDataset]);

  // Compute Evaluation Metrics
  const { classificationMetrics, regressionMetrics, trainScore, testScore } = useMemo(() => {
    if (taskType === 'classification') {
      const metrics =
        isRandomForest && randomForest
          ? evaluateRandomForestClassification(
              randomForest,
              activeDataset.trainData,
              activeDataset.testData
            )
          : evaluateClassification(singleTree, activeDataset.trainData, activeDataset.testData);
      return {
        classificationMetrics: metrics,
        regressionMetrics: undefined,
        trainScore: metrics.trainAccuracy,
        testScore: metrics.testAccuracy,
      };
    } else {
      const metrics =
        isRandomForest && randomForest
          ? evaluateRandomForestRegression(
              randomForest,
              activeDataset.trainData,
              activeDataset.testData
            )
          : evaluateRegression(singleTree, activeDataset.trainData, activeDataset.testData);
      return {
        classificationMetrics: undefined,
        regressionMetrics: metrics,
        trainScore: metrics.trainR2,
        testScore: metrics.testR2,
      };
    }
  }, [taskType, isRandomForest, randomForest, singleTree, activeDataset]);

  // Model Fit Diagnostics
  const diagnostics = useMemo(() => {
    return diagnoseModelFit(taskType, trainScore, testScore, params);
  }, [taskType, trainScore, testScore, params]);

  const treeStats = useMemo(() => {
    return activeDisplayTree.getTreeStats();
  }, [activeDisplayTree]);

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-800 font-sans flex flex-col selection:bg-indigo-500 selection:text-white">
      {/* Top Navigation & Mode Selector */}
      <Header
        currentMode={currentMode}
        onSelectMode={handleSelectMode}
        datasets={datasetOptions}
        selectedDatasetId={selectedDatasetId}
        onSelectDataset={handleSelectDataset}
        onResetParams={handleResetParams}
      />

      {/* Main Workspace Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6">
        {currentMode === 'pedagogical_guide' ? (
          <PedagogicalGuideView />
        ) : (
          <div className="space-y-6">
            {/* Practical Scenario Briefing */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4 flex flex-col md:flex-row md:items-center justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2.5 py-0.5 rounded-full border border-indigo-100">
                    Caso Práctico en Análisis
                  </span>
                  <h2 className="text-base font-bold text-slate-900">{activeDataset.name}</h2>
                </div>
                <p className="text-xs text-slate-600 mt-1 max-w-4xl leading-relaxed">
                  {activeDataset.description}
                </p>
              </div>

              <div className="flex items-center gap-2 self-start md:self-auto text-xs font-medium text-slate-500 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
                <span>Train: {activeDataset.trainData.length} muestras</span>
                <span>•</span>
                <span>Test: {activeDataset.testData.length} muestras</span>
              </div>
            </div>

            {/* Split Grid: Controls & Diagnostics on Left, Visualizations on Right */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              {/* Left Column: Sliders & Diagnostics (5 cols) */}
              <div className="lg:col-span-5 space-y-6">
                <HyperparameterControls
                  params={params}
                  onChange={setParams}
                  taskType={taskType}
                  isRandomForest={isRandomForest}
                />

                <MetricsPanel
                  taskType={taskType}
                  classificationMetrics={classificationMetrics}
                  regressionMetrics={regressionMetrics}
                  diagnostics={diagnostics}
                  treeStats={treeStats}
                />
              </div>

              {/* Right Column: Visualizations & Tree Structure (7 cols) */}
              <div className="lg:col-span-7 space-y-6">
                {/* 1. Decision Boundary or Regression Step Plot */}
                {taskType === 'classification' ? (
                  <DecisionBoundaryCanvas
                    dataset={activeDataset}
                    predictFn={activePredictFn}
                    predictProbFn={activePredictProbFn}
                    selectedProbe={selectedProbe}
                    onSelectProbe={setSelectedProbe}
                    showTestData={true}
                  />
                ) : (
                  <RegressionPlotCanvas
                    dataset={activeDataset}
                    predictFn={activePredictFn}
                    selectedProbe={selectedProbe}
                    onSelectProbe={setSelectedProbe}
                    showTestData={true}
                  />
                )}

                {/* 2. If Random Forest: Ensemble Inspector */}
                {isRandomForest && randomForest && (
                  <EnsembleInspector
                    nEstimators={params.nEstimators}
                    bootstrap={params.bootstrap}
                    oobScore={randomForest.oobScore}
                    featureImportances={randomForest.featureImportances}
                    featureNames={[activeDataset.x1Name, activeDataset.x2Name]}
                    selectedTreeIndex={selectedRfTreeIndex}
                    onSelectTreeIndex={setSelectedRfTreeIndex}
                    treeSummaries={randomForest.getTreeSummaries()}
                  />
                )}

                {/* 3. SVG Hierarchical Tree Diagram with Trace Route */}
                <TreeDiagramSvg
                  root={activeDisplayTree.root}
                  featureNames={[activeDataset.x1Name, activeDataset.x2Name]}
                  taskType={taskType}
                  classLabels={activeDataset.classLabels}
                  yUnit={activeDataset.yUnit}
                  activePath={activePredictionTrace}
                />
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Subtle Pedagogical Footer */}
      <footer className="bg-white border-t border-slate-200 py-4 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>
            Laboratorio Pedagógico de Machine Learning: Árboles de Decisión, Regresión y Random Forest.
          </span>
          <span className="text-slate-400">
            Experimenta con sobreajuste y subajuste variando <code className="text-indigo-600">max_depth</code> y <code className="text-indigo-600">min_samples_leaf</code>.
          </span>
        </div>
      </footer>
    </div>
  );
}
