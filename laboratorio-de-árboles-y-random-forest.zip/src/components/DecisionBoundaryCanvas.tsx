import React, { useRef, useEffect, useState, useCallback } from 'react';
import { Crosshair, Eye, Info } from 'lucide-react';
import { Dataset, DataPoint } from '../types/ml';

interface DecisionBoundaryCanvasProps {
  dataset: Dataset;
  predictFn: (x1: number, x2: number) => number;
  predictProbFn?: (x1: number, x2: number) => [number, number];
  selectedProbe: { x1: number; x2: number } | null;
  onSelectProbe: (probe: { x1: number; x2: number } | null) => void;
  showTestData?: boolean;
}

export const DecisionBoundaryCanvas: React.FC<DecisionBoundaryCanvasProps> = ({
  dataset,
  predictFn,
  predictProbFn,
  selectedProbe,
  onSelectProbe,
  showTestData = true,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [hoveredPoint, setHoveredPoint] = useState<DataPoint | null>(null);
  const [hoverCoord, setHoverCoord] = useState<{ x1: number; x2: number } | null>(null);

  // Compute dataset bounding ranges
  const allPoints = [...dataset.trainData, ...dataset.testData];
  const minX1 = Math.min(...allPoints.map(p => p.x1));
  const maxX1 = Math.max(...allPoints.map(p => p.x1));
  const minX2 = Math.min(...allPoints.map(p => p.x2));
  const maxX2 = Math.max(...allPoints.map(p => p.x2));

  // Add 5% padding
  const padX1 = (maxX1 - minX1) * 0.06;
  const padX2 = (maxX2 - minX2) * 0.06;
  const rangeX1: [number, number] = [minX1 - padX1, maxX1 + padX1];
  const rangeX2: [number, number] = [minX2 - padX2, maxX2 + padX2];

  const toCanvasCoords = useCallback(
    (x1: number, x2: number, width: number, height: number) => {
      const padding = 36;
      const plotW = width - padding * 2;
      const plotH = height - padding * 2;

      const px = padding + ((x1 - rangeX1[0]) / (rangeX1[1] - rangeX1[0])) * plotW;
      const py = height - padding - ((x2 - rangeX2[0]) / (rangeX2[1] - rangeX2[0])) * plotH;
      return { px, py };
    },
    [rangeX1, rangeX2]
  );

  const fromCanvasCoords = useCallback(
    (px: number, py: number, width: number, height: number) => {
      const padding = 36;
      const plotW = width - padding * 2;
      const plotH = height - padding * 2;

      const x1 = rangeX1[0] + ((px - padding) / plotW) * (rangeX1[1] - rangeX1[0]);
      const x2 = rangeX2[0] + ((height - padding - py) / plotH) * (rangeX2[1] - rangeX2[0]);
      return { x1, x2 };
    },
    [rangeX1, rangeX2]
  );

  // Render canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    const padding = 36;

    // Clear background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, width, height);

    // 1. Draw Decision Boundary Regions using fine grid mesh
    const gridRes = 55;
    const cellW = (width - padding * 2) / gridRes;
    const cellH = (height - padding * 2) / gridRes;

    for (let gx = 0; gx < gridRes; gx++) {
      for (let gy = 0; gy < gridRes; gy++) {
        const px = padding + gx * cellW + cellW / 2;
        const py = padding + gy * cellH + cellH / 2;
        const coords = fromCanvasCoords(px, py, width, height);

        let pred = predictFn(coords.x1, coords.x2);
        let prob1 = pred;
        if (predictProbFn) {
          const probs = predictProbFn(coords.x1, coords.x2);
          prob1 = probs[1];
        }

        // Color interpolation for smooth decision landscape
        if (predictProbFn) {
          // Soft blue (class 0) to soft amber/rose (class 1)
          // 0 -> rgb(238, 242, 255) to 1 -> rgb(254, 243, 199)
          const r = Math.round(238 + (254 - 238) * prob1);
          const g = Math.round(242 + (230 - 242) * prob1);
          const b = Math.round(255 + (200 - 255) * prob1);
          ctx.fillStyle = `rgb(${r}, ${g}, ${b})`;
        } else {
          ctx.fillStyle = pred === 1 ? '#fef3c7' : '#e0e7ff';
        }

        ctx.fillRect(padding + gx * cellW, padding + gy * cellH, cellW + 0.5, cellH + 0.5);
      }
    }

    // 2. Draw Grid & Axes
    ctx.strokeStyle = '#cbd5e1';
    ctx.lineWidth = 1;
    ctx.strokeRect(padding, padding, width - padding * 2, height - padding * 2);

    // X-ticks
    ctx.fillStyle = '#64748b';
    ctx.font = '10px Inter, system-ui, sans-serif';
    ctx.textAlign = 'center';
    const xTicks = 5;
    for (let i = 0; i <= xTicks; i++) {
      const val = rangeX1[0] + (i / xTicks) * (rangeX1[1] - rangeX1[0]);
      const { px } = toCanvasCoords(val, rangeX2[0], width, height);
      ctx.fillText(val.toFixed(0), px, height - padding + 15);
      ctx.beginPath();
      ctx.moveTo(px, height - padding);
      ctx.lineTo(px, height - padding + 4);
      ctx.stroke();
    }

    // Y-ticks
    ctx.textAlign = 'right';
    const yTicks = 5;
    for (let i = 0; i <= yTicks; i++) {
      const val = rangeX2[0] + (i / yTicks) * (rangeX2[1] - rangeX2[0]);
      const { py } = toCanvasCoords(rangeX1[0], val, width, height);
      ctx.fillText(val.toFixed(0), padding - 6, py + 3);
      ctx.beginPath();
      ctx.moveTo(padding - 4, py);
      ctx.lineTo(padding, py);
      ctx.stroke();
    }

    // Axis Labels
    ctx.fillStyle = '#334155';
    ctx.font = 'bold 11px Inter, system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(
      `${dataset.x1Name} ${dataset.x1Unit ? `(${dataset.x1Unit})` : ''}`,
      width / 2,
      height - 6
    );

    ctx.save();
    ctx.translate(12, height / 2);
    ctx.rotate(-Math.PI / 2);
    ctx.fillText(
      `${dataset.x2Name} ${dataset.x2Unit ? `(${dataset.x2Unit})` : ''}`,
      0,
      0
    );
    ctx.restore();

    // 3. Draw Training Points (Circles)
    dataset.trainData.forEach(p => {
      const { px, py } = toCanvasCoords(p.x1, p.x2, width, height);
      ctx.beginPath();
      ctx.arc(px, py, 4.5, 0, Math.PI * 2);

      if (p.y === 1) {
        ctx.fillStyle = '#d97706'; // Amber-600
        ctx.strokeStyle = '#78350f';
      } else {
        ctx.fillStyle = '#4f46e5'; // Indigo-600
        ctx.strokeStyle = '#1e1b4b';
      }
      ctx.lineWidth = 1.2;
      ctx.fill();
      ctx.stroke();
    });

    // 4. Draw Test Points (Diamonds) if enabled
    if (showTestData) {
      dataset.testData.forEach(p => {
        const { px, py } = toCanvasCoords(p.x1, p.x2, width, height);
        ctx.beginPath();
        // Diamond path
        const s = 4.5;
        ctx.moveTo(px, py - s);
        ctx.lineTo(px + s, py);
        ctx.lineTo(px, py + s);
        ctx.lineTo(px - s, py);
        ctx.closePath();

        if (p.y === 1) {
          ctx.fillStyle = '#f59e0b';
          ctx.strokeStyle = '#451a03';
        } else {
          ctx.fillStyle = '#818cf8';
          ctx.strokeStyle = '#0f172a';
        }
        ctx.lineWidth = 1.8;
        ctx.fill();
        ctx.stroke();
      });
    }

    // 5. Draw Selected Probe (Test Marker)
    if (selectedProbe) {
      const { px, py } = toCanvasCoords(selectedProbe.x1, selectedProbe.x2, width, height);

      // Target reticle
      ctx.strokeStyle = '#0f172a';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(px, py, 9, 0, Math.PI * 2);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(px - 14, py);
      ctx.lineTo(px + 14, py);
      ctx.moveTo(px, py - 14);
      ctx.lineTo(px, py + 14);
      ctx.stroke();

      ctx.fillStyle = '#ef4444';
      ctx.beginPath();
      ctx.arc(px, py, 3.5, 0, Math.PI * 2);
      ctx.fill();
    }
  }, [dataset, predictFn, predictProbFn, selectedProbe, showTestData, toCanvasCoords, fromCanvasCoords, rangeX1, rangeX2]);

  // Handle canvas click to place inspection probe
  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const px = ((e.clientX - rect.left) / rect.width) * canvas.width;
    const py = ((e.clientY - rect.top) / rect.height) * canvas.height;

    const coords = fromCanvasCoords(px, py, canvas.width, canvas.height);
    // Clamp to bounds
    const clampedX1 = Math.max(rangeX1[0], Math.min(rangeX1[1], coords.x1));
    const clampedX2 = Math.max(rangeX2[0], Math.min(rangeX2[1], coords.x2));

    onSelectProbe({
      x1: parseFloat(clampedX1.toFixed(1)),
      x2: parseFloat(clampedX2.toFixed(1)),
    });
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const px = ((e.clientX - rect.left) / rect.width) * canvas.width;
    const py = ((e.clientY - rect.top) / rect.height) * canvas.height;

    const coords = fromCanvasCoords(px, py, canvas.width, canvas.height);
    setHoverCoord(coords);

    // Check if hovering near a dataset point
    const threshold = 10; // pixels
    const all = [...dataset.trainData, ...(showTestData ? dataset.testData : [])];
    const found = all.find(p => {
      const pt = toCanvasCoords(p.x1, p.x2, canvas.width, canvas.height);
      const dist = Math.hypot(pt.px - px, pt.py - py);
      return dist <= threshold;
    });

    setHoveredPoint(found || null);
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4 space-y-3">
      {/* Title & Canvas Tooling */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-blue-50 text-blue-600">
            <Eye className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-800">
              Frontera de Decisión 2D (Decision Boundary)
            </h3>
            <p className="text-xs text-slate-500">
              Haz clic en cualquier punto para trazar el camino de decisión en el árbol
            </p>
          </div>
        </div>

        {/* Coords & probe status */}
        <div className="flex items-center gap-2 text-xs">
          {selectedProbe ? (
            <span className="inline-flex items-center gap-1 px-2 py-1 rounded bg-slate-100 text-slate-700 font-mono text-[11px] border border-slate-200">
              <Crosshair className="w-3 h-3 text-red-500" />
              Prueba: ({selectedProbe.x1}, {selectedProbe.x2})
            </span>
          ) : (
            <span className="text-slate-400 text-[11px] italic">
              Haz clic para probar un punto
            </span>
          )}
        </div>
      </div>

      {/* Canvas Frame */}
      <div className="relative border border-slate-200 rounded-lg overflow-hidden bg-slate-50 flex items-center justify-center">
        <canvas
          id="decision-boundary-canvas"
          ref={canvasRef}
          width={520}
          height={380}
          onClick={handleCanvasClick}
          onMouseMove={handleMouseMove}
          onMouseLeave={() => {
            setHoveredPoint(null);
            setHoverCoord(null);
          }}
          className="w-full max-w-[520px] aspect-[520/380] cursor-crosshair block"
        />

        {/* Hover Point Tooltip */}
        {hoveredPoint && (
          <div className="absolute top-2 right-2 bg-slate-900/90 text-white text-[11px] px-2.5 py-1.5 rounded-lg shadow-lg backdrop-blur-sm pointer-events-none border border-slate-700">
            <div className="font-semibold text-indigo-300">
              {hoveredPoint.isTest ? 'Punto de Prueba (Test)' : 'Punto de Entrenamiento (Train)'}
            </div>
            <div>
              {dataset.x1Name}: <span className="font-mono">{hoveredPoint.x1}</span>
            </div>
            <div>
              {dataset.x2Name}: <span className="font-mono">{hoveredPoint.x2}</span>
            </div>
            <div>
              Clase Real:{' '}
              <span className="font-bold font-mono">
                {dataset.classLabels ? dataset.classLabels[hoveredPoint.y] : hoveredPoint.y}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Legend & Interactive Hints */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-1 text-xs text-slate-600 border-t border-slate-100">
        <div className="flex items-center gap-4 flex-wrap">
          {/* Class 0 */}
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-indigo-600 border border-slate-800" />
            <span className="text-[11px]">
              {dataset.classLabels ? dataset.classLabels[0] : 'Clase 0'} (Azul)
            </span>
          </div>

          {/* Class 1 */}
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-amber-600 border border-slate-800" />
            <span className="text-[11px]">
              {dataset.classLabels ? dataset.classLabels[1] : 'Clase 1'} (Ámbar)
            </span>
          </div>

          {/* Train vs Test Shape */}
          <div className="flex items-center gap-1.5 text-slate-500 text-[11px]">
            <span className="w-2.5 h-2.5 rounded-full bg-slate-400 inline-block" /> Círculo = Train
          </div>
          <div className="flex items-center gap-1.5 text-slate-500 text-[11px]">
            <span className="w-2.5 h-2.5 rotate-45 bg-slate-400 inline-block" /> Rombo = Test
          </div>
        </div>

        <div className="flex items-center gap-1 text-[11px] text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded">
          <Info className="w-3 h-3" />
          <span>Frontera rectangular ortogonal típica de árboles</span>
        </div>
      </div>
    </div>
  );
};
