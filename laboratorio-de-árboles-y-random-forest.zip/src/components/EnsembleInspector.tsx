import React from 'react';
import { Trees, BarChart2, CheckCircle, GitFork, HelpCircle, Sparkles } from 'lucide-react';
import { EnsembleTreeSummary } from '../types/ml';

interface EnsembleInspectorProps {
  nEstimators: number;
  bootstrap: boolean;
  oobScore: number;
  featureImportances: [number, number];
  featureNames: [string, string];
  selectedTreeIndex: number; // -1 for consensus forest, 0..N-1 for individual tree
  onSelectTreeIndex: (index: number) => void;
  treeSummaries: EnsembleTreeSummary[];
}

export const EnsembleInspector: React.FC<EnsembleInspectorProps> = ({
  nEstimators,
  bootstrap,
  oobScore,
  featureImportances,
  featureNames,
  selectedTreeIndex,
  onSelectTreeIndex,
  treeSummaries,
}) => {
  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5 space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-teal-50 text-teal-600">
            <Trees className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-800">
              Veedor de Ensamble y Reducción de Varianza
            </h3>
            <p className="text-xs text-slate-500">
              Compara el consenso del bosque contra árboles individuales aislados
            </p>
          </div>
        </div>

        {/* Tree Selector Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full">
          <button
            id="rf-select-consensus-btn"
            onClick={() => onSelectTreeIndex(-1)}
            className={`px-3 py-1 rounded-md text-xs font-semibold whitespace-nowrap transition-all ${
              selectedTreeIndex === -1
                ? 'bg-teal-600 text-white shadow-sm'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            Consenso del Bosque ({nEstimators} árboles)
          </button>

          {treeSummaries.slice(0, 6).map((summary, idx) => (
            <button
              key={summary.id}
              onClick={() => onSelectTreeIndex(idx)}
              className={`px-2.5 py-1 rounded-md text-xs font-medium whitespace-nowrap transition-all ${
                selectedTreeIndex === idx
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              Árbol #{summary.id}
            </button>
          ))}
          {treeSummaries.length > 6 && (
            <span className="text-[11px] text-slate-400">+{treeSummaries.length - 6} más</span>
          )}
        </div>
      </div>

      {/* Comparison Insight Box */}
      <div className="p-3.5 rounded-xl bg-teal-50/70 border border-teal-200 text-xs text-teal-950 space-y-1.5">
        <div className="font-bold flex items-center gap-1.5 text-teal-900">
          <Sparkles className="w-3.5 h-3.5 text-teal-600" />
          <span>Lección Pedagógica Clave de Random Forest:</span>
        </div>
        <p className="text-slate-700 leading-relaxed">
          {selectedTreeIndex === -1 ? (
            <>
              <strong>Consenso Activo:</strong> Al promediar las decisiones de los{' '}
              <span className="font-semibold text-teal-800">{nEstimators} árboles</span>, los
              errores aleatorios individuales se cancelan entre sí. La frontera de decisión se
              vuelve mucho más suave, regular y resistente al ruido, superando a cualquier árbol por
              separado.
            </>
          ) : (
            <>
              <strong>Inspeccionando Árbol #{selectedTreeIndex + 1}:</strong> Observa cómo este
              árbol individual tiene particiones más rígidas o irregulares porque fue entrenado con
              un subconjunto aleatorio de datos (Bootstrap). Sin embargo, su diversidad es lo que
              nutre al bosque completo.
            </>
          )}
        </p>
      </div>

      {/* Grid: Feature Importance & Out-of-Bag Score */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Feature Importance */}
        <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50 space-y-3">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-slate-800 flex items-center gap-1.5">
              <BarChart2 className="w-3.5 h-3.5 text-indigo-600" />
              Importancia de Características (Feature Importance)
            </span>
            <span className="text-[10px] text-slate-400">Reducción de Impureza</span>
          </div>

          <div className="space-y-2">
            {/* Feature 1 */}
            <div>
              <div className="flex justify-between text-xs text-slate-700 mb-1">
                <span>{featureNames[0]}</span>
                <span className="font-mono font-bold">
                  {(featureImportances[0] * 100).toFixed(1)}%
                </span>
              </div>
              <div className="w-full bg-slate-200 rounded-full h-2 overflow-hidden">
                <div
                  className="bg-indigo-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${Math.max(4, featureImportances[0] * 100)}%` }}
                />
              </div>
            </div>

            {/* Feature 2 */}
            <div>
              <div className="flex justify-between text-xs text-slate-700 mb-1">
                <span>{featureNames[1]}</span>
                <span className="font-mono font-bold">
                  {(featureImportances[1] * 100).toFixed(1)}%
                </span>
              </div>
              <div className="w-full bg-slate-200 rounded-full h-2 overflow-hidden">
                <div
                  className="bg-teal-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${Math.max(4, featureImportances[1] * 100)}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Out-of-Bag (OOB) Metric Card */}
        <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-slate-800 flex items-center gap-1.5">
              <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
              Validación Out-of-Bag (OOB Score)
            </span>
            <span className="text-[10px] text-slate-400">
              {bootstrap ? 'Bootstrap Activo' : 'Sin Bootstrap'}
            </span>
          </div>

          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-extrabold font-mono text-emerald-600">
              {bootstrap ? `${(oobScore * 100).toFixed(1)}%` : 'N/A'}
            </span>
            <span className="text-xs text-slate-500">
              {bootstrap ? 'evaluado en muestras no vistas' : 'requiere bootstrap'}
            </span>
          </div>

          <p className="text-[11px] text-slate-600 leading-relaxed">
            En cada árbol con bootstrap, aproximadamente el{' '}
            <strong>36.8% de los datos quedan fuera</strong> de la muestra. El bosque los evalúa
            automáticamente como un conjunto de validación gratuito sin tocar los datos de prueba.
          </p>
        </div>
      </div>
    </div>
  );
};
