import React from 'react';
import { Network, GitFork, Trees, BookOpen, RotateCcw } from 'lucide-react';
import { TaskType } from '../types/ml';

export type AppMode = 'classification_tree' | 'regression_tree' | 'random_forest' | 'pedagogical_guide';

interface HeaderProps {
  currentMode: AppMode;
  onSelectMode: (mode: AppMode) => void;
  datasets: { id: string; name: string; taskType: TaskType }[];
  selectedDatasetId: string;
  onSelectDataset: (id: string) => void;
  onResetParams: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentMode,
  onSelectMode,
  datasets,
  selectedDatasetId,
  onSelectDataset,
  onResetParams,
}) => {
  return (
    <header className="bg-slate-900 border-b border-slate-800 text-slate-100 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          {/* Logo & Title */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 via-blue-600 to-teal-400 flex items-center justify-center shadow-lg shadow-indigo-500/25">
              <Trees className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-bold tracking-tight text-white">
                  Laboratorio Didáctico de Árboles y Random Forest
                </h1>
                <span className="text-[11px] font-semibold tracking-wide uppercase px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  Pedagógico ML
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Visualiza y experimenta en tiempo real el impacto de los hiperparámetros en el sesgo y la varianza
              </p>
            </div>
          </div>

          {/* Dataset selector & Quick reset */}
          {currentMode !== 'pedagogical_guide' && (
            <div className="flex items-center gap-2 flex-wrap">
              <label htmlFor="dataset-select" className="text-xs text-slate-400 font-medium">
                Caso Práctico:
              </label>
              <select
                id="dataset-select"
                value={selectedDatasetId}
                onChange={e => onSelectDataset(e.target.value)}
                className="bg-slate-800 border border-slate-700 text-slate-200 text-xs rounded-lg px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer max-w-[260px] truncate"
              >
                {datasets.map(d => (
                  <option key={d.id} value={d.id}>
                    {d.name} ({d.taskType === 'classification' ? 'Clasificación' : 'Regresión'})
                  </option>
                ))}
              </select>

              <button
                id="reset-params-btn"
                onClick={onResetParams}
                title="Restablecer hiperparámetros por defecto"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700 hover:text-white transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Restablecer</span>
              </button>
            </div>
          )}
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1.5 mt-4 overflow-x-auto pb-1 scrollbar-thin">
          <button
            id="tab-classification-tree"
            onClick={() => onSelectMode('classification_tree')}
            className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
              currentMode === 'classification_tree'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            <GitFork className="w-4 h-4" />
            <span>1. Árbol de Clasificación</span>
          </button>

          <button
            id="tab-regression-tree"
            onClick={() => onSelectMode('regression_tree')}
            className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
              currentMode === 'regression_tree'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Network className="w-4 h-4" />
            <span>2. Árbol de Regresión</span>
          </button>

          <button
            id="tab-random-forest"
            onClick={() => onSelectMode('random_forest')}
            className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
              currentMode === 'random_forest'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Trees className="w-4 h-4" />
            <span>3. Random Forest (Ensamble)</span>
          </button>

          <button
            id="tab-pedagogical-guide"
            onClick={() => onSelectMode('pedagogical_guide')}
            className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
              currentMode === 'pedagogical_guide'
                ? 'bg-amber-600 text-white shadow-sm'
                : 'text-amber-300 hover:text-white hover:bg-amber-950/40 border border-amber-500/20'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>Guía y Clasificación de Hiperparámetros</span>
          </button>
        </div>
      </div>
    </header>
  );
};
