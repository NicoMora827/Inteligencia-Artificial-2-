import React, { useState } from 'react';
import { Sliders, HelpCircle, Sparkles, AlertTriangle, ShieldCheck, Flame } from 'lucide-react';
import { Hyperparameters, TaskType } from '../types/ml';
import { HYPERPARAMETER_CATALOG } from '../ml/hyperparameterImpact';

interface HyperparameterControlsProps {
  params: Hyperparameters;
  onChange: (params: Hyperparameters) => void;
  taskType: TaskType;
  isRandomForest?: boolean;
}

export const HyperparameterControls: React.FC<HyperparameterControlsProps> = ({
  params,
  onChange,
  taskType,
  isRandomForest = false,
}) => {
  const [activeHelpKey, setActiveHelpKey] = useState<string | null>(null);

  const updateParam = <K extends keyof Hyperparameters>(key: K, value: Hyperparameters[K]) => {
    onChange({
      ...params,
      [key]: value,
    });
  };

  const applyPreset = (type: 'underfitting' | 'optimal' | 'overfitting') => {
    if (type === 'underfitting') {
      onChange({
        ...params,
        maxDepth: 1,
        minSamplesLeaf: 15,
        minSamplesSplit: 20,
        nEstimators: isRandomForest ? 2 : params.nEstimators,
      });
    } else if (type === 'optimal') {
      onChange({
        ...params,
        maxDepth: isRandomForest ? 5 : 4,
        minSamplesLeaf: 4,
        minSamplesSplit: 8,
        nEstimators: isRandomForest ? 20 : params.nEstimators,
        bootstrap: true,
        maxFeatures: 'sqrt',
      });
    } else if (type === 'overfitting') {
      onChange({
        ...params,
        maxDepth: 9,
        minSamplesLeaf: 1,
        minSamplesSplit: 2,
        nEstimators: isRandomForest ? 1 : params.nEstimators,
      });
    }
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5 space-y-5">
      {/* Title & Presets Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-indigo-50 text-indigo-600">
            <Sliders className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-slate-800">Control de Hiperparámetros</h2>
            <p className="text-xs text-slate-500">Ajusta los parámetros y observa la frontera en vivo</p>
          </div>
        </div>

        {/* Quick Didactic Presets */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-[11px] font-medium text-slate-400 mr-1 hidden sm:inline">
            Casos Guía:
          </span>
          <button
            id="preset-underfit-btn"
            onClick={() => applyPreset('underfitting')}
            className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded-md bg-amber-50 text-amber-700 hover:bg-amber-100 border border-amber-200 transition-colors"
            title="Aplica valores para generar Subajuste (modelo muy rígido)"
          >
            <AlertTriangle className="w-3 h-3 text-amber-600" />
            Subajuste
          </button>
          <button
            id="preset-optimal-btn"
            onClick={() => applyPreset('optimal')}
            className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded-md bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200 transition-colors"
            title="Aplica valores equilibrados para buena generalización"
          >
            <ShieldCheck className="w-3 h-3 text-emerald-600" />
            Óptimo
          </button>
          <button
            id="preset-overfit-btn"
            onClick={() => applyPreset('overfitting')}
            className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded-md bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200 transition-colors"
            title="Aplica valores para generar Sobreajuste (memorización de ruido)"
          >
            <Flame className="w-3 h-3 text-rose-600" />
            Sobreajuste
          </button>
        </div>
      </div>

      {/* Sliders Grid */}
      <div className="space-y-4">
        {/* 1. max_depth */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-1.5">
              <label htmlFor="slider-max-depth" className="font-semibold text-slate-700">
                Profundidad Máxima (max_depth)
              </label>
              <button
                type="button"
                onClick={() => setActiveHelpKey(activeHelpKey === 'maxDepth' ? null : 'maxDepth')}
                className="text-slate-400 hover:text-indigo-600 transition-colors"
                title="Ver explicación didáctica"
              >
                <HelpCircle className="w-3.5 h-3.5" />
              </button>
            </div>
            <span className="font-mono font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded text-xs">
              {params.maxDepth} niveles
            </span>
          </div>
          <input
            id="slider-max-depth"
            type="range"
            min="1"
            max="10"
            step="1"
            value={params.maxDepth}
            onChange={e => updateParam('maxDepth', parseInt(e.target.value))}
            className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
          />
          <div className="flex justify-between text-[10px] text-slate-400">
            <span>1 (Bifurcación simple / Muñón)</span>
            <span>5 (Moderado)</span>
            <span>10 (Complejo / Alto riesgo overfit)</span>
          </div>

          {activeHelpKey === 'maxDepth' && (
            <div className="p-2.5 rounded-lg bg-indigo-50/70 border border-indigo-100 text-xs text-slate-700 space-y-1 animate-in fade-in duration-150">
              <div className="font-semibold text-indigo-900 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-indigo-600" />
                Impacto: {HYPERPARAMETER_CATALOG.maxDepth.impactLevel} ({HYPERPARAMETER_CATALOG.maxDepth.categoryLabel})
              </div>
              <p>{HYPERPARAMETER_CATALOG.maxDepth.shortExplanation}</p>
              <p className="text-[11px] text-slate-600 italic">💡 {HYPERPARAMETER_CATALOG.maxDepth.practicalTip}</p>
            </div>
          )}
        </div>

        {/* 2. min_samples_leaf */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-1.5">
              <label htmlFor="slider-min-leaf" className="font-semibold text-slate-700">
                Muestras Mínimas por Hoja (min_samples_leaf)
              </label>
              <button
                type="button"
                onClick={() => setActiveHelpKey(activeHelpKey === 'minSamplesLeaf' ? null : 'minSamplesLeaf')}
                className="text-slate-400 hover:text-indigo-600 transition-colors"
                title="Ver explicación didáctica"
              >
                <HelpCircle className="w-3.5 h-3.5" />
              </button>
            </div>
            <span className="font-mono font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded text-xs">
              {params.minSamplesLeaf} muestras
            </span>
          </div>
          <input
            id="slider-min-leaf"
            type="range"
            min="1"
            max="18"
            step="1"
            value={params.minSamplesLeaf}
            onChange={e => updateParam('minSamplesLeaf', parseInt(e.target.value))}
            className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
          />
          <div className="flex justify-between text-[10px] text-slate-400">
            <span>1 (Permite hojas con 1 muestra)</span>
            <span>8 (Suavizado regular)</span>
            <span>18 (Muy conservador)</span>
          </div>

          {activeHelpKey === 'minSamplesLeaf' && (
            <div className="p-2.5 rounded-lg bg-indigo-50/70 border border-indigo-100 text-xs text-slate-700 space-y-1 animate-in fade-in duration-150">
              <div className="font-semibold text-indigo-900 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-indigo-600" />
                Impacto: {HYPERPARAMETER_CATALOG.minSamplesLeaf.impactLevel} ({HYPERPARAMETER_CATALOG.minSamplesLeaf.categoryLabel})
              </div>
              <p>{HYPERPARAMETER_CATALOG.minSamplesLeaf.shortExplanation}</p>
              <p className="text-[11px] text-slate-600 italic">💡 {HYPERPARAMETER_CATALOG.minSamplesLeaf.practicalTip}</p>
            </div>
          )}
        </div>

        {/* 3. min_samples_split */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-1.5">
              <label htmlFor="slider-min-split" className="font-semibold text-slate-700">
                Muestras Mínimas para Dividir (min_samples_split)
              </label>
              <button
                type="button"
                onClick={() => setActiveHelpKey(activeHelpKey === 'minSamplesSplit' ? null : 'minSamplesSplit')}
                className="text-slate-400 hover:text-indigo-600 transition-colors"
                title="Ver explicación didáctica"
              >
                <HelpCircle className="w-3.5 h-3.5" />
              </button>
            </div>
            <span className="font-mono font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded text-xs">
              {params.minSamplesSplit} muestras
            </span>
          </div>
          <input
            id="slider-min-split"
            type="range"
            min="2"
            max="30"
            step="1"
            value={params.minSamplesSplit}
            onChange={e => updateParam('minSamplesSplit', parseInt(e.target.value))}
            className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
          />
          <div className="flex justify-between text-[10px] text-slate-400">
            <span>2 (Crecimiento agresivo)</span>
            <span>15 (Poda equilibrada)</span>
            <span>30 (Poda estricta)</span>
          </div>

          {activeHelpKey === 'minSamplesSplit' && (
            <div className="p-2.5 rounded-lg bg-indigo-50/70 border border-indigo-100 text-xs text-slate-700 space-y-1 animate-in fade-in duration-150">
              <div className="font-semibold text-indigo-900 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-indigo-600" />
                Impacto: {HYPERPARAMETER_CATALOG.minSamplesSplit.impactLevel} ({HYPERPARAMETER_CATALOG.minSamplesSplit.categoryLabel})
              </div>
              <p>{HYPERPARAMETER_CATALOG.minSamplesSplit.shortExplanation}</p>
              <p className="text-[11px] text-slate-600 italic">💡 {HYPERPARAMETER_CATALOG.minSamplesSplit.practicalTip}</p>
            </div>
          )}
        </div>

        {/* 4. Criterion */}
        <div className="space-y-1.5 pt-1">
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-1.5">
              <span className="font-semibold text-slate-700">Criterio Matemático (criterion)</span>
              <button
                type="button"
                onClick={() => setActiveHelpKey(activeHelpKey === 'criterion' ? null : 'criterion')}
                className="text-slate-400 hover:text-indigo-600 transition-colors"
                title="Ver explicación didáctica"
              >
                <HelpCircle className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            {taskType === 'classification' ? (
              <>
                <button
                  type="button"
                  id="btn-criterion-gini"
                  onClick={() => updateParam('criterion', 'gini')}
                  className={`py-1.5 px-3 text-xs font-medium rounded-lg border text-center transition-all ${
                    params.criterion === 'gini'
                      ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  Gini Impurity
                </button>
                <button
                  type="button"
                  id="btn-criterion-entropy"
                  onClick={() => updateParam('criterion', 'entropy')}
                  className={`py-1.5 px-3 text-xs font-medium rounded-lg border text-center transition-all ${
                    params.criterion === 'entropy'
                      ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  Entropía (Info Gain)
                </button>
              </>
            ) : (
              <>
                <button
                  type="button"
                  id="btn-criterion-mse"
                  onClick={() => updateParam('criterion', 'mse')}
                  className={`py-1.5 px-3 text-xs font-medium rounded-lg border text-center transition-all ${
                    params.criterion === 'mse'
                      ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  MSE (Error Cuadrático)
                </button>
                <button
                  type="button"
                  id="btn-criterion-mae"
                  onClick={() => updateParam('criterion', 'mae')}
                  className={`py-1.5 px-3 text-xs font-medium rounded-lg border text-center transition-all ${
                    params.criterion === 'mae'
                      ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  MAE (Error Absoluto)
                </button>
              </>
            )}
          </div>

          {activeHelpKey === 'criterion' && (
            <div className="p-2.5 rounded-lg bg-indigo-50/70 border border-indigo-100 text-xs text-slate-700 space-y-1 animate-in fade-in duration-150">
              <div className="font-semibold text-indigo-900 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-indigo-600" />
                Impacto: {HYPERPARAMETER_CATALOG.criterion.impactLevel} ({HYPERPARAMETER_CATALOG.criterion.categoryLabel})
              </div>
              <p>{HYPERPARAMETER_CATALOG.criterion.shortExplanation}</p>
              <p className="text-[11px] text-slate-600 italic">💡 {HYPERPARAMETER_CATALOG.criterion.practicalTip}</p>
            </div>
          )}
        </div>

        {/* RANDOM FOREST SPECIFIC CONTROLS */}
        {isRandomForest && (
          <div className="pt-3 border-t border-slate-200 space-y-4">
            <div className="text-xs font-bold text-slate-800 flex items-center gap-1.5 text-teal-800">
              <span>Hiperparámetros de Ensamble (Random Forest)</span>
            </div>

            {/* n_estimators */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-1.5">
                  <label htmlFor="slider-n-estimators" className="font-semibold text-slate-700">
                    Número de Árboles (n_estimators)
                  </label>
                  <button
                    type="button"
                    onClick={() => setActiveHelpKey(activeHelpKey === 'nEstimators' ? null : 'nEstimators')}
                    className="text-slate-400 hover:text-indigo-600 transition-colors"
                  >
                    <HelpCircle className="w-3.5 h-3.5" />
                  </button>
                </div>
                <span className="font-mono font-bold text-teal-700 bg-teal-50 px-2 py-0.5 rounded text-xs border border-teal-200">
                  {params.nEstimators} árboles
                </span>
              </div>
              <input
                id="slider-n-estimators"
                type="range"
                min="1"
                max="40"
                step="1"
                value={params.nEstimators}
                onChange={e => updateParam('nEstimators', parseInt(e.target.value))}
                className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-teal-600"
              />
              <div className="flex justify-between text-[10px] text-slate-400">
                <span>1 (Comportamiento de árbol individual)</span>
                <span>20 (Buen ensamble)</span>
                <span>40 (Máxima reducción varianza)</span>
              </div>

              {activeHelpKey === 'nEstimators' && (
                <div className="p-2.5 rounded-lg bg-teal-50/80 border border-teal-200 text-xs text-slate-700 space-y-1 animate-in fade-in duration-150">
                  <div className="font-semibold text-teal-900 flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-teal-600" />
                    Impacto: {HYPERPARAMETER_CATALOG.nEstimators.impactLevel} ({HYPERPARAMETER_CATALOG.nEstimators.categoryLabel})
                  </div>
                  <p>{HYPERPARAMETER_CATALOG.nEstimators.shortExplanation}</p>
                  <p className="text-[11px] text-slate-600 italic">💡 {HYPERPARAMETER_CATALOG.nEstimators.practicalTip}</p>
                </div>
              )}
            </div>

            {/* Bootstrap & Max Features */}
            <div className="grid grid-cols-2 gap-3 pt-1">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  Muestreo Bootstrap
                </label>
                <button
                  type="button"
                  id="btn-toggle-bootstrap"
                  onClick={() => updateParam('bootstrap', !params.bootstrap)}
                  className={`w-full py-1.5 px-2 text-xs font-semibold rounded-lg border transition-all ${
                    params.bootstrap
                      ? 'bg-teal-600 text-white border-teal-600'
                      : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {params.bootstrap ? '✓ Con Reemplazo' : '✗ Sin Reemplazo'}
                </button>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  Variables (max_features)
                </label>
                <select
                  id="select-max-features"
                  value={String(params.maxFeatures)}
                  onChange={e => {
                    const val = e.target.value;
                    updateParam('maxFeatures', val === 'sqrt' ? 'sqrt' : 'all');
                  }}
                  className="w-full bg-slate-50 border border-slate-200 text-slate-700 text-xs rounded-lg px-2.5 py-1.5 focus:outline-none focus:ring-1 focus:ring-teal-500"
                >
                  <option value="sqrt">sqrt (1 variable por división)</option>
                  <option value="all">all (todas las variables)</option>
                </select>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
