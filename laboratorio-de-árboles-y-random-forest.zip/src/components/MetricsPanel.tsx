import React from 'react';
import { Activity, AlertTriangle, ShieldCheck, Flame, Scale, CheckCircle2 } from 'lucide-react';
import {
  ClassificationMetrics,
  RegressionMetrics,
  ModelDiagnostics,
  TaskType,
  TreeStats,
} from '../types/ml';

interface MetricsPanelProps {
  taskType: TaskType;
  classificationMetrics?: ClassificationMetrics;
  regressionMetrics?: RegressionMetrics;
  diagnostics: ModelDiagnostics;
  treeStats: TreeStats;
}

export const MetricsPanel: React.FC<MetricsPanelProps> = ({
  taskType,
  classificationMetrics,
  regressionMetrics,
  diagnostics,
  treeStats,
}) => {
  const isClassification = taskType === 'classification';

  const trainScore = isClassification
    ? (classificationMetrics?.trainAccuracy ?? 0) * 100
    : (regressionMetrics?.trainR2 ?? 0) * 100;

  const testScore = isClassification
    ? (classificationMetrics?.testAccuracy ?? 0) * 100
    : (regressionMetrics?.testR2 ?? 0) * 100;

  const scoreUnit = isClassification ? '%' : '% R²';

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5 space-y-4">
      {/* 1. Diagnostic Status Banner */}
      <div
        className={`p-4 rounded-xl border flex flex-col md:flex-row md:items-center justify-between gap-3 ${
          diagnostics.status === 'optimal'
            ? 'bg-emerald-50/80 border-emerald-200 text-emerald-950'
            : diagnostics.status === 'overfitting'
            ? 'bg-rose-50/80 border-rose-200 text-rose-950'
            : 'bg-amber-50/80 border-amber-200 text-amber-950'
        }`}
      >
        <div className="flex items-start gap-3">
          <div
            className={`p-2 rounded-lg mt-0.5 ${
              diagnostics.status === 'optimal'
                ? 'bg-emerald-100 text-emerald-700'
                : diagnostics.status === 'overfitting'
                ? 'bg-rose-100 text-rose-700'
                : 'bg-amber-100 text-amber-700'
            }`}
          >
            {diagnostics.status === 'optimal' ? (
              <ShieldCheck className="w-5 h-5" />
            ) : diagnostics.status === 'overfitting' ? (
              <Flame className="w-5 h-5" />
            ) : (
              <AlertTriangle className="w-5 h-5" />
            )}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold">{diagnostics.statusLabel}</h3>
              <span className="text-[11px] font-mono font-bold px-2 py-0.5 rounded-full bg-white/70 border border-slate-300">
                Complejidad: {diagnostics.complexityScore}/100
              </span>
            </div>
            <p className="text-xs mt-1 text-slate-700 leading-relaxed">
              {diagnostics.explanation}
            </p>
            <p className="text-xs mt-1 font-semibold text-slate-800">
              💡 {diagnostics.recommendedAction}
            </p>
          </div>
        </div>
      </div>

      {/* 2. Core Comparison Cards (Train vs Test) */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {/* Train Score Card */}
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
          <div className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">
            {isClassification ? 'Exactitud Train' : 'R² Score Train'}
          </div>
          <div className="text-xl font-extrabold text-slate-900 mt-1 font-mono">
            {trainScore.toFixed(1)}
            <span className="text-xs text-slate-500 ml-0.5">{scoreUnit}</span>
          </div>
          <div className="text-[10px] text-slate-500 mt-1">Datos con los que aprendió</div>
        </div>

        {/* Test Score Card */}
        <div
          className={`border rounded-lg p-3 ${
            diagnostics.status === 'overfitting'
              ? 'bg-rose-50/50 border-rose-200'
              : 'bg-slate-50 border-slate-200'
          }`}
        >
          <div className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">
            {isClassification ? 'Exactitud Test' : 'R² Score Test'}
          </div>
          <div
            className={`text-xl font-extrabold mt-1 font-mono ${
              diagnostics.status === 'overfitting' ? 'text-rose-600' : 'text-slate-900'
            }`}
          >
            {testScore.toFixed(1)}
            <span className="text-xs text-slate-500 ml-0.5">{scoreUnit}</span>
          </div>
          <div className="text-[10px] text-slate-500 mt-1">Capacidad de generalizar</div>
        </div>

        {/* Gap / Error Metric */}
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
          <div className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">
            {isClassification ? 'F1-Score Test' : 'RMSE Test'}
          </div>
          <div className="text-xl font-extrabold text-indigo-600 mt-1 font-mono">
            {isClassification
              ? `${((classificationMetrics?.testF1 ?? 0) * 100).toFixed(1)}%`
              : `${(regressionMetrics?.testRmse ?? 0).toFixed(1)}`}
          </div>
          <div className="text-[10px] text-slate-500 mt-1">
            {isClassification ? 'Equilibrio Precisión/Recall' : 'Desviación típica media'}
          </div>
        </div>

        {/* Tree Complexity Stats */}
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
          <div className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">
            Estructura Árbol
          </div>
          <div className="text-sm font-bold text-slate-800 mt-1 font-mono">
            {treeStats.totalNodes} nodos ({treeStats.leafCount} hojas)
          </div>
          <div className="text-[10px] text-slate-500 mt-1">
            Profundidad real: <strong className="text-slate-700">{treeStats.actualMaxDepth}</strong>
          </div>
        </div>
      </div>

      {/* 3. Confusion Matrix or Secondary Metrics */}
      {isClassification && classificationMetrics && (
        <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
          <div className="text-xs font-bold text-slate-700 mb-2 flex items-center justify-between">
            <span>Matriz de Confusión (Evaluada en Test):</span>
            <span className="text-[11px] font-normal text-slate-500">
              Total Muestras Test:{' '}
              {classificationMetrics.confusionMatrix.tn +
                classificationMetrics.confusionMatrix.fp +
                classificationMetrics.confusionMatrix.fn +
                classificationMetrics.confusionMatrix.tp}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-center text-xs">
            <div className="bg-emerald-50 border border-emerald-200 rounded p-2 text-emerald-900">
              <span className="text-[10px] text-emerald-700 block">Verdaderos Negativos (TN)</span>
              <strong className="text-base font-mono">
                {classificationMetrics.confusionMatrix.tn}
              </strong>
            </div>
            <div className="bg-rose-50 border border-rose-200 rounded p-2 text-rose-900">
              <span className="text-[10px] text-rose-700 block">Falsos Positivos (FP)</span>
              <strong className="text-base font-mono">
                {classificationMetrics.confusionMatrix.fp}
              </strong>
            </div>
            <div className="bg-rose-50 border border-rose-200 rounded p-2 text-rose-900">
              <span className="text-[10px] text-rose-700 block">Falsos Negativos (FN)</span>
              <strong className="text-base font-mono">
                {classificationMetrics.confusionMatrix.fn}
              </strong>
            </div>
            <div className="bg-emerald-50 border border-emerald-200 rounded p-2 text-emerald-900">
              <span className="text-[10px] text-emerald-700 block">Verdaderos Positivos (TP)</span>
              <strong className="text-base font-mono">
                {classificationMetrics.confusionMatrix.tp}
              </strong>
            </div>
          </div>
        </div>
      )}

      {/* Regression secondary metrics */}
      {!isClassification && regressionMetrics && (
        <div className="grid grid-cols-2 gap-3 text-xs">
          <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg">
            <span className="text-slate-500 text-[11px] block">Error Absoluto Medio (MAE):</span>
            <strong className="text-sm font-mono text-slate-800">
              {regressionMetrics.testMae.toFixed(2)}
            </strong>
          </div>
          <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg">
            <span className="text-slate-500 text-[11px] block">Error Cuadrático Medio (RMSE):</span>
            <strong className="text-sm font-mono text-slate-800">
              {regressionMetrics.testRmse.toFixed(2)}
            </strong>
          </div>
        </div>
      )}
    </div>
  );
};
