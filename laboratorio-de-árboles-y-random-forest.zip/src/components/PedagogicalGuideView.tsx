import React, { useState } from 'react';
import {
  BookOpen,
  Sparkles,
  AlertTriangle,
  Flame,
  ShieldCheck,
  HelpCircle,
  CheckCircle2,
  Sliders,
  Scale,
  GitFork,
  Network,
  Trees,
} from 'lucide-react';
import { HYPERPARAMETER_CATALOG } from '../ml/hyperparameterImpact';

export const PedagogicalGuideView: React.FC = () => {
  const [interactiveProblem, setInteractiveProblem] = useState<'overfit' | 'underfit' | 'variance'>(
    'overfit'
  );

  return (
    <div className="max-w-6xl mx-auto space-y-8 py-2">
      {/* Hero Pedagogical Banner */}
      <div className="bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 rounded-2xl p-6 sm:p-8 text-white border border-slate-800 shadow-xl">
        <div className="flex items-center gap-3 mb-3">
          <span className="p-2 rounded-xl bg-indigo-500/20 border border-indigo-500/30 text-indigo-300">
            <BookOpen className="w-6 h-6" />
          </span>
          <span className="text-xs font-bold tracking-wider uppercase text-indigo-400">
            Guía Didáctica de Machine Learning
          </span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
          Clasificación Didáctica del Impacto de los Hiperparámetros
        </h2>
        <p className="text-sm sm:text-base text-slate-300 max-w-3xl mt-2 leading-relaxed">
          Los hiperparámetros son las palancas que configuras antes del entrenamiento para gobernar
          el equilibrio entre la <strong>capacidad de memorización (Varianza)</strong> y la{' '}
          <strong>simplicidad generalizadora (Sesgo)</strong>. A continuación aprenderás cómo
          clasificarlos y diagnosticarlos en casos prácticos.
        </p>
      </div>

      {/* 1. Categorización Fundamental */}
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-indigo-100 text-indigo-700">
            <Sliders className="w-4 h-4" />
          </div>
          <h3 className="text-lg font-bold text-slate-900">
            1. Las 3 Familias de Hiperparámetros
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Familia 1: Complejidad */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm space-y-3">
            <div className="flex items-center gap-2 text-indigo-700">
              <Scale className="w-5 h-5" />
              <h4 className="font-bold text-sm">A. Control de Complejidad</h4>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Controlan el tamaño físico del árbol y cuántas subdivisiones puede crear en el espacio
              de datos.
            </p>
            <div className="space-y-2 pt-2 border-t border-slate-100 text-xs">
              <div className="p-2 rounded bg-indigo-50/60 border border-indigo-100">
                <strong className="text-indigo-900">max_depth:</strong> Límite de niveles de
                bifurcación.
              </div>
              <div className="p-2 rounded bg-indigo-50/60 border border-indigo-100">
                <strong className="text-indigo-900">min_samples_split:</strong> Mínimo de muestras
                para permitir división.
              </div>
              <div className="p-2 rounded bg-indigo-50/60 border border-indigo-100">
                <strong className="text-indigo-900">min_samples_leaf:</strong> Mínimo de muestras
                en cada hoja final.
              </div>
            </div>
          </div>

          {/* Familia 2: Reducción de Varianza */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm space-y-3">
            <div className="flex items-center gap-2 text-teal-700">
              <Trees className="w-5 h-5" />
              <h4 className="font-bold text-sm">B. Reducción de Varianza (Ensamble)</h4>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Exclusivos de Random Forest. Crean una multitud de árboles diversos y promedian sus
              opiniones para cancelar errores.
            </p>
            <div className="space-y-2 pt-2 border-t border-slate-100 text-xs">
              <div className="p-2 rounded bg-teal-50/60 border border-teal-100">
                <strong className="text-teal-900">n_estimators:</strong> Número de árboles
                entrenados.
              </div>
              <div className="p-2 rounded bg-teal-50/60 border border-teal-100">
                <strong className="text-teal-900">max_features:</strong> Variables candidatas al azar
                por nodo.
              </div>
              <div className="p-2 rounded bg-teal-50/60 border border-teal-100">
                <strong className="text-teal-900">bootstrap:</strong> Muestreo con reemplazo para
                inyectar diversidad.
              </div>
            </div>
          </div>

          {/* Familia 3: Criterio Matemático */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm space-y-3">
            <div className="flex items-center gap-2 text-amber-700">
              <Sparkles className="w-5 h-5" />
              <h4 className="font-bold text-sm">C. Criterio de Pureza</h4>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Define qué tan 'mezclado' o 'disperso' está un grupo de datos para encontrar el corte
              óptimo.
            </p>
            <div className="space-y-2 pt-2 border-t border-slate-100 text-xs">
              <div className="p-2 rounded bg-amber-50/60 border border-amber-100">
                <strong className="text-amber-900">Gini vs Entropía:</strong> En clasificación,
                miden la impureza de clases.
              </div>
              <div className="p-2 rounded bg-amber-50/60 border border-amber-100">
                <strong className="text-amber-900">MSE vs MAE:</strong> En regresión, MSE castiga
                desviaciones grandes; MAE es robusto ante outliers.
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Tabla Comparativa de Impacto */}
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-indigo-100 text-indigo-700">
            <BookOpen className="w-4 h-4" />
          </div>
          <h3 className="text-lg font-bold text-slate-900">
            2. Matriz de Impacto en el Rendimiento del Modelo
          </h3>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-700 font-bold">
                  <th className="p-3">Hiperparámetro</th>
                  <th className="p-3">Impacto</th>
                  <th className="p-3">Al Aumentar ↑</th>
                  <th className="p-3">Al Disminuir ↓</th>
                  <th className="p-3">Regla Práctica</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-600">
                {Object.values(HYPERPARAMETER_CATALOG).map(doc => (
                  <tr key={doc.key} className="hover:bg-slate-50/60 transition-colors">
                    <td className="p-3 font-semibold text-slate-800">
                      <div>{doc.name}</div>
                      <span className="text-[10px] text-slate-400 font-normal">
                        {doc.categoryLabel}
                      </span>
                    </td>
                    <td className="p-3">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          doc.impactLevel === 'Crítico'
                            ? 'bg-rose-100 text-rose-800'
                            : doc.impactLevel === 'Alto'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-blue-100 text-blue-800'
                        }`}
                      >
                        {doc.impactLevel}
                      </span>
                    </td>
                    <td className="p-3 text-[11px] max-w-xs">{doc.increasingEffect}</td>
                    <td className="p-3 text-[11px] max-w-xs">{doc.decreasingEffect}</td>
                    <td className="p-3 text-[11px] max-w-xs text-indigo-900 font-medium">
                      {doc.practicalTip}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* 3. Simulador de Diagnóstico: "El Doctor de Hiperparámetros" */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-4">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-emerald-100 text-emerald-700">
            <CheckCircle2 className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900">
              3. Simulador de Diagnóstico Práctico ("El Doctor de Hiperparámetros")
            </h3>
            <p className="text-xs text-slate-500">
              Selecciona un síntoma común al entrenar modelos y aprende la prescripción exacta
            </p>
          </div>
        </div>

        {/* Diagnostic scenarios selector */}
        <div className="flex gap-2 flex-wrap">
          <button
            onClick={() => setInteractiveProblem('overfit')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-all ${
              interactiveProblem === 'overfit'
                ? 'bg-rose-600 text-white border-rose-600 shadow-sm'
                : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
            }`}
          >
            Caso A: Train 99% vs Test 67% (Sobreajuste Severo)
          </button>
          <button
            onClick={() => setInteractiveProblem('underfit')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-all ${
              interactiveProblem === 'underfit'
                ? 'bg-amber-600 text-white border-amber-600 shadow-sm'
                : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
            }`}
          >
            Caso B: Train 62% vs Test 61% (Subajuste / Modelo Ciego)
          </button>
          <button
            onClick={() => setInteractiveProblem('variance')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-all ${
              interactiveProblem === 'variance'
                ? 'bg-teal-600 text-white border-teal-600 shadow-sm'
                : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
            }`}
          >
            Caso C: Árbol inestable ante pequeñas variaciones de datos
          </button>
        </div>

        {/* Diagnosis resolution */}
        <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-3">
          {interactiveProblem === 'overfit' && (
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-rose-700 font-bold text-sm">
                <Flame className="w-4 h-4" />
                <span>Diagnóstico: Alta Varianza / Sobreajuste (Overfitting)</span>
              </div>
              <p className="text-slate-700 leading-relaxed">
                El árbol memorizó hasta el último punto atípico del conjunto de entrenamiento
                creando particiones diminutas con 1 o 2 muestras. Al enfrentarse a datos del mundo
                real (test), falla catastróficamente.
              </p>
              <div className="bg-white p-3 rounded-lg border border-slate-200 space-y-1.5 text-slate-800">
                <div className="font-semibold text-indigo-900">
                  Prescripción de Hiperparámetros:
                </div>
                <ul className="list-disc list-inside space-y-1 text-[11px] text-slate-700">
                  <li>
                    <strong>Reduce max_depth:</strong> de 9 a 3 o 4 niveles para forzar reglas más
                    generales.
                  </li>
                  <li>
                    <strong>Aumenta min_samples_leaf:</strong> fija en 5 u 8 para que ninguna hoja
                    se cree con casos solitarios.
                  </li>
                  <li>
                    <strong>Aumenta min_samples_split:</strong> a 10 o 15 para detener la
                    ramificación temprana.
                  </li>
                  <li>
                    <strong>O mejor aún:</strong> Convierte el árbol en un{' '}
                    <strong>Random Forest</strong> con 25 estimadores.
                  </li>
                </ul>
              </div>
            </div>
          )}

          {interactiveProblem === 'underfit' && (
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-amber-700 font-bold text-sm">
                <AlertTriangle className="w-4 h-4" />
                <span>Diagnóstico: Alto Sesgo / Subajuste (Underfitting)</span>
              </div>
              <p className="text-slate-700 leading-relaxed">
                El modelo es incapaz de aprender incluso los patrones evidentes de entrenamiento. Es
                demasiado simplista (por ejemplo, un árbol de profundidad 1 que solo hace una
                pregunta binaria).
              </p>
              <div className="bg-white p-3 rounded-lg border border-slate-200 space-y-1.5 text-slate-800">
                <div className="font-semibold text-indigo-900">
                  Prescripción de Hiperparámetros:
                </div>
                <ul className="list-disc list-inside space-y-1 text-[11px] text-slate-700">
                  <li>
                    <strong>Aumenta max_depth:</strong> permite que el árbol crezca a 4 o 6
                    profundidades para capturar relaciones multivariables.
                  </li>
                  <li>
                    <strong>Disminuye min_samples_leaf:</strong> de valores restrictivos (ej. 20) a
                    2 o 4 muestras.
                  </li>
                  <li>
                    <strong>Verifica el Criterio:</strong> asegúrate de que los datos tengan
                    correlación con la variable objetivo.
                  </li>
                </ul>
              </div>
            </div>
          )}

          {interactiveProblem === 'variance' && (
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-teal-700 font-bold text-sm">
                <Trees className="w-4 h-4" />
                <span>Diagnóstico: Inestabilidad Estructural del Árbol Individual</span>
              </div>
              <p className="text-slate-700 leading-relaxed">
                Los árboles de decisión son conocidos por ser algoritmos de alta varianza: si cambias
                ligeramente 3 datos de entrada, la primera división raíz puede cambiar por completo
                y alterar toda la estructura del árbol restante.
              </p>
              <div className="bg-white p-3 rounded-lg border border-slate-200 space-y-1.5 text-slate-800">
                <div className="font-semibold text-indigo-900">
                  Solución Definitiva: Random Forest (Bagging)
                </div>
                <ul className="list-disc list-inside space-y-1 text-[11px] text-slate-700">
                  <li>
                    <strong>n_estimators ≥ 25:</strong> Entrena un comité de árboles donde cada uno
                    ve una muestra bootstrap diferente.
                  </li>
                  <li>
                    <strong>max_features = 'sqrt':</strong> Cada nodo solo puede elegir entre un
                    subconjunto aleatorio de variables, descorrelacionando los árboles.
                  </li>
                  <li>
                    <strong>Consenso por Votación:</strong> El promedio de muchos árboles
                    imperfectos produce un clasificador casi óptimo y sumamente robusto.
                  </li>
                </ul>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
