import React, { useRef, useEffect, useState, useCallback } from 'react';
import { LineChart, Crosshair, HelpCircle, Activity } from 'lucide-react';
import { Dataset, DataPoint } from '../types/ml';

interface RegressionPlotCanvasProps {
  dataset: Dataset;
  predictFn: (x1: number, x2: number) => number;
  selectedProbe: { x1: number; x2: number } | null;
  onSelectProbe: (probe: { x1: number; x2: number } | null) => void;
  showTestData?: boolean;
}

export const RegressionPlotCanvas: React.FC<RegressionPlotCanvasProps> = ({
  dataset,
  predictFn,
  selectedProbe,
  onSelectProbe,
  showTestData = true,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [hoveredVal, setHoveredVal] = useState<{ x1: number; predY: number } | null>(null);

  const allPoints = [...dataset.trainData, ...dataset.testData];
  const minX1 = Math.min(...allPoints.map(p => p.x1));
  const maxX1 = Math.max(...allPoints.map(p => p.x1));
  const minY = Math.min(...allPoints.map(p => p.y));
  const maxY = Math.max(...allPoints.map(p => p.y));

  // Compute fixed average of x2 across dataset to slice 1D response curve
  const avgX2 = allPoints.reduce((acc, p) => acc + p.x2, 0) / allPoints.length;

  const padX1 = (maxX1 - minX1) * 0.05;
  const padY = (maxY - minY) * 0.08;
  const rangeX1: [number, number] = [minX1 - padX1, maxX1 + padX1];
  const rangeY: [number, number] = [Math.max(0, minY - padY), maxY + padY];

  const toCanvas = useCallback(
    (x1: number, y: number, width: number, height: number) => {
      const padding = 42;
      const plotW = width - padding * 2;
      const plotH = height - padding * 2;

      const px = padding + ((x1 - rangeX1[0]) / (rangeX1[1] - rangeX1[0])) * plotW;
      const py = height - padding - ((y - rangeY[0]) / (rangeY[1] - rangeY[0])) * plotH;
      return { px, py };
    },
    [rangeX1, rangeY]
  );

  const fromCanvas = useCallback(
    (px: number, py: number, width: number, height: number) => {
      const padding = 42;
      const plotW = width - padding * 2;
      const plotH = height - padding * 2;

      const x1 = rangeX1[0] + ((px - padding) / plotW) * (rangeX1[1] - rangeX1[0]);
      const y = rangeY[0] + ((height - padding - py) / plotH) * (rangeY[1] - rangeY[0]);
      return { x1, y };
    },
    [rangeX1, rangeY]
  );

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    const padding = 42;

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, width, height);

    // 1. Grid lines & background
    ctx.fillStyle = '#f8fafc';
    ctx.fillRect(padding, padding, width - padding * 2, height - padding * 2);

    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 1;

    // Horiz grid
    const yTicks = 5;
    ctx.font = '10px Inter, system-ui, sans-serif';
    ctx.fillStyle = '#64748b';
    ctx.textAlign = 'right';

    for (let i = 0; i <= yTicks; i++) {
      const val = rangeY[0] + (i / yTicks) * (rangeY[1] - rangeY[0]);
      const { py } = toCanvas(rangeX1[0], val, width, height);
      ctx.beginPath();
      ctx.moveTo(padding, py);
      ctx.lineTo(width - padding, py);
      ctx.stroke();
      ctx.fillText(val.toFixed(0), padding - 6, py + 3);
    }

    // Vert grid
    const xTicks = 6;
    ctx.textAlign = 'center';
    for (let i = 0; i <= xTicks; i++) {
      const val = rangeX1[0] + (i / xTicks) * (rangeX1[1] - rangeX1[0]);
      const { px } = toCanvas(val, rangeY[0], width, height);
      ctx.beginPath();
      ctx.moveTo(px, padding);
      ctx.lineTo(px, height - padding);
      ctx.stroke();
      ctx.fillText(val.toFixed(0), px, height - padding + 16);
    }

    // Axis Labels
    ctx.fillStyle = '#1e293b';
    ctx.font = 'bold 11px Inter, system-ui, sans-serif';
    ctx.fillText(
      `${dataset.x1Name} ${dataset.x1Unit ? `(${dataset.x1Unit})` : ''}`,
      width / 2,
      height - 6
    );

    ctx.save();
    ctx.translate(12, height / 2);
    ctx.rotate(-Math.PI / 2);
    ctx.fillText(
      `${dataset.yName} ${dataset.yUnit ? `(${dataset.yUnit})` : ''}`,
      0,
      0
    );
    ctx.restore();

    // 2. Sample prediction function to draw step-wise regression curve
    const steps = 300;
    const curvePoints: { x1: number; y: number }[] = [];
    for (let s = 0; s <= steps; s++) {
      const x1Val = rangeX1[0] + (s / steps) * (rangeX1[1] - rangeX1[0]);
      const pred = predictFn(x1Val, avgX2);
      curvePoints.push({ x1: x1Val, y: pred });
    }

    // Fill area under curve softly
    ctx.beginPath();
    const startPt = toCanvas(curvePoints[0].x1, curvePoints[0].y, width, height);
    const bottomStart = toCanvas(curvePoints[0].x1, rangeY[0], width, height);
    ctx.moveTo(bottomStart.px, bottomStart.py);
    ctx.lineTo(startPt.px, startPt.py);

    for (let i = 1; i < curvePoints.length; i++) {
      const pt = toCanvas(curvePoints[i].x1, curvePoints[i].y, width, height);
      ctx.lineTo(pt.px, pt.py);
    }
    const endPt = toCanvas(curvePoints[curvePoints.length - 1].x1, rangeY[0], width, height);
    ctx.lineTo(endPt.px, endPt.py);
    ctx.closePath();
    ctx.fillStyle = 'rgba(79, 70, 229, 0.08)'; // Indigo-50
    ctx.fill();

    // Draw main regression step line
    ctx.beginPath();
    ctx.strokeStyle = '#4f46e5'; // Indigo-600
    ctx.lineWidth = 2.5;
    ctx.moveTo(startPt.px, startPt.py);
    for (let i = 1; i < curvePoints.length; i++) {
      const pt = toCanvas(curvePoints[i].x1, curvePoints[i].y, width, height);
      ctx.lineTo(pt.px, pt.py);
    }
    ctx.stroke();

    // 3. Draw Training Points (Dark Blue Circles)
    dataset.trainData.forEach(p => {
      const { px, py } = toCanvas(p.x1, p.y, width, height);
      ctx.beginPath();
      ctx.arc(px, py, 4, 0, Math.PI * 2);
      ctx.fillStyle = '#0284c7'; // Sky-600
      ctx.strokeStyle = '#0369a1';
      ctx.lineWidth = 1;
      ctx.fill();
      ctx.stroke();
    });

    // 4. Draw Test Points (Orange/Amber Diamonds)
    if (showTestData) {
      dataset.testData.forEach(p => {
        const { px, py } = toCanvas(p.x1, p.y, width, height);
        ctx.beginPath();
        const s = 4;
        ctx.moveTo(px, py - s);
        ctx.lineTo(px + s, py);
        ctx.lineTo(px, py + s);
        ctx.lineTo(px - s, py);
        ctx.closePath();
        ctx.fillStyle = '#f59e0b';
        ctx.strokeStyle = '#b45309';
        ctx.lineWidth = 1.2;
        ctx.fill();
        ctx.stroke();
      });
    }

    // 5. Draw Selected Probe Line and Point
    if (selectedProbe) {
      const predY = predictFn(selectedProbe.x1, selectedProbe.x2);
      const pt = toCanvas(selectedProbe.x1, predY, width, height);

      // Vertical guideline
      ctx.setLineDash([4, 4]);
      ctx.strokeStyle = '#dc2626';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(pt.px, padding);
      ctx.lineTo(pt.px, height - padding);
      ctx.stroke();

      // Horizontal guideline
      ctx.beginPath();
      ctx.moveTo(padding, pt.py);
      ctx.lineTo(width - padding, pt.py);
      ctx.stroke();
      ctx.setLineDash([]);

      // Probe indicator
      ctx.beginPath();
      ctx.arc(pt.px, pt.py, 6, 0, Math.PI * 2);
      ctx.fillStyle = '#ef4444';
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2;
      ctx.fill();
      ctx.stroke();
    }
  }, [dataset, predictFn, selectedProbe, showTestData, avgX2, toCanvas, rangeX1, rangeY]);

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const px = ((e.clientX - rect.left) / rect.width) * canvas.width;
    const py = ((e.clientY - rect.top) / rect.height) * canvas.height;

    const coords = fromCanvas(px, py, canvas.width, canvas.height);
    const clampedX1 = Math.max(rangeX1[0], Math.min(rangeX1[1], coords.x1));

    onSelectProbe({
      x1: parseFloat(clampedX1.toFixed(1)),
      x2: parseFloat(avgX2.toFixed(1)),
    });
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const px = ((e.clientX - rect.left) / rect.width) * canvas.width;
    const py = ((e.clientY - rect.top) / rect.height) * canvas.height;

    const coords = fromCanvas(px, py, canvas.width, canvas.height);
    const clampedX1 = Math.max(rangeX1[0], Math.min(rangeX1[1], coords.x1));
    const pred = predictFn(clampedX1, avgX2);

    setHoveredVal({ x1: parseFloat(clampedX1.toFixed(1)), predY: parseFloat(pred.toFixed(1)) });
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4 space-y-3">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-indigo-50 text-indigo-600">
            <LineChart className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-800">
              Curva de Regresión Escalonada f(X)
            </h3>
            <p className="text-xs text-slate-500">
              Observa cómo el árbol divide el espacio en mesetas constantes (promedios por hoja)
            </p>
          </div>
        </div>

        {/* Live probe text */}
        <div className="text-xs font-mono">
          {selectedProbe ? (
            <span className="inline-flex items-center gap-1.5 px-2 py-1 rounded bg-slate-100 text-slate-800 border border-slate-200">
              <Crosshair className="w-3 h-3 text-red-500" />
              {dataset.x1Name}: {selectedProbe.x1} → Predicción:{' '}
              <strong className="text-indigo-600 font-bold">
                {predictFn(selectedProbe.x1, selectedProbe.x2).toFixed(1)} {dataset.yUnit}
              </strong>
            </span>
          ) : (
            <span className="text-slate-400 italic text-[11px]">Haz clic para probar un valor</span>
          )}
        </div>
      </div>

      {/* Canvas */}
      <div className="relative border border-slate-200 rounded-lg overflow-hidden bg-slate-50 flex items-center justify-center">
        <canvas
          id="regression-plot-canvas"
          ref={canvasRef}
          width={520}
          height={340}
          onClick={handleCanvasClick}
          onMouseMove={handleMouseMove}
          onMouseLeave={() => setHoveredVal(null)}
          className="w-full max-w-[520px] aspect-[520/340] cursor-crosshair block"
        />

        {hoveredVal && !selectedProbe && (
          <div className="absolute top-2 right-2 bg-slate-900/90 text-white text-[11px] px-2.5 py-1.5 rounded-lg shadow-md backdrop-blur-sm pointer-events-none border border-slate-700">
            <div>
              {dataset.x1Name}: <span className="font-mono font-bold">{hoveredVal.x1}</span>
            </div>
            <div>
              Predicción ŷ:{' '}
              <span className="font-mono font-bold text-amber-300">
                {hoveredVal.predY} {dataset.yUnit}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Pedagogical footnote */}
      <div className="flex flex-wrap items-center justify-between gap-2 pt-1 text-xs text-slate-600 border-t border-slate-100">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-0.5 bg-indigo-600 inline-block" />
            <span className="text-[11px] font-medium">Predicción Escalonada f(X)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-sky-600 inline-block" />
            <span className="text-[11px]">Train</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rotate-45 bg-amber-500 inline-block" />
            <span className="text-[11px]">Test</span>
          </div>
        </div>

        <div className="flex items-center gap-1 text-[11px] text-amber-800 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
          <Activity className="w-3 h-3 text-amber-600" />
          <span>Hojas pequeñas = picos abruptos (overfitting)</span>
        </div>
      </div>
    </div>
  );
};
