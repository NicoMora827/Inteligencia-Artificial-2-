import React, { useState, useMemo } from 'react';
import { GitFork, ZoomIn, ZoomOut, Maximize2, Sparkles, ArrowDown } from 'lucide-react';
import { TreeNode, PredictionPathStep, TaskType } from '../types/ml';

interface TreeDiagramSvgProps {
  root: TreeNode | null;
  featureNames: [string, string];
  taskType: TaskType;
  classLabels?: [string, string];
  yUnit?: string;
  activePath?: PredictionPathStep[];
}

interface LayoutNode {
  node: TreeNode;
  x: number;
  y: number;
  width: number;
  height: number;
  depth: number;
  isActive: boolean;
  children: LayoutNode[];
}

export const TreeDiagramSvg: React.FC<TreeDiagramSvgProps> = ({
  root,
  featureNames,
  taskType,
  classLabels = ['Clase 0', 'Clase 1'],
  yUnit = '',
  activePath = [],
}) => {
  const [zoomLevel, setZoomLevel] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });

  const activeNodeIds = useMemo(() => {
    return new Set(activePath.map(step => step.nodeId));
  }, [activePath]);

  // Compute hierarchical tree layout
  const { layoutTree, totalWidth, totalHeight } = useMemo(() => {
    if (!root) return { layoutTree: null, totalWidth: 600, totalHeight: 400 };

    const nodeWidth = 148;
    const nodeHeight = 64;
    const verticalGap = 72;
    const horizontalGap = 16;

    // 1. Post-order traversal to calculate required subtree width
    const getSubtreeWidth = (node: TreeNode): number => {
      if (node.isLeaf || !node.left || !node.right) {
        return nodeWidth + horizontalGap;
      }
      const leftW = getSubtreeWidth(node.left);
      const rightW = getSubtreeWidth(node.right);
      return Math.max(nodeWidth + horizontalGap, leftW + rightW);
    };

    // 2. Pre-order traversal to assign (x, y)
    let maxDepth = 0;
    const buildLayout = (node: TreeNode, leftBound: number, width: number, depth: number): LayoutNode => {
      if (depth > maxDepth) maxDepth = depth;
      const x = leftBound + width / 2;
      const y = 40 + depth * (nodeHeight + verticalGap);

      const isActive = activeNodeIds.has(node.id);
      const children: LayoutNode[] = [];

      if (!node.isLeaf && node.left && node.right) {
        const leftW = getSubtreeWidth(node.left);
        const rightW = getSubtreeWidth(node.right);
        const totalChildW = leftW + rightW;

        // Proportional split
        const leftBoxW = (leftW / totalChildW) * width;
        const rightBoxW = (rightW / totalChildW) * width;

        children.push(buildLayout(node.left, leftBound, leftBoxW, depth + 1));
        children.push(buildLayout(node.right, leftBound + leftBoxW, rightBoxW, depth + 1));
      }

      return {
        node,
        x,
        y,
        width: nodeWidth,
        height: nodeHeight,
        depth,
        isActive,
        children,
      };
    };

    const rootSubtreeW = getSubtreeWidth(root);
    const canvasWidth = Math.max(700, rootSubtreeW + 100);
    const layout = buildLayout(root, 50, canvasWidth - 100, 0);
    const canvasHeight = Math.max(380, 70 + (maxDepth + 1) * (nodeHeight + verticalGap));

    return { layoutTree: layout, totalWidth: canvasWidth, totalHeight: canvasHeight };
  }, [root, activeNodeIds]);

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    setPan({
      x: e.clientX - dragStart.x,
      y: e.clientY - dragStart.y,
    });
  };

  const handleMouseUp = () => setIsDragging(false);

  // Render SVG tree recursively
  const renderTreeEdges = (layout: LayoutNode) => {
    return layout.children.map(child => {
      const isBranchActive = layout.isActive && child.isActive;
      const startX = layout.x;
      const startY = layout.y + layout.height / 2;
      const endX = child.x;
      const endY = child.y - child.height / 2;

      // Curved bezier path
      const midY = (startY + endY) / 2;
      const d = `M ${startX} ${startY} C ${startX} ${midY}, ${endX} ${midY}, ${endX} ${endY}`;

      const isLeft = child.x < layout.x;
      const conditionLabel = layout.node.threshold !== null
        ? `${isLeft ? '≤' : '>'} ${layout.node.threshold.toFixed(1)}`
        : '';

      return (
        <g key={`edge-${layout.node.id}-${child.node.id}`}>
          <path
            d={d}
            fill="none"
            stroke={isBranchActive ? '#f59e0b' : '#cbd5e1'}
            strokeWidth={isBranchActive ? 3 : 1.5}
            strokeDasharray={isBranchActive ? undefined : 'none'}
            className="transition-all duration-200"
          />
          {/* Branch text label */}
          <rect
            x={(startX + endX) / 2 - 28}
            y={midY - 8}
            width={56}
            height={16}
            rx={4}
            fill="#ffffff"
            stroke={isBranchActive ? '#f59e0b' : '#e2e8f0'}
            strokeWidth={1}
          />
          <text
            x={(startX + endX) / 2}
            y={midY + 3.5}
            textAnchor="middle"
            fontSize="9"
            fontWeight="bold"
            fill={isBranchActive ? '#b45309' : '#64748b'}
            className="select-none"
          >
            {conditionLabel}
          </text>
          {renderTreeEdges(child)}
        </g>
      );
    });
  };

  const renderTreeNodes = (layout: LayoutNode) => {
    const { node, x, y, width, height, isActive } = layout;
    const isLeaf = node.isLeaf;

    let nodeHeader = '';
    let nodeSub = '';

    if (!isLeaf && node.featureIndex !== null && node.threshold !== null) {
      const featName = featureNames[node.featureIndex] || `X${node.featureIndex + 1}`;
      nodeHeader = `${featName} ≤ ${node.threshold.toFixed(1)}`;
      nodeSub = `Impureza: ${node.impurity.toFixed(2)} | n: ${node.samples}`;
    } else {
      if (taskType === 'classification') {
        const label = classLabels[node.value] || `Clase ${node.value}`;
        const p = node.probabilities ? (node.probabilities[node.value] * 100).toFixed(0) : '100';
        nodeHeader = `🎯 ${label}`;
        nodeSub = `Confianza: ${p}% (n=${node.samples})`;
      } else {
        nodeHeader = `🎯 ŷ = ${node.value.toFixed(1)} ${yUnit}`;
        nodeSub = `MSE: ${node.impurity.toFixed(1)} | n: ${node.samples}`;
      }
    }

    return (
      <g key={`node-${node.id}`}>
        {/* Node container card */}
        <rect
          x={x - width / 2}
          y={y - height / 2}
          width={width}
          height={height}
          rx={8}
          fill={
            isActive
              ? '#fef3c7' // active gold highlight
              : isLeaf
              ? node.value === 1 && taskType === 'classification'
                ? '#fffbeb' // light amber
                : '#f0fdf4' // light emerald
              : '#ffffff'
          }
          stroke={
            isActive
              ? '#f59e0b'
              : isLeaf
              ? node.value === 1 && taskType === 'classification'
                ? '#f59e0b'
                : '#10b981'
              : '#94a3b8'
          }
          strokeWidth={isActive ? 2.5 : 1.2}
          className="filter drop-shadow-sm transition-all duration-200"
        />

        {/* Node ID badge */}
        <rect
          x={x - width / 2 + 6}
          y={y - height / 2 + 5}
          width={18}
          height={14}
          rx={3}
          fill="#f1f5f9"
        />
        <text
          x={x - width / 2 + 15}
          y={y - height / 2 + 15}
          textAnchor="middle"
          fontSize="8"
          fontWeight="bold"
          fill="#64748b"
        >
          #{node.id}
        </text>

        {/* Node Title / Rule */}
        <text
          x={x + 4}
          y={y - height / 2 + 22}
          textAnchor="middle"
          fontSize="11"
          fontWeight="bold"
          fill={isActive ? '#92400e' : '#0f172a'}
          className="select-none"
        >
          {nodeHeader}
        </text>

        {/* Subtitle (Samples, Impurity, Confidence) */}
        <text
          x={x}
          y={y - height / 2 + 40}
          textAnchor="middle"
          fontSize="9.5"
          fill={isActive ? '#b45309' : '#64748b'}
          className="select-none"
        >
          {nodeSub}
        </text>

        {/* Progress or Distribution Bar */}
        {taskType === 'classification' && node.probabilities && (
          <g>
            <rect
              x={x - width / 2 + 12}
              y={y + height / 2 - 12}
              width={width - 24}
              height={5}
              rx={2.5}
              fill="#e0e7ff"
            />
            <rect
              x={x - width / 2 + 12}
              y={y + height / 2 - 12}
              width={(width - 24) * (node.probabilities[1] ?? 0)}
              height={5}
              rx={2.5}
              fill="#f59e0b"
            />
          </g>
        )}

        {layout.children.map(child => renderTreeNodes(child))}
      </g>
    );
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4 space-y-3">
      {/* Header & Zoom Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-indigo-50 text-indigo-600">
            <GitFork className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-800">
              Estructura Jerárquica del Árbol (Diagrama Didáctico)
            </h3>
            <p className="text-xs text-slate-500">
              Inspecciona las preguntas (nodos) y hojas terminales. Arrastra para mover o haz zoom.
            </p>
          </div>
        </div>

        {/* Zoom & Pan Controls */}
        <div className="flex items-center gap-1.5">
          <button
            id="tree-zoom-in-btn"
            onClick={() => setZoomLevel(prev => Math.min(2.0, prev + 0.15))}
            className="p-1.5 text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
            title="Acercar zoom"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
          <button
            id="tree-zoom-out-btn"
            onClick={() => setZoomLevel(prev => Math.max(0.4, prev - 0.15))}
            className="p-1.5 text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
            title="Alejar zoom"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <button
            id="tree-reset-view-btn"
            onClick={() => {
              setZoomLevel(1);
              setPan({ x: 0, y: 0 });
            }}
            className="p-1.5 text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
            title="Restablecer vista"
          >
            <Maximize2 className="w-3.5 h-3.5" />
          </button>
          <span className="text-[11px] font-mono text-slate-500 ml-1">
            {Math.round(zoomLevel * 100)}%
          </span>
        </div>
      </div>

      {/* SVG Canvas Area */}
      <div
        className="relative w-full h-[360px] border border-slate-200 rounded-lg overflow-hidden bg-slate-50/50 cursor-grab active:cursor-grabbing select-none"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      >
        <svg
          id="decision-tree-svg"
          width="100%"
          height="100%"
          viewBox={`0 0 ${totalWidth} ${totalHeight}`}
          className="w-full h-full"
        >
          <g transform={`translate(${pan.x}, ${pan.y}) scale(${zoomLevel})`}>
            {layoutTree && (
              <>
                {renderTreeEdges(layoutTree)}
                {renderTreeNodes(layoutTree)}
              </>
            )}
          </g>
        </svg>

        {/* Active Path Notification Badge */}
        {activePath.length > 0 && (
          <div className="absolute bottom-2 left-2 bg-amber-500/90 text-slate-900 text-xs font-semibold px-3 py-1 rounded-full shadow-md backdrop-blur-sm flex items-center gap-1.5 border border-amber-400">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Ruta activa resaltada en dorado ({activePath.length} pasos)</span>
          </div>
        )}
      </div>

      {/* Traversal Step-by-Step Path Detail */}
      {activePath.length > 0 && (
        <div className="p-3 rounded-lg bg-amber-50/70 border border-amber-200 text-xs space-y-1.5">
          <div className="font-bold text-amber-900 flex items-center gap-1.5">
            <ArrowDown className="w-3.5 h-3.5 text-amber-600" />
            <span>Explicación Paso a Paso de la Inferencia:</span>
          </div>
          <div className="space-y-1">
            {activePath.map((step, idx) => (
              <div key={idx} className="flex items-start gap-2 text-slate-700">
                <span className="font-mono font-bold text-amber-700">#{idx + 1}.</span>
                <span>{step.comparisonText}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
