import { Dataset, DataPoint } from '../types/ml';

// Pseudo-random generator with seed for reproducible datasets
function createRng(seed: number) {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

function gaussianRandom(rng: () => number, mean = 0, stdev = 1): number {
  const u = 1 - rng();
  const v = rng();
  const z = Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
  return z * stdev + mean;
}

// 1. Cardiovascular Risk Diagnostic (Classification)
export function generateHeartDiseaseDataset(seed = 42): Dataset {
  const rng = createRng(seed);
  const total = 160;
  const points: DataPoint[] = [];

  for (let i = 0; i < total; i++) {
    const isTest = i >= 110;
    // Age: 25 to 80
    const age = 25 + rng() * 55;
    // Cholesterol / Blood pressure indicator: 130 to 310
    const cholesterol = 130 + rng() * 170;

    // Realistic non-linear cardiac risk function
    // Risk increases significantly with age > 50 and cholesterol > 210, plus diagonal interaction
    const normalizedAge = (age - 25) / 55; // 0 to 1
    const normalizedChol = (cholesterol - 130) / 170; // 0 to 1

    const riskScore = 0.55 * normalizedAge + 0.5 * normalizedChol + (normalizedAge * normalizedChol) * 0.4;
    // Add realistic physiological noise
    const noise = gaussianRandom(rng, 0, 0.14);
    const y = (riskScore + noise > 0.65) ? 1 : 0;

    points.push({
      id: i,
      x1: parseFloat(age.toFixed(1)),
      x2: parseFloat(cholesterol.toFixed(1)),
      y,
      isTest,
    });
  }

  const trainData = points.filter(p => !p.isTest);
  const testData = points.filter(p => p.isTest);

  return {
    name: 'Diagnóstico de Riesgo Cardiovascular',
    taskType: 'classification',
    description: 'Predice si un paciente tiene Alto Riesgo (1) o Bajo Riesgo (0) según su Edad y Nivel de Colesterol. Demuestra cómo árboles muy profundos crean reglas absurdas para aislar pacientes ruidosos.',
    x1Name: 'Edad',
    x2Name: 'Colesterol / Presión',
    yName: 'Riesgo Cardíaco',
    x1Unit: 'años',
    x2Unit: 'mg/dL',
    classLabels: ['Bajo Riesgo', 'Alto Riesgo'],
    trainData,
    testData,
  };
}

// 2. Bank Credit Approval (Classification)
export function generateCreditApprovalDataset(seed = 101): Dataset {
  const rng = createRng(seed);
  const total = 160;
  const points: DataPoint[] = [];

  for (let i = 0; i < total; i++) {
    const isTest = i >= 110;
    // Annual Income: $15k to $120k
    const income = 15 + rng() * 100;
    // Debt-to-Income ratio: 5% to 65%
    const debtRatio = 5 + rng() * 55;

    // Credit approved if high income and low debt, with step-like requirements
    const cond1 = income > 45 && debtRatio < 40;
    const cond2 = income > 75 && debtRatio < 52;
    const baseProb = (cond1 || cond2) ? 0.85 : 0.15;
    const y = (rng() < baseProb) ? 1 : 0;

    points.push({
      id: i,
      x1: parseFloat(income.toFixed(1)),
      x2: parseFloat(debtRatio.toFixed(1)),
      y,
      isTest,
    });
  }

  return {
    name: 'Aprobación de Crédito Bancario',
    taskType: 'classification',
    description: 'Evalúa la aprobación de un crédito según Ingresos Anuales y Ratio de Endeudamiento. Ideal para ver cómo los árboles particionan el espacio en cajas rectangulares.',
    x1Name: 'Ingresos Anuales',
    x2Name: 'Ratio de Deuda',
    yName: 'Aprobación',
    x1Unit: 'k$',
    x2Unit: '%',
    classLabels: ['Denegado', 'Aprobado'],
    trainData: points.filter(p => !p.isTest),
    testData: points.filter(p => p.isTest),
  };
}

// 3. House Price Valuation (Regression)
export function generateHousePricesDataset(seed = 77): Dataset {
  const rng = createRng(seed);
  const total = 150;
  const points: DataPoint[] = [];

  for (let i = 0; i < total; i++) {
    const isTest = i >= 105;
    // Area: 40 to 240 m2
    const area = 40 + rng() * 200;
    // Distance to city center: 1 to 25 km
    const distance = 1 + rng() * 24;

    // Price model: base price + area factor - distance penalty + non-linear interaction
    // Values in thousands of USD ($k)
    const basePrice = 60;
    const areaEffect = (area / 10) * 12.5; // ~1.25k per m2
    const distEffect = Math.max(0, (25 - distance) * 4.2);
    const noise = gaussianRandom(rng, 0, 18);

    const price = Math.max(40, basePrice + areaEffect + distEffect + noise);

    points.push({
      id: i,
      x1: parseFloat(area.toFixed(1)),
      x2: parseFloat(distance.toFixed(1)),
      y: parseFloat(price.toFixed(1)),
      isTest,
    });
  }

  return {
    name: 'Valoración Inmobiliaria (Precios de Viviendas)',
    taskType: 'regression',
    description: 'Predice el valor comercial en miles de dólares ($k) a partir de los metros cuadrados y la cercanía al centro. Observa cómo el árbol de regresión aproxima una superficie continua mediante promedios por intervalos discretos.',
    x1Name: 'Superficie',
    x2Name: 'Distancia al Centro',
    yName: 'Precio de Venta',
    x1Unit: 'm²',
    x2Unit: 'km',
    yUnit: 'k$',
    trainData: points.filter(p => !p.isTest),
    testData: points.filter(p => p.isTest),
  };
}

// 4. Energy Consumption (Non-linear U-Shape Regression)
export function generateEnergyConsumptionDataset(seed = 88): Dataset {
  const rng = createRng(seed);
  const total = 150;
  const points: DataPoint[] = [];

  for (let i = 0; i < total; i++) {
    const isTest = i >= 105;
    // Outdoor Temperature: -5°C to 38°C
    const temp = -5 + rng() * 43;
    // Household Occupancy: 1 to 6 people
    const occupancy = Math.floor(1 + rng() * 5.9);

    // Quadratic thermal demand (U-shape): cold needs heating, hot needs AC
    const optimalTemp = 20; // 20°C is comfortable
    const tempDelta = Math.abs(temp - optimalTemp);
    const thermalLoad = 0.45 * Math.pow(tempDelta, 1.7);
    const occupancyLoad = occupancy * 3.8;
    const noise = gaussianRandom(rng, 0, 2.5);

    const consumptionKwh = Math.max(5, 8 + thermalLoad + occupancyLoad + noise);

    points.push({
      id: i,
      x1: parseFloat(temp.toFixed(1)),
      x2: parseFloat(occupancy.toFixed(0)),
      y: parseFloat(consumptionKwh.toFixed(1)),
      isTest,
    });
  }

  return {
    name: 'Consumo Eléctrico Residencial',
    taskType: 'regression',
    description: 'Predice el consumo en kWh según la Temperatura Exterior (°C) y Personas en el Hogar. Muestra la capacidad del árbol para aproximar funciones en forma de U sin requerir transformaciones polinómicas.',
    x1Name: 'Temperatura Exterior',
    x2Name: 'Personas en el Hogar',
    yName: 'Consumo Eléctrico',
    x1Unit: '°C',
    x2Unit: 'personas',
    yUnit: 'kWh',
    trainData: points.filter(p => !p.isTest),
    testData: points.filter(p => p.isTest),
  };
}

// 5. Fraud Detection Complex Pattern (Random Forest Showcase)
export function generateFraudDetectionDataset(seed = 123): Dataset {
  const rng = createRng(seed);
  const total = 180;
  const points: DataPoint[] = [];

  for (let i = 0; i < total; i++) {
    const isTest = i >= 120;
    // Transaction Amount: $5 to $1000
    const amount = 5 + rng() * 995;
    // Unusual Velocity/Frequency Index: 0 to 100
    const velocity = rng() * 100;

    // Island-like fraud behavior: high amount + high velocity OR strange medium-amount micro-bursts
    const island1 = (amount > 650 && velocity > 50);
    const island2 = (amount > 150 && amount < 400 && velocity > 75);
    const island3 = (amount > 850 && velocity < 20); // atypical high-roller fraud

    let isFraud = island1 || island2 || island3;
    // add realistic false positives/negatives noise
    if (rng() < 0.08) {
      isFraud = !isFraud;
    }

    points.push({
      id: i,
      x1: parseFloat(amount.toFixed(0)),
      x2: parseFloat(velocity.toFixed(1)),
      y: isFraud ? 1 : 0,
      isTest,
    });
  }

  return {
    name: 'Detección de Fraude en Transacciones',
    taskType: 'classification',
    description: 'Clasifica transacciones sospechosas (1) vs legítimas (0). Caso perfecto para comparar cómo un Árbol Individual sobreajusta aislando puntos aislados con bordes bruscos, mientras Random Forest promedia los árboles reduciendo el error y suavizando la frontera.',
    x1Name: 'Monto Transacción',
    x2Name: 'Índice de Velocidad / Frecuencia',
    yName: 'Fraude',
    x1Unit: '$',
    x2Unit: 'pts',
    classLabels: ['Legítima', 'Fraude'],
    trainData: points.filter(p => !p.isTest),
    testData: points.filter(p => p.isTest),
  };
}
