import {
  DataPoint,
  Hyperparameters,
  TreeNode,
  PredictionResult,
  PredictionPathStep,
  ClassificationMetrics,
  RegressionMetrics,
  TaskType,
  TreeStats
} from '../types/ml';

interface BestSplit {
  featureIndex: number;
  threshold: number;
  impurityReduction: number;
  leftPoints: DataPoint[];
  rightPoints: DataPoint[];
}

// Compute Gini Impurity for binary classification
export function computeGini(points: DataPoint[]): number {
  if (points.length === 0) return 0;
  const count1 = points.filter(p => p.y === 1).length;
  const p1 = count1 / points.length;
  const p0 = 1 - p1;
  return 1 - (p0 * p0 + p1 * p1);
}

// Compute Entropy for binary classification
export function computeEntropy(points: DataPoint[]): number {
  if (points.length === 0) return 0;
  const count1 = points.filter(p => p.y === 1).length;
  const p1 = count1 / points.length;
  const p0 = 1 - p1;
  if (p0 <= 0 || p1 <= 0) return 0;
  return -(p0 * Math.log2(p0) + p1 * Math.log2(p1));
}

// Compute MSE for regression
export function computeMSE(points: DataPoint[]): number {
  if (points.length === 0) return 0;
  const mean = points.reduce((acc, p) => acc + p.y, 0) / points.length;
  return points.reduce((acc, p) => acc + Math.pow(p.y - mean, 2), 0) / points.length;
}

// Compute MAE for regression
export function computeMAE(points: DataPoint[]): number {
  if (points.length === 0) return 0;
  const sorted = [...points].sort((a, b) => a.y - b.y);
  const median = sorted[Math.floor(sorted.length / 2)].y;
  return points.reduce((acc, p) => acc + Math.abs(p.y - median), 0) / points.length;
}

export function computeImpurity(points: DataPoint[], taskType: TaskType, criterion: string): number {
  if (taskType === 'classification') {
    return criterion === 'entropy' ? computeEntropy(points) : computeGini(points);
  } else {
    return criterion === 'mae' ? computeMAE(points) : computeMSE(points);
  }
}

export class DecisionTree {
  root: TreeNode | null = null;
  taskType: TaskType;
  params: Hyperparameters;
  private nodeIdCounter = 0;

  constructor(taskType: TaskType, params: Hyperparameters) {
    this.taskType = taskType;
    this.params = params;
  }

  fit(data: DataPoint[], featureIndicesAllowed: number[] = [0, 1]): void {
    this.nodeIdCounter = 0;
    this.root = this.buildNode(data, 0, featureIndicesAllowed);
  }

  private buildNode(
    points: DataPoint[],
    currentDepth: number,
    featureIndicesAllowed: number[]
  ): TreeNode {
    const nodeId = this.nodeIdCounter++;
    const numSamples = points.length;

    // Calculate node prediction value and impurities
    let nodeValue: number;
    let probabilities: number[] | undefined;

    if (this.taskType === 'classification') {
      const count1 = points.filter(p => p.y === 1).length;
      const p1 = numSamples > 0 ? count1 / numSamples : 0;
      const p0 = 1 - p1;
      probabilities = [p0, p1];
      nodeValue = p1 >= 0.5 ? 1 : 0;
    } else {
      nodeValue = numSamples > 0
        ? points.reduce((acc, p) => acc + p.y, 0) / numSamples
        : 0;
    }

    const currentImpurity = computeImpurity(points, this.taskType, this.params.criterion);

    // Check stopping criteria:
    // 1. Max depth reached
    // 2. Minimum samples to split not met
    // 3. Pure node (impurity ~ 0)
    // 4. No points left
    const isPure = currentImpurity <= 0.0001;
    const canSplit =
      currentDepth < this.params.maxDepth &&
      numSamples >= this.params.minSamplesSplit &&
      !isPure;

    if (!canSplit) {
      return {
        id: nodeId,
        featureIndex: null,
        threshold: null,
        left: null,
        right: null,
        isLeaf: true,
        samples: numSamples,
        value: nodeValue,
        probabilities,
        impurity: currentImpurity,
        depth: currentDepth,
      };
    }

    // Find best split
    const bestSplit = this.findBestSplit(points, featureIndicesAllowed);

    if (!bestSplit || bestSplit.impurityReduction <= 0) {
      return {
        id: nodeId,
        featureIndex: null,
        threshold: null,
        left: null,
        right: null,
        isLeaf: true,
        samples: numSamples,
        value: nodeValue,
        probabilities,
        impurity: currentImpurity,
        depth: currentDepth,
      };
    }

    // Build left and right children recursively
    const leftChild = this.buildNode(bestSplit.leftPoints, currentDepth + 1, featureIndicesAllowed);
    const rightChild = this.buildNode(bestSplit.rightPoints, currentDepth + 1, featureIndicesAllowed);

    return {
      id: nodeId,
      featureIndex: bestSplit.featureIndex,
      threshold: bestSplit.threshold,
      left: leftChild,
      right: rightChild,
      isLeaf: false,
      samples: numSamples,
      value: nodeValue,
      probabilities,
      impurity: currentImpurity,
      depth: currentDepth,
    };
  }

  private findBestSplit(points: DataPoint[], featureIndices: number[]): BestSplit | null {
    let bestSplit: BestSplit | null = null;
    let maxGain = -1;
    const n = points.length;
    const baseImpurity = computeImpurity(points, this.taskType, this.params.criterion);

    for (const featureIndex of featureIndices) {
      // Sort points by feature value
      const sorted = [...points].sort((a, b) => {
        const valA = featureIndex === 0 ? a.x1 : a.x2;
        const valB = featureIndex === 0 ? b.x1 : b.x2;
        return valA - valB;
      });

      // Try candidate thresholds between adjacent unique values
      for (let i = 0; i < sorted.length - 1; i++) {
        const val1 = featureIndex === 0 ? sorted[i].x1 : sorted[i].x2;
        const val2 = featureIndex === 0 ? sorted[i + 1].x1 : sorted[i + 1].x2;

        if (Math.abs(val1 - val2) < 1e-6) continue;

        const candidateThreshold = (val1 + val2) / 2;

        const leftPoints = sorted.slice(0, i + 1);
        const rightPoints = sorted.slice(i + 1);

        // Check min_samples_leaf constraint
        if (
          leftPoints.length < this.params.minSamplesLeaf ||
          rightPoints.length < this.params.minSamplesLeaf
        ) {
          continue;
        }

        const leftImp = computeImpurity(leftPoints, this.taskType, this.params.criterion);
        const rightImp = computeImpurity(rightPoints, this.taskType, this.params.criterion);

        const weightedChildImpurity =
          (leftPoints.length / n) * leftImp + (rightPoints.length / n) * rightImp;

        const gain = baseImpurity - weightedChildImpurity;

        if (gain > maxGain) {
          maxGain = gain;
          bestSplit = {
            featureIndex,
            threshold: candidateThreshold,
            impurityReduction: gain,
            leftPoints,
            rightPoints,
          };
        }
      }
    }

    return bestSplit;
  }

  predictPoint(x1: number, x2: number): number {
    if (!this.root) return 0;
    let curr = this.root;
    while (!curr.isLeaf) {
      const val = curr.featureIndex === 0 ? x1 : x2;
      if (curr.threshold !== null && val <= curr.threshold) {
        if (!curr.left) break;
        curr = curr.left;
      } else {
        if (!curr.right) break;
        curr = curr.right;
      }
    }
    return curr.value;
  }

  predictPointWithTrace(
    x1: number,
    x2: number,
    featureNames: [string, string] = ['X1', 'X2']
  ): PredictionResult {
    const path: PredictionPathStep[] = [];
    if (!this.root) {
      return { predictedValue: 0, path, leafNodeId: -1 };
    }

    let curr: TreeNode = this.root;
    while (!curr.isLeaf) {
      const fIdx = curr.featureIndex ?? 0;
      const featureName = featureNames[fIdx];
      const sampleVal = fIdx === 0 ? x1 : x2;
      const threshold = curr.threshold ?? 0;

      if (sampleVal <= threshold) {
        path.push({
          nodeId: curr.id,
          depth: curr.depth,
          featureName,
          threshold,
          sampleValue: sampleVal,
          decision: 'left',
          comparisonText: `${featureName} (${sampleVal.toFixed(1)}) ≤ ${threshold.toFixed(1)} → Rama Izquierda`,
        });
        if (!curr.left) break;
        curr = curr.left;
      } else {
        path.push({
          nodeId: curr.id,
          depth: curr.depth,
          featureName,
          threshold,
          sampleValue: sampleVal,
          decision: 'right',
          comparisonText: `${featureName} (${sampleVal.toFixed(1)}) > ${threshold.toFixed(1)} → Rama Derecha`,
        });
        if (!curr.right) break;
        curr = curr.right;
      }
    }

    // Leaf reached
    path.push({
      nodeId: curr.id,
      depth: curr.depth,
      featureName: 'Hoja Final',
      threshold: 0,
      sampleValue: 0,
      decision: 'leaf',
      comparisonText: `Nodo Hoja #${curr.id}: Predicción = ${
        this.taskType === 'classification'
          ? `Clase ${curr.value} (p=${(curr.probabilities?.[curr.value] ?? 1).toFixed(2)})`
          : curr.value.toFixed(1)
      } con ${curr.samples} muestras.`,
    });

    return {
      predictedValue: curr.value,
      probabilities: curr.probabilities,
      path,
      leafNodeId: curr.id,
    };
  }

  getTreeStats(): TreeStats {
    let totalNodes = 0;
    let leafCount = 0;
    let actualMaxDepth = 0;

    const traverse = (node: TreeNode | null) => {
      if (!node) return;
      totalNodes++;
      if (node.depth > actualMaxDepth) actualMaxDepth = node.depth;
      if (node.isLeaf) {
        leafCount++;
      } else {
        traverse(node.left);
        traverse(node.right);
      }
    };

    traverse(this.root);
    return { totalNodes, leafCount, actualMaxDepth };
  }
}

// Compute classification metrics
export function evaluateClassification(
  tree: DecisionTree,
  trainData: DataPoint[],
  testData: DataPoint[]
): ClassificationMetrics {
  const calcAcc = (dataset: DataPoint[]) => {
    if (dataset.length === 0) return { acc: 0, f1: 0, tn: 0, fp: 0, fn: 0, tp: 0 };
    let correct = 0;
    let tn = 0, fp = 0, fn = 0, tp = 0;

    for (const p of dataset) {
      const pred = tree.predictPoint(p.x1, p.x2);
      if (pred === p.y) correct++;
      if (p.y === 1 && pred === 1) tp++;
      if (p.y === 0 && pred === 0) tn++;
      if (p.y === 0 && pred === 1) fp++;
      if (p.y === 1 && pred === 0) fn++;
    }

    const acc = correct / dataset.length;
    const precision = tp + fp > 0 ? tp / (tp + fp) : 0;
    const recall = tp + fn > 0 ? tp / (tp + fn) : 0;
    const f1 = precision + recall > 0 ? (2 * precision * recall) / (precision + recall) : 0;

    return { acc, f1, tn, fp, fn, tp };
  };

  const trainRes = calcAcc(trainData);
  const testRes = calcAcc(testData);

  return {
    trainAccuracy: trainRes.acc,
    testAccuracy: testRes.acc,
    trainF1: trainRes.f1,
    testF1: testRes.f1,
    trainLoss: 1 - trainRes.acc,
    testLoss: 1 - testRes.acc,
    confusionMatrix: {
      tn: testRes.tn,
      fp: testRes.fp,
      fn: testRes.fn,
      tp: testRes.tp,
    },
  };
}

// Compute regression metrics (R2, RMSE, MAE)
export function evaluateRegression(
  tree: DecisionTree,
  trainData: DataPoint[],
  testData: DataPoint[]
): RegressionMetrics {
  const calcMetrics = (dataset: DataPoint[]) => {
    if (dataset.length === 0) return { r2: 0, rmse: 0, mae: 0 };
    const n = dataset.length;
    const meanY = dataset.reduce((acc, p) => acc + p.y, 0) / n;

    let ssTot = 0;
    let ssRes = 0;
    let sumAbsErr = 0;

    for (const p of dataset) {
      const pred = tree.predictPoint(p.x1, p.x2);
      const diff = p.y - pred;
      ssRes += diff * diff;
      ssTot += Math.pow(p.y - meanY, 2);
      sumAbsErr += Math.abs(diff);
    }

    const r2 = ssTot > 0 ? Math.max(-1, 1 - ssRes / ssTot) : 0;
    const rmse = Math.sqrt(ssRes / n);
    const mae = sumAbsErr / n;

    return { r2, rmse, mae };
  };

  const train = calcMetrics(trainData);
  const test = calcMetrics(testData);

  return {
    trainR2: train.r2,
    testR2: test.r2,
    trainRmse: train.rmse,
    testRmse: test.rmse,
    trainMae: train.mae,
    testMae: test.mae,
  };
}
