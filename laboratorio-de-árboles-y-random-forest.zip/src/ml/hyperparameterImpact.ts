import { ModelDiagnostics, Hyperparameters, TaskType } from '../types/ml';

export interface HyperparameterDoc {
  key: keyof Hyperparameters;
  name: string;
  category: 'complexity' | 'variance' | 'criterion';
  categoryLabel: string;
  shortExplanation: string;
  increasingEffect: string;
  decreasingEffect: string;
  practicalTip: string;
  impactLevel: 'Alto' | 'Medio' | 'Crítico';
}

export const HYPERPARAMETER_CATALOG: Record<string, HyperparameterDoc> = {
  maxDepth: {
    key: 'maxDepth',
    name: 'Profundidad Máxima (max_depth)',
    category: 'complexity',
    categoryLabel: 'Control de Complejidad (Sesgo/Varianza)',
    impactLevel: 'Crítico',
    shortExplanation: 'Determina cuántos niveles de preguntas (bifurcaciones) consecutivas puede tener el árbol.',
    increasingEffect: 'Aumenta la flexibilidad del árbol para capturar patrones intrincados, pero eleva bruscamente el riesgo de SOBREAJUSTE (memorizar ruido).',
    decreasingEffect: 'Simplifica la estructura obligando al modelo a aprender solo las reglas generales, pero si es demasiado bajo provocará SUBAJUSTE (modelo ciego a matices).',
    practicalTip: 'En árboles de decisión suele fijarse entre 3 y 6 para evitar sobreajuste. En Random Forest puede ser algo mayor gracias al promediado de múltiples árboles.',
  },
  minSamplesSplit: {
    key: 'minSamplesSplit',
    name: 'Muestras Mínimas para Dividir (min_samples_split)',
    category: 'complexity',
    categoryLabel: 'Poda Previa (Pre-pruning)',
    impactLevel: 'Alto',
    shortExplanation: 'El número mínimo de observaciones que debe contener un nodo para que se le permita crear nuevas ramas hijas.',
    increasingEffect: 'Frena el crecimiento prematuro en grupos pequeños, forzando al árbol a ser más conservador y regularizado.',
    decreasingEffect: 'Permite bifurcar nodos con muy pocas muestras (hasta 2), creando micro-reglas específicas y aumentando la varianza.',
    practicalTip: 'Un valor entre 5 y 20 previene que el árbol divida un nodo solo para aislar 1 o 2 observaciones atípicas (outliers).',
  },
  minSamplesLeaf: {
    key: 'minSamplesLeaf',
    name: 'Muestras Mínimas por Hoja (min_samples_leaf)',
    category: 'complexity',
    categoryLabel: 'Regularización / Estabilidad',
    impactLevel: 'Crítico',
    shortExplanation: 'El número mínimo de datos que debe albergar obligatoriamente cada nodo terminal (hoja final de decisión).',
    increasingEffect: 'Suaviza fuertemente el modelo; en regresión garantiza que cada predicción sea el promedio de un grupo representativo y no de un valor aislado.',
    decreasingEffect: 'Permite hojas con solo 1 muestra (hojas singleton), lo que conduce a escalones bruscos en regresión y sobreajuste extremo en clasificación.',
    practicalTip: 'Uno de los hiperparámetros más eficaces para combatir el ruido. Subir este valor de 1 a 4 o 8 elimina casi todo el sobreajuste.',
  },
  criterion: {
    key: 'criterion',
    name: 'Criterio de División (criterion)',
    category: 'criterion',
    categoryLabel: 'Función de Pérdida / Pureza',
    impactLevel: 'Medio',
    shortExplanation: 'La fórmula matemática utilizada para medir la "impureza" de un grupo y decidir el corte que mejor separa los datos.',
    increasingEffect: 'Gini es computacionalmente más rápido y favorece particiones que aíslan la clase mayoritaria. Entropía penaliza más severamente la dispersión.',
    decreasingEffect: 'En regresión, MSE castiga cuadráticamente los errores grandes (sensible a outliers); MAE minimiza el error absoluto y es más robusto ante datos extremos.',
    practicalTip: 'En la práctica Gini y Entropía dan resultados similares el 95% de las veces. En regresión, usa MAE si tienes valores atípicos y MSE para penalizar desviaciones grandes.',
  },
  nEstimators: {
    key: 'nEstimators',
    name: 'Número de Árboles (n_estimators)',
    category: 'variance',
    categoryLabel: 'Reducción de Varianza (Ensamble)',
    impactLevel: 'Crítico',
    shortExplanation: 'Cantidad total de árboles individuales independientes entrenados en el Random Forest.',
    increasingEffect: 'Reduce la varianza global por la Ley de los Grandes Números, estabiliza las predicciones y no sobreajusta (llega a una meseta de rendimiento óptimo).',
    decreasingEffect: 'Con muy pocos árboles (1 a 5), el bosque pierde el beneficio del ensamble y hereda la inestabilidad de un árbol individual.',
    practicalTip: 'A diferencia de max_depth, aumentar n_estimators NUNCA causa sobreajuste, solo aumenta el costo computacional. Entre 20 y 100 suele ser excelente.',
  },
  maxFeatures: {
    key: 'maxFeatures',
    name: 'Variables por División (max_features)',
    category: 'variance',
    categoryLabel: 'Descorrelación de Árboles',
    impactLevel: 'Alto',
    shortExplanation: 'Cuántas variables aleatorias se consideran como candidatas para buscar la mejor división en cada nodo.',
    increasingEffect: 'Si se usan todas (all), los árboles individuales tienden a parecerse entre sí (árboles correlacionados), reduciendo el beneficio del bosque.',
    decreasingEffect: 'Al forzar a considerar un subconjunto aleatorio (sqrt o 1), los árboles aprenden perspectivas distintas y diversas, mejorando el consenso.',
    practicalTip: 'Para clasificación la regla estándar es raíz cuadrada (sqrt) del total de variables. Para regresión suele ser un tercio o todas.',
  },
  bootstrap: {
    key: 'bootstrap',
    name: 'Muestreo con Reemplazo (bootstrap)',
    category: 'variance',
    categoryLabel: 'Inyección de Diversidad',
    impactLevel: 'Alto',
    shortExplanation: 'Si es True, cada árbol se entrena con un subconjunto de datos muestreado al azar con reemplazo (~63.2% de datos únicos).',
    increasingEffect: 'Inyecta variabilidad entre árboles y deja datos fuera de la bolsa ("Out-of-Bag") para validar el modelo sin necesidad de conjunto de validación externo.',
    decreasingEffect: 'Si es False, cada árbol recibe exactamente los mismos datos originales, lo cual reduce la diversidad del bosque.',
    practicalTip: 'Mantén siempre bootstrap = True en Random Forest salvo que el conjunto de datos sea diminuto.',
  },
};

export function diagnoseModelFit(
  taskType: TaskType,
  trainScore: number, // Accuracy (0 to 1) or R2 (can be negative or up to 1)
  testScore: number,
  params: Hyperparameters
): ModelDiagnostics {
  // Normalize R2 for sanity
  const normTrain = taskType === 'classification' ? trainScore : Math.max(0, trainScore);
  const normTest = taskType === 'classification' ? testScore : Math.max(0, testScore);

  const gap = normTrain - normTest;

  // Calculate complexity heuristic (0 to 100)
  const depthFactor = Math.min(1, params.maxDepth / 8) * 50;
  const leafFactor = Math.max(0, (1 - (params.minSamplesLeaf - 1) / 10)) * 30;
  const splitFactor = Math.max(0, (1 - (params.minSamplesSplit - 2) / 15)) * 20;
  const complexityScore = Math.round(depthFactor + leafFactor + splitFactor);

  // Underfitting: both scores are low
  if (normTrain < 0.70 && normTest < 0.70) {
    return {
      status: 'underfitting',
      statusLabel: 'Subajuste (Underfitting / Alto Sesgo)',
      statusColor: 'amber',
      complexityScore,
      explanation:
        'El modelo es demasiado simple y rígido. No logra capturar las relaciones reales en los datos, obteniendo bajo rendimiento tanto en entrenamiento como en prueba.',
      recommendedAction:
        params.maxDepth <= 2
          ? 'Acción didáctica: Incrementa la Profundidad Máxima (max_depth) para permitirle al árbol formular más reglas de decisión.'
          : 'Acción didáctica: Reduce min_samples_leaf o min_samples_split para no asfixiar el crecimiento de ramas informativas.',
    };
  }

  // Overfitting: train score is very high, but test score is significantly lower
  if (gap >= 0.12 && normTrain >= 0.85) {
    return {
      status: 'overfitting',
      statusLabel: 'Sobreajuste (Overfitting / Alta Varianza)',
      statusColor: 'rose',
      complexityScore,
      explanation: `El modelo memorizó los datos de entrenamiento (rendimiento ${(normTrain * 100).toFixed(0)}%), pero al evaluar datos nuevos cae a ${(normTest * 100).toFixed(0)}% (brecha de ${(gap * 100).toFixed(0)}%). Ha aprendido el ruido y casos atípicos.`,
      recommendedAction:
        params.maxDepth >= 5
          ? 'Acción didáctica: Reduce max_depth (p. ej. a 3 o 4) y aumenta min_samples_leaf (p. ej. a 5) para forzar al modelo a buscar reglas robustas y generales.'
          : 'Acción didáctica: Aumenta min_samples_leaf para evitar hojas con muy pocas muestras.',
    };
  }

  // Balanced / Optimal
  return {
    status: 'optimal',
    statusLabel: 'Equilibrio Óptimo (Generalización Robusta)',
    statusColor: 'emerald',
    complexityScore,
    explanation: `Excelente balance entre sesgo y varianza. El modelo obtiene un rendimiento consistente entre entrenamiento (${(normTrain * 100).toFixed(0)}%) y prueba (${(normTest * 100).toFixed(0)}%), demostrando que generaliza adecuadamente ante datos no vistos.`,
    recommendedAction:
      '¡Felicidades! Has encontrado una zona de hiperparámetros equilibrada. Puedes comparar ahora este comportamiento con Random Forest para ver cómo el ensamble estabiliza aún más la frontera.',
  };
}
