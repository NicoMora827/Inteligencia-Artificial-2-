import {
  DataPoint,
  Hyperparameters,
  TaskType,
  ClassificationMetrics,
  RegressionMetrics,
  EnsembleTreeSummary,
} from '../types/ml';
import { DecisionTree } from './decisionTree';

// Simple PRNG helper for reproducible bagging
function seededRng(seed: number) {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

export class RandomForest {
  trees: DecisionTree[] = [];
  taskType: TaskType;
  params: Hyperparameters;
  oobScore: number = 0;
  featureImportances: [number, number] = [0.5, 0.5]; // [x1Importance, x2Importance]

  constructor(taskType: TaskType, params: Hyperparameters) {
    this.taskType = taskType;
    this.params = params;
  }

  fit(data: DataPoint[]): void {
    this.trees = [];
    const n = data.length;
    if (n === 0) return;

    const rng = seededRng(42 + this.params.nEstimators);
    // Track out-of-bag predictions: map dataPoint id -> array of predictions from trees that didn't see it
    const oobPredictions: Map<number, number[]> = new Map();
    data.forEach(p => oobPredictions.set(p.id, []));

    const totalFeatures = 2;
    let featCount = 2;
    if (this.params.maxFeatures === 'sqrt') {
      featCount = Math.max(1, Math.round(Math.sqrt(totalFeatures))); // 1 or 2
    } else if (typeof this.params.maxFeatures === 'number') {
      featCount = Math.min(totalFeatures, Math.max(1, this.params.maxFeatures));
    }

    let x1ImpurityGainTotal = 0;
    let x2ImpurityGainTotal = 0;

    for (let t = 0; t < this.params.nEstimators; t++) {
      // 1. Bootstrap sampling (with replacement) or full sample
      const sampledIndices: number[] = [];
      const inBagSet = new Set<number>();

      if (this.params.bootstrap) {
        for (let i = 0; i < n; i++) {
          const randIdx = Math.floor(rng() * n);
          sampledIndices.push(randIdx);
          inBagSet.add(data[randIdx].id);
        }
      } else {
        for (let i = 0; i < n; i++) {
          sampledIndices.push(i);
          inBagSet.add(data[i].id);
        }
      }

      const trainBag = sampledIndices.map(idx => data[idx]);

      // 2. Feature selection
      let allowedFeatures = [0, 1];
      if (featCount === 1) {
        // Randomly pick feature 0 or 1
        allowedFeatures = rng() < 0.5 ? [0] : [1];
      }

      // Create tree
      const tree = new DecisionTree(this.taskType, {
        ...this.params,
      });

      tree.fit(trainBag, allowedFeatures);
      this.trees.push(tree);

      // Collect tree feature gains for feature importance
      const collectGains = (node: typeof tree.root) => {
        if (!node || node.isLeaf) return;
        const leftCount = node.left ? node.left.samples : 0;
        const rightCount = node.right ? node.right.samples : 0;
        const total = node.samples;
        const leftImp = node.left ? node.left.impurity : 0;
        const rightImp = node.right ? node.right.impurity : 0;

        const gain = node.impurity - ((leftCount / total) * leftImp + (rightCount / total) * rightImp);
        if (gain > 0) {
          if (node.featureIndex === 0) x1ImpurityGainTotal += gain * total;
          if (node.featureIndex === 1) x2ImpurityGainTotal += gain * total;
        }
        collectGains(node.left);
        collectGains(node.right);
      };
      collectGains(tree.root);

      // Record OOB predictions
      if (this.params.bootstrap) {
        data.forEach(p => {
          if (!inBagSet.has(p.id)) {
            const pred = tree.predictPoint(p.x1, p.x2);
            oobPredictions.get(p.id)?.push(pred);
          }
        });
      }
    }

    // Normalize feature importance
    const totalGain = x1ImpurityGainTotal + x2ImpurityGainTotal;
    if (totalGain > 0) {
      this.featureImportances = [
        x1ImpurityGainTotal / totalGain,
        x2ImpurityGainTotal / totalGain,
      ];
    } else {
      this.featureImportances = [0.5, 0.5];
    }

    // Compute OOB Accuracy or R2
    if (this.params.bootstrap) {
      let evaluatedCount = 0;
      let oobCorrect = 0;
      data.forEach(p => {
        const preds = oobPredictions.get(p.id) || [];
        if (preds.length > 0) {
          evaluatedCount++;
          if (this.taskType === 'classification') {
            const sum = preds.reduce((acc, v) => acc + v, 0);
            const ensembleVote = sum / preds.length >= 0.5 ? 1 : 0;
            if (ensembleVote === p.y) oobCorrect++;
          }
        }
      });
      this.oobScore = evaluatedCount > 0 ? oobCorrect / evaluatedCount : 0;
    } else {
      this.oobScore = 0;
    }
  }

  predictPoint(x1: number, x2: number): number {
    if (this.trees.length === 0) return 0;

    if (this.taskType === 'classification') {
      let votesFor1 = 0;
      for (const tree of this.trees) {
        if (tree.predictPoint(x1, x2) === 1) votesFor1++;
      }
      return votesFor1 / this.trees.length >= 0.5 ? 1 : 0;
    } else {
      let sum = 0;
      for (const tree of this.trees) {
        sum += tree.predictPoint(x1, x2);
      }
      return sum / this.trees.length;
    }
  }

  predictProbabilities(x1: number, x2: number): [number, number] {
    if (this.trees.length === 0) return [0.5, 0.5];
    let votesFor1 = 0;
    for (const tree of this.trees) {
      if (tree.predictPoint(x1, x2) === 1) votesFor1++;
    }
    const p1 = votesFor1 / this.trees.length;
    return [1 - p1, p1];
  }

  getTreeSummaries(): EnsembleTreeSummary[] {
    return this.trees.map((t, idx) => {
      const stats = t.getTreeStats();
      return {
        id: idx + 1,
        depth: stats.actualMaxDepth,
        nodeCount: stats.totalNodes,
        weight: 1 / this.trees.length,
        tree: t.root!,
      };
    });
  }
}

export function evaluateRandomForestClassification(
  rf: RandomForest,
  trainData: DataPoint[],
  testData: DataPoint[]
): ClassificationMetrics {
  const calcAcc = (dataset: DataPoint[]) => {
    if (dataset.length === 0) return { acc: 0, f1: 0, tn: 0, fp: 0, fn: 0, tp: 0 };
    let correct = 0;
    let tn = 0, fp = 0, fn = 0, tp = 0;

    for (const p of dataset) {
      const pred = rf.predictPoint(p.x1, p.x2);
      if (pred === p.y) correct++;
      if (p.y === 1 && pred === 1) tp++;
      if (p.y === 0 && pred === 0) tn++;
      if (p.y === 0 && pred === 1) fp++;
      if (p.y === 1 && pred === 0) fn++;
    }

    const acc = correct / dataset.length;
    const precision = tp + fp > 0 ? tp / (tp + fp) : 0;
    const recall = tp + fn > 0 ? tp / (tp + fn) : 0;
    const f1 = precision + recall > 0 ? (2 * precision * recall) / (precision + recall) : 0;

    return { acc, f1, tn, fp, fn, tp };
  };

  const trainRes = calcAcc(trainData);
  const testRes = calcAcc(testData);

  return {
    trainAccuracy: trainRes.acc,
    testAccuracy: testRes.acc,
    trainF1: trainRes.f1,
    testF1: testRes.f1,
    trainLoss: 1 - trainRes.acc,
    testLoss: 1 - testRes.acc,
    confusionMatrix: {
      tn: testRes.tn,
      fp: testRes.fp,
      fn: testRes.fn,
      tp: testRes.tp,
    },
  };
}

export function evaluateRandomForestRegression(
  rf: RandomForest,
  trainData: DataPoint[],
  testData: DataPoint[]
): RegressionMetrics {
  const calcMetrics = (dataset: DataPoint[]) => {
    if (dataset.length === 0) return { r2: 0, rmse: 0, mae: 0 };
    const n = dataset.length;
    const meanY = dataset.reduce((acc, p) => acc + p.y, 0) / n;

    let ssTot = 0;
    let ssRes = 0;
    let sumAbsErr = 0;

    for (const p of dataset) {
      const pred = rf.predictPoint(p.x1, p.x2);
      const diff = p.y - pred;
      ssRes += diff * diff;
      ssTot += Math.pow(p.y - meanY, 2);
      sumAbsErr += Math.abs(diff);
    }

    const r2 = ssTot > 0 ? Math.max(-1, 1 - ssRes / ssTot) : 0;
    const rmse = Math.sqrt(ssRes / n);
    const mae = sumAbsErr / n;

    return { r2, rmse, mae };
  };

  const train = calcMetrics(trainData);
  const test = calcMetrics(testData);

  return {
    trainR2: train.r2,
    testR2: test.r2,
    trainRmse: train.rmse,
    testRmse: test.rmse,
    trainMae: train.mae,
    testMae: test.mae,
  };
}
