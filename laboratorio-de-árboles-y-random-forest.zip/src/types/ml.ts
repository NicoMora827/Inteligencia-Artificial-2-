export type TaskType = 'classification' | 'regression';

export interface DataPoint {
  id: number;
  x1: number;
  x2: number;
  y: number; // class (0 or 1) for classification; continuous value for regression
  predicted?: number;
  isTest?: boolean;
}

export interface Dataset {
  name: string;
  taskType: TaskType;
  description: string;
  x1Name: string;
  x2Name: string;
  yName: string;
  x1Unit?: string;
  x2Unit?: string;
  yUnit?: string;
  trainData: DataPoint[];
  testData: DataPoint[];
  classLabels?: [string, string];
}

export interface Hyperparameters {
  maxDepth: number; // 1 to 10
  minSamplesSplit: number; // 2 to 30
  minSamplesLeaf: number; // 1 to 20
  criterion: 'gini' | 'entropy' | 'mse' | 'mae';
  // Random Forest specific
  nEstimators: number; // 1 to 50
  bootstrap: boolean;
  maxFeatures: 'all' | 'sqrt' | number;
}

export interface TreeNode {
  id: number;
  featureIndex: number | null; // 0 for x1, 1 for x2, null if leaf
  threshold: number | null;
  left: TreeNode | null;
  right: TreeNode | null;
  isLeaf: boolean;
  samples: number;
  value: number; // majority class or mean target
  probabilities?: number[]; // for classification [p0, p1]
  impurity: number; // gini/entropy or mse/mae
  depth: number;
}

export interface PredictionPathStep {
  nodeId: number;
  depth: number;
  featureName: string;
  threshold: number;
  sampleValue: number;
  decision: 'left' | 'right' | 'leaf';
  comparisonText: string;
}

export interface PredictionResult {
  predictedValue: number;
  probabilities?: number[];
  path: PredictionPathStep[];
  leafNodeId: number;
}

export interface ClassificationMetrics {
  trainAccuracy: number;
  testAccuracy: number;
  trainF1: number;
  testF1: number;
  trainLoss: number;
  testLoss: number;
  confusionMatrix: {
    tn: number;
    fp: number;
    fn: number;
    tp: number;
  };
}

export interface RegressionMetrics {
  trainR2: number;
  testR2: number;
  trainRmse: number;
  testRmse: number;
  trainMae: number;
  testMae: number;
}

export type FitStatus = 'underfitting' | 'optimal' | 'overfitting';

export interface ModelDiagnostics {
  status: FitStatus;
  statusLabel: string;
  statusColor: 'emerald' | 'amber' | 'rose';
  explanation: string;
  recommendedAction: string;
  complexityScore: number; // 0 (muy simple) a 100 (muy complejo)
}

export interface TreeStats {
  totalNodes: number;
  leafCount: number;
  actualMaxDepth: number;
}

export interface EnsembleTreeSummary {
  id: number;
  depth: number;
  nodeCount: number;
  weight: number;
  tree: TreeNode;
}
