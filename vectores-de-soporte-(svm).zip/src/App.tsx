/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { Point2D, SVMParams, PresetDatasetId, ClassLabel } from './types';
import { PRESET_DATASETS } from './svm/presets';
import { trainSVM } from './svm/svmEngine';
import { SvmCanvas } from './components/SvmCanvas';
import { ControlsPanel } from './components/ControlsPanel';
import { MetricsBar } from './components/MetricsBar';
import { KernelTrick3D } from './components/KernelTrick3D';
import { TheoryGuide } from './components/TheoryGuide';
import {
  Compass,
  Rotate3d,
  Layers,
  BookOpen,
  Sparkles,
  Info,
  PlusCircle,
  ShieldCheck,
} from 'lucide-react';

export default function App() {
  const initialPreset = PRESET_DATASETS[0];

  const [points, setPoints] = useState<Point2D[]>(initialPreset.points);
  const [selectedPreset, setSelectedPreset] = useState<PresetDatasetId>(initialPreset.id);

  const [params, setParams] = useState<SVMParams>({
    kernel: initialPreset.recommendedKernel,
    C: initialPreset.recommendedC,
    gamma: initialPreset.recommendedGamma,
    degree: 3,
    coef0: 1.0,
    tol: 0.001,
    maxPasses: 10,
  });

  const [activeClass, setActiveClass] = useState<ClassLabel>(1);
  const [showHeatmap, setShowHeatmap] = useState(true);
  const [showMargins, setShowMargins] = useState(true);
  const [showAlphaLabels, setShowAlphaLabels] = useState(true);

  // Tab navigation: 'canvas2d' | 'kernel3d' | 'theory'
  const [activeTab, setActiveTab] = useState<'canvas2d' | 'kernel3d' | 'theory'>('canvas2d');

  // Fast Memoized SVM Training
  const model = useMemo(() => {
    return trainSVM(points, params);
  }, [points, params]);

  // Handle Preset Switching
  const handleSelectPreset = (presetId: PresetDatasetId) => {
    const preset = PRESET_DATASETS.find((p) => p.id === presetId);
    if (!preset) return;
    setSelectedPreset(presetId);
    setPoints(preset.points);
    setParams((prev) => ({
      ...prev,
      kernel: preset.recommendedKernel,
      C: preset.recommendedC,
      gamma: preset.recommendedGamma,
    }));
  };

  // Add random points with slight noise
  const handleAddRandomNoise = () => {
    const noisePoints: Point2D[] = [];
    const count = 4;
    for (let i = 0; i < count; i++) {
      const isPos = i % 2 === 0;
      const angle = Math.random() * Math.PI * 2;
      const r = 0.2 + Math.random() * 0.6;
      noisePoints.push({
        id: `noise_${Date.now()}_${i}`,
        x: Math.max(-0.85, Math.min(0.85, Math.cos(angle) * r)),
        y: Math.max(-0.85, Math.min(0.85, Math.sin(angle) * r)),
        label: isPos ? 1 : -1,
      });
    }
    setPoints((prev) => [...prev, ...noisePoints]);
  };

  const handleClearPoints = () => {
    setPoints([]);
  };

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-800 font-sans antialiased">
      {/* Top Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-2xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-xs">
              <Compass className="w-6 h-6" />
            </div>
            <div>
              <h1 className="font-extrabold text-lg text-slate-900 leading-tight">
                Vectores de Soporte <span className="text-indigo-600">(SVM)</span>
              </h1>
              <p className="text-xs text-slate-500 font-medium">
                Simulador Interactivo de Clasificación y Margen Máximo
              </p>
            </div>
          </div>

          {/* View Mode Tabs */}
          <nav className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs">
            <button
              id="tab-canvas-2d"
              onClick={() => setActiveTab('canvas2d')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-semibold transition-all ${
                activeTab === 'canvas2d'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Lienzo 2D Interactivo</span>
            </button>

            <button
              id="tab-kernel-3d"
              onClick={() => setActiveTab('kernel3d')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-semibold transition-all ${
                activeTab === 'kernel3d'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Rotate3d className="w-3.5 h-3.5" />
              <span>Truco del Kernel 3D</span>
            </button>

            <button
              id="tab-theory"
              onClick={() => setActiveTab('theory')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-semibold transition-all ${
                activeTab === 'theory'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Teoría & Matemáticas</span>
            </button>
          </nav>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-5">
        {/* Real-time Metrics Bar */}
        <MetricsBar model={model} />

        {/* Tab 1: 2D Interactive Canvas & Controls */}
        {activeTab === 'canvas2d' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
            {/* Left Column: Interactive Canvas & Explanation */}
            <div className="lg:col-span-7 xl:col-span-8 space-y-4">
              <SvmCanvas
                model={model}
                points={points}
                activeClass={activeClass}
                onPointsChange={setPoints}
                showHeatmap={showHeatmap}
                showMargins={showMargins}
                showAlphaLabels={showAlphaLabels}
              />

              {/* Informative helper card */}
              <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs text-xs space-y-2">
                <div className="flex items-center gap-2 font-bold text-slate-800">
                  <ShieldCheck className="w-4 h-4 text-indigo-600" />
                  <span>Interpretación de la Visualización</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-slate-600">
                  <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-100">
                    <span className="font-bold text-slate-800 block mb-1">
                      Línea Central Sólida (f(x) = 0):
                    </span>
                    Frontera de decisión óptima. Los puntos a un lado se clasifican como +1 y al otro como −1.
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-100">
                    <span className="font-bold text-slate-800 block mb-1">
                      Líneas Discontinuas (f(x) = ±1):
                    </span>
                    Límites del corredor del margen. La distancia entre ambas es el margen geométrico{' '}
                    <code className="font-mono text-indigo-600 font-semibold">2 / ||w||</code>.
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-100">
                    <span className="font-bold text-slate-800 block mb-1">
                      Anillos Dobles (α &gt; 0):
                    </span>
                    Son los <strong>Vectores de Soporte</strong>. Solo ellos definen el hiperplano. Si mueves un punto sin anillo, la frontera no se altera.
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column: Controls Panel */}
            <div className="lg:col-span-5 xl:col-span-4">
              <ControlsPanel
                params={params}
                onParamsChange={setParams}
                selectedPreset={selectedPreset}
                onSelectPreset={handleSelectPreset}
                activeClass={activeClass}
                onActiveClassChange={setActiveClass}
                showHeatmap={showHeatmap}
                onToggleHeatmap={() => setShowHeatmap(!showHeatmap)}
                showMargins={showMargins}
                showToggleMargins={() => setShowMargins(!showMargins)}
                showAlphaLabels={showAlphaLabels}
                onToggleAlphaLabels={() => setShowAlphaLabels(!showAlphaLabels)}
                onClearPoints={handleClearPoints}
                onAddRandomNoise={handleAddRandomNoise}
              />
            </div>
          </div>
        )}

        {/* Tab 2: 3D Kernel Trick Visualizer */}
        {activeTab === 'kernel3d' && (
          <div className="space-y-4">
            <KernelTrick3D points={points} />
            <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs text-xs text-slate-600 space-y-2">
              <h4 className="font-bold text-slate-800 text-sm flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-indigo-600" />
                ¿Cómo funciona el Truco del Kernel en esta vista 3D?
              </h4>
              <p>
                En dos dimensiones, datos dispuestos en anillos concéntricos o formas cuadráticas
                no pueden ser separados por una línea recta. Al aplicar la transformación de elevación{' '}
                <code className="font-mono bg-slate-100 px-1 py-0.5 rounded text-indigo-600 font-semibold">
                  Φ(x₁, x₂) = (x₁, x₂, x₁² + x₂²)
                </code>
                , los puntos cercanos al origen permanecen abajo mientras que los puntos del anillo exterior
                ascienden sobre un paraboloide.
              </p>
              <p>
                En ese nuevo espacio tridimensional, un plano horizontal plano separa perfectamente ambas
                clases. El teorema de Mercer y el truco del kernel permiten a los algoritmos SVM calcular
                esta frontera no lineal en 2D sin necesidad de calcular explícitamente coordenadas de alta dimensión.
              </p>
            </div>
          </div>
        )}

        {/* Tab 3: Theoretical & Mathematical Foundations */}
        {activeTab === 'theory' && (
          <div className="max-w-4xl mx-auto">
            <TheoryGuide />
          </div>
        )}
      </main>
    </div>
  );
}
