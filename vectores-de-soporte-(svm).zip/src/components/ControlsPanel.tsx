import React from 'react';
import { KernelType, SVMParams, PresetDatasetId, ClassLabel } from '../types';
import { PRESET_DATASETS } from '../svm/presets';
import {
  Settings,
  Database,
  Sliders,
  PlusCircle,
  MinusCircle,
  RotateCcw,
  Sparkles,
  Layers,
  HelpCircle,
  Eye,
} from 'lucide-react';

interface ControlsPanelProps {
  params: SVMParams;
  onParamsChange: (newParams: SVMParams) => void;
  selectedPreset: PresetDatasetId;
  onSelectPreset: (presetId: PresetDatasetId) => void;
  activeClass: ClassLabel;
  onActiveClassChange: (c: ClassLabel) => void;
  showHeatmap: boolean;
  onToggleHeatmap: () => void;
  showMargins: boolean;
  onToggleMargins: () => void;
  showAlphaLabels: boolean;
  onToggleAlphaLabels: () => void;
  onClearPoints: () => void;
  onAddRandomNoise: () => void;
}

export const ControlsPanel: React.FC<ControlsPanelProps> = ({
  params,
  onParamsChange,
  selectedPreset,
  onSelectPreset,
  activeClass,
  onActiveClassChange,
  showHeatmap,
  onToggleHeatmap,
  showMargins,
  onToggleMargins,
  showAlphaLabels,
  onToggleAlphaLabels,
  onClearPoints,
  onAddRandomNoise,
}) => {
  const kernels: { id: KernelType; label: string; formula: string }[] = [
    { id: 'linear', label: 'Lineal', formula: 'K(x, z) = x · z' },
    { id: 'rbf', label: 'RBF / Gaussiano', formula: 'K(x, z) = exp(-γ||x-z||²)' },
    { id: 'poly', label: 'Polinómico', formula: 'K(x, z) = (x · z + 1)ᵈ' },
    { id: 'sigmoid', label: 'Sigmoide', formula: 'K(x, z) = tanh(γ x·z + 1)' },
  ];

  return (
    <div id="controls-panel" className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs space-y-5">
      {/* 1. Dataset Selection */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-slate-500">
            <Database className="w-3.5 h-3.5 text-indigo-600" />
            <span>Conjuntos de Datos de Ejemplo</span>
          </div>
          <span className="text-[11px] text-slate-400">Haz clic para cargar</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
          {PRESET_DATASETS.map((preset) => {
            const isSelected = selectedPreset === preset.id;
            return (
              <button
                key={preset.id}
                id={`preset-${preset.id}`}
                onClick={() => onSelectPreset(preset.id)}
                className={`text-left px-2.5 py-2 rounded-lg text-xs font-medium transition-all ${
                  isSelected
                    ? 'bg-indigo-50 border border-indigo-300 text-indigo-900 shadow-xs'
                    : 'bg-slate-50 border border-slate-200 hover:bg-slate-100 text-slate-700'
                }`}
              >
                <div className="font-semibold truncate">{preset.name}</div>
                <div className="text-[10px] text-slate-500 line-clamp-1 mt-0.5">
                  Kernel rec.: <span className="font-mono">{preset.recommendedKernel}</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. Kernel Selection */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-slate-500">
            <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
            <span>Función del Kernel K(x, z)</span>
          </div>
          <span className="text-[11px] text-slate-400">Espacio de Hilbert</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
          {kernels.map((k) => {
            const isActive = params.kernel === k.id;
            return (
              <button
                key={k.id}
                id={`kernel-${k.id}`}
                onClick={() => onParamsChange({ ...params, kernel: k.id })}
                className={`px-3 py-2 rounded-lg text-xs font-medium text-center transition-all ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-sm ring-2 ring-indigo-200'
                    : 'bg-slate-50 border border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <div className="font-bold">{k.label}</div>
                <div
                  className={`text-[9px] font-mono mt-0.5 truncate ${
                    isActive ? 'text-indigo-100' : 'text-slate-400'
                  }`}
                >
                  {k.formula}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* 3. Hyperparameters (C, Gamma, Degree) */}
      <div className="bg-slate-50/80 p-3.5 rounded-lg border border-slate-200/80 space-y-4">
        <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-slate-600">
          <Sliders className="w-3.5 h-3.5 text-indigo-600" />
          <span>Hiperparámetros del Modelo</span>
        </div>

        {/* Regularization C */}
        <div>
          <div className="flex justify-between items-center text-xs mb-1">
            <span className="font-semibold text-slate-700 flex items-center gap-1">
              Regularización C (Margen Blando vs Duro):
            </span>
            <span className="font-mono font-bold bg-white px-2 py-0.5 rounded border border-slate-200 text-indigo-700">
              {params.C >= 100 ? params.C.toFixed(0) : params.C.toFixed(2)}
            </span>
          </div>
          <input
            type="range"
            min="-1"
            max="3"
            step="0.1"
            value={Math.log10(params.C)}
            onChange={(e) => {
              const val = Math.pow(10, parseFloat(e.target.value));
              onParamsChange({ ...params, C: val });
            }}
            className="w-full accent-indigo-600 cursor-pointer"
          />
          <div className="flex justify-between text-[10px] text-slate-400 mt-1">
            <span>0.1 (Margen amplio, tolera errores)</span>
            <span>1000 (Margen estricto / Hard Margin)</span>
          </div>
        </div>

        {/* Gamma for RBF and Sigmoid */}
        {(params.kernel === 'rbf' || params.kernel === 'sigmoid') && (
          <div>
            <div className="flex justify-between items-center text-xs mb-1">
              <span className="font-semibold text-slate-700">
                Parámetro Gamma (γ - Radio de influencia):
              </span>
              <span className="font-mono font-bold bg-white px-2 py-0.5 rounded border border-slate-200 text-indigo-700">
                {params.gamma.toFixed(2)}
              </span>
            </div>
            <input
              type="range"
              min="0.1"
              max="8.0"
              step="0.1"
              value={params.gamma}
              onChange={(e) =>
                onParamsChange({ ...params, gamma: parseFloat(e.target.value) })
              }
              className="w-full accent-indigo-600 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400 mt-1">
              <span>0.1 (Frontera suave / global)</span>
              <span>8.0 (Frontera ajustada / islas locales)</span>
            </div>
          </div>
        )}

        {/* Polynomial Degree */}
        {params.kernel === 'poly' && (
          <div>
            <div className="flex justify-between items-center text-xs mb-1">
              <span className="font-semibold text-slate-700">Grado Polinómico (d):</span>
              <span className="font-mono font-bold bg-white px-2 py-0.5 rounded border border-slate-200 text-indigo-700">
                {params.degree}
              </span>
            </div>
            <div className="flex gap-2">
              {[2, 3, 4, 5].map((deg) => (
                <button
                  key={deg}
                  onClick={() => onParamsChange({ ...params, degree: deg })}
                  className={`flex-1 py-1 text-xs rounded font-medium ${
                    params.degree === deg
                      ? 'bg-indigo-600 text-white'
                      : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  Grado {deg}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* 4. Canvas Drawing Controls & Toggles */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-1 border-t border-slate-100">
        {/* Active Class Selector */}
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-600">Clase al hacer clic:</span>
          <div className="inline-flex rounded-lg border border-slate-200 p-0.5 bg-slate-100">
            <button
              id="btn-class-pos"
              onClick={() => onActiveClassChange(1)}
              className={`px-2.5 py-1 rounded-md text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeClass === 1
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span>Clase +1</span>
            </button>
            <button
              id="btn-class-neg"
              onClick={() => onActiveClassChange(-1)}
              className={`px-2.5 py-1 rounded-md text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeClass === -1
                  ? 'bg-red-500 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <MinusCircle className="w-3.5 h-3.5" />
              <span>Clase −1</span>
            </button>
          </div>
        </div>

        {/* Visual Layer Toggles */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <button
            onClick={onToggleHeatmap}
            className={`px-2.5 py-1.5 rounded-md border font-medium flex items-center gap-1.5 transition-colors ${
              showHeatmap
                ? 'bg-indigo-50 border-indigo-200 text-indigo-700'
                : 'bg-white border-slate-200 text-slate-500'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Mapa de Calor</span>
          </button>

          <button
            onClick={onToggleMargins}
            className={`px-2.5 py-1.5 rounded-md border font-medium flex items-center gap-1.5 transition-colors ${
              showMargins
                ? 'bg-indigo-50 border-indigo-200 text-indigo-700'
                : 'bg-white border-slate-200 text-slate-500'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Márgenes (±1)</span>
          </button>

          <button
            onClick={onToggleAlphaLabels}
            className={`px-2.5 py-1.5 rounded-md border font-medium flex items-center gap-1.5 transition-colors ${
              showAlphaLabels
                ? 'bg-indigo-50 border-indigo-200 text-indigo-700'
                : 'bg-white border-slate-200 text-slate-500'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Valores α</span>
          </button>

          <button
            onClick={onAddRandomNoise}
            className="px-2.5 py-1.5 rounded-md border border-slate-200 bg-white hover:bg-slate-50 text-slate-600 font-medium"
            title="Añadir puntos aleatorios con ruido"
          >
            + Puntos
          </button>

          <button
            onClick={onClearPoints}
            className="px-2.5 py-1.5 rounded-md border border-red-200 bg-red-50 hover:bg-red-100 text-red-600 font-medium flex items-center gap-1"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Limpiar</span>
          </button>
        </div>
      </div>
    </div>
  );
};
