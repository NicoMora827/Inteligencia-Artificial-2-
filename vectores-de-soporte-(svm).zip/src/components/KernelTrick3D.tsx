import React, { useRef, useEffect, useState } from 'react';
import { Point2D } from '../types';
import { Rotate3d, Eye, Sparkles, Layers, Sliders } from 'lucide-react';

interface KernelTrick3DProps {
  points: Point2D[];
}

export const KernelTrick3D: React.FC<KernelTrick3DProps> = ({ points }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Rotation angles in radians
  const [rotation, setRotation] = useState({ yaw: 0.8, pitch: 0.5 });
  const [isDragging, setIsDragging] = useState(false);
  const [lastMouse, setLastMouse] = useState({ x: 0, y: 0 });

  // Morph slider from 0 (flat 2D, z=0) to 1 (full 3D feature space, z = x^2 + y^2)
  const [morphZ, setMorphZ] = useState(1.0);
  const [showHyperplane, setShowHyperplane] = useState(true);
  const [planeZ, setPlaneZ] = useState(0.35);

  // Mouse Orbit controls
  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setLastMouse({ x: e.clientX, y: e.clientY });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    const dx = e.clientX - lastMouse.x;
    const dy = e.clientY - lastMouse.y;
    setRotation((prev) => ({
      yaw: prev.yaw + dx * 0.01,
      pitch: Math.max(-1.4, Math.min(1.4, prev.pitch + dy * 0.01)),
    }));
    setLastMouse({ x: e.clientX, y: e.clientY });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const rect = container.getBoundingClientRect();
    const width = Math.floor(rect.width);
    const height = Math.floor(rect.height);
    if (width <= 0 || height <= 0) return;

    const dpr = window.devicePixelRatio || 1;
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, width, height);

    // 3D Projection Matrix setup
    const scale = Math.min(width, height) * 0.38;
    const cx = width / 2;
    const cy = height / 2 + 15;

    const cosY = Math.cos(rotation.yaw);
    const sinY = Math.sin(rotation.yaw);
    const cosP = Math.cos(rotation.pitch);
    const sinP = Math.sin(rotation.pitch);

    // Project 3D (x, y, z) to 2D screen coordinates
    const project = (x: number, y: number, z: number) => {
      // Rotate around Y axis (yaw)
      const x1 = x * cosY - y * sinY;
      const y1 = x * sinY + y * cosY;
      const z1 = z;

      // Rotate around X axis (pitch)
      const x2 = x1;
      const y2 = y1 * cosP - z1 * sinP;
      const z2 = y1 * sinP + z1 * cosP;

      // Screen projection
      const px = cx + x2 * scale;
      const py = cy - z2 * scale; // Invert Z for standard mathematical upward height
      return { px, py, depth: y2 };
    };

    // Draw 3D Base Grid (Z = 0)
    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 1;
    const gridStep = 0.5;
    for (let g = -1; g <= 1; g += gridStep) {
      // Lines parallel to X
      const p1 = project(-1, g, 0);
      const p2 = project(1, g, 0);
      ctx.beginPath();
      ctx.moveTo(p1.px, p1.py);
      ctx.lineTo(p2.px, p2.py);
      ctx.stroke();

      // Lines parallel to Y
      const p3 = project(g, -1, 0);
      const p4 = project(g, 1, 0);
      ctx.beginPath();
      ctx.moveTo(p3.px, p3.py);
      ctx.lineTo(p4.px, p4.py);
      ctx.stroke();
    }

    // Draw 3D Coordinate Axes
    const o = project(0, 0, 0);
    const axX = project(1.2, 0, 0);
    const axY = project(0, 1.2, 0);
    const axZ = project(0, 0, 1.2);

    // X Axis (Reddish)
    ctx.strokeStyle = '#f87171';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(o.px, o.py);
    ctx.lineTo(axX.px, axX.py);
    ctx.stroke();

    // Y Axis (Greenish)
    ctx.strokeStyle = '#34d399';
    ctx.beginPath();
    ctx.moveTo(o.px, o.py);
    ctx.lineTo(axY.px, axY.py);
    ctx.stroke();

    // Z Axis (Feature Space Dimension: x_1^2 + x_2^2) (Indigo)
    ctx.strokeStyle = '#6366f1';
    ctx.beginPath();
    ctx.moveTo(o.px, o.py);
    ctx.lineTo(axZ.px, axZ.py);
    ctx.stroke();

    // Axis Labels
    ctx.font = 'bold 11px ui-monospace, monospace';
    ctx.fillStyle = '#dc2626';
    ctx.fillText('X₁', axX.px + 4, axX.py + 4);
    ctx.fillStyle = '#059669';
    ctx.fillText('X₂', axY.px + 4, axY.py + 4);
    ctx.fillStyle = '#4f46e5';
    ctx.fillText('Z = Φ(X)', axZ.px + 4, axZ.py - 4);

    // Draw 3D Separating Hyperplane (Flat Plane in feature space)
    if (showHyperplane && morphZ > 0.15) {
      const planeCorners = [
        project(-1.1, -1.1, planeZ * morphZ),
        project(1.1, -1.1, planeZ * morphZ),
        project(1.1, 1.1, planeZ * morphZ),
        project(-1.1, 1.1, planeZ * morphZ),
      ];

      ctx.save();
      ctx.fillStyle = 'rgba(245, 158, 11, 0.18)'; // Amber semi-transparent plane
      ctx.strokeStyle = 'rgba(217, 119, 6, 0.8)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(planeCorners[0].px, planeCorners[0].py);
      for (let c = 1; c < 4; c++) {
        ctx.lineTo(planeCorners[c].px, planeCorners[c].py);
      }
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      // Hyperplane label
      const pl = project(1.15, 0, planeZ * morphZ);
      ctx.fillStyle = '#b45309';
      ctx.font = 'bold 10px sans-serif';
      ctx.fillText('Hiperplano Separador 3D', pl.px + 4, pl.py);
      ctx.restore();
    }

    // Project and sort points by camera depth for correct painters-algorithm rendering
    const pointList = points.map((p) => {
      // Non-linear lifting function: z = x^2 + y^2
      const targetZ = (p.x * p.x + p.y * p.y) * 0.9;
      const z = targetZ * morphZ;
      const proj = project(p.x, p.y, z);
      const groundProj = project(p.x, p.y, 0);
      return {
        point: p,
        x: p.x,
        y: p.y,
        z,
        proj,
        groundProj,
        depth: proj.depth,
      };
    });

    // Sort back-to-front
    pointList.sort((a, b) => b.depth - a.depth);

    // Draw stems connecting 2D ground projection to 3D point
    if (morphZ > 0.05) {
      ctx.strokeStyle = 'rgba(148, 163, 184, 0.4)';
      ctx.lineWidth = 1;
      ctx.setLineDash([2, 2]);
      for (const p of pointList) {
        ctx.beginPath();
        ctx.moveTo(p.groundProj.px, p.groundProj.py);
        ctx.lineTo(p.proj.px, p.proj.py);
        ctx.stroke();
      }
      ctx.setLineDash([]);
    }

    // Draw 3D Points
    for (const p of pointList) {
      const isPos = p.point.label === 1;
      const radius = 7;

      ctx.save();
      ctx.beginPath();
      ctx.arc(p.proj.px, p.proj.py, radius, 0, 2 * Math.PI);
      ctx.fillStyle = isPos ? '#4f46e5' : '#ef4444';
      ctx.shadowColor = isPos ? 'rgba(79, 70, 229, 0.4)' : 'rgba(239, 68, 68, 0.4)';
      ctx.shadowBlur = 6;
      ctx.fill();

      ctx.shadowBlur = 0;
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Point label (+ / -)
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 9px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(isPos ? '+' : '−', p.proj.px, p.proj.py);
      ctx.restore();
    }
  }, [points, rotation, morphZ, showHyperplane, planeZ]);

  return (
    <div
      id="kernel-trick-3d"
      className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs flex flex-col gap-4"
    >
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <Rotate3d className="w-5 h-5 text-indigo-600" />
            <h3 className="font-bold text-slate-800 text-base">
              Visualizador 3D: El Truco del Kernel (Kernel Trick)
            </h3>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Observa cómo datos no separables en 2D se proyectan al espacio de características{' '}
            <code className="font-mono bg-slate-100 px-1 py-0.5 rounded text-indigo-600">
              Φ(x) = (x₁, x₂, x₁² + x₂²)
            </code>{' '}
            y se vuelven linealmente separables por un plano plano 3D.
          </p>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-center">
          <button
            onClick={() => setRotation({ yaw: 0.8, pitch: 0.5 })}
            className="px-2.5 py-1 text-xs font-medium text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors"
          >
            Reset Vista
          </button>
        </div>
      </div>

      {/* 3D Canvas Area */}
      <div
        ref={containerRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        className="relative w-full h-[360px] bg-slate-50 rounded-lg border border-slate-200 overflow-hidden cursor-grab active:cursor-grabbing select-none"
      >
        <canvas ref={canvasRef} className="w-full h-full block" />

        {/* Orbit Hint badge */}
        <div className="absolute top-2.5 left-2.5 bg-white/90 backdrop-blur-sm px-2.5 py-1 rounded text-[11px] font-medium text-slate-600 border border-slate-200 flex items-center gap-1.5 pointer-events-none">
          <Eye className="w-3.5 h-3.5 text-indigo-500" />
          <span>Arrastra con el ratón para rotar en 3D</span>
        </div>

        {/* Current Space Status badge */}
        <div className="absolute bottom-2.5 right-2.5 bg-slate-900/90 text-white px-2.5 py-1 rounded text-[11px] font-mono border border-slate-700 pointer-events-none">
          {morphZ === 0
            ? 'Espacio Original 2D (No separable)'
            : morphZ === 1
            ? 'Espacio de Hilbert 3D (Linealmente Separable)'
            : `Proyección Intermedia: ${(morphZ * 100).toFixed(0)}%`}
        </div>
      </div>

      {/* Interactive Controls for 3D Morphing */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-50/70 p-3.5 rounded-lg border border-slate-200/80 text-xs">
        <div>
          <div className="flex justify-between items-center mb-1.5 font-medium text-slate-700">
            <span className="flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-indigo-600" />
              Proyección al espacio de características Z:
            </span>
            <span className="font-mono text-indigo-600 font-bold">{(morphZ * 100).toFixed(0)}%</span>
          </div>
          <input
            type="range"
            min="0"
            max="1"
            step="0.02"
            value={morphZ}
            onChange={(e) => setMorphZ(parseFloat(e.target.value))}
            className="w-full accent-indigo-600 cursor-pointer"
          />
          <div className="flex justify-between text-[10px] text-slate-400 mt-1">
            <span>2D Plano (Z=0)</span>
            <span>Elevación paraboloide Φ(x)</span>
          </div>
        </div>

        <div>
          <div className="flex justify-between items-center mb-1.5 font-medium text-slate-700">
            <span className="flex items-center gap-1.5">
              <Sliders className="w-3.5 h-3.5 text-amber-600" />
              Altura del Hiperplano Separador:
            </span>
            <span className="font-mono text-amber-600 font-bold">{planeZ.toFixed(2)}</span>
          </div>
          <div className="flex items-center gap-2">
            <input
              type="range"
              min="0.1"
              max="0.8"
              step="0.02"
              value={planeZ}
              onChange={(e) => setPlaneZ(parseFloat(e.target.value))}
              disabled={!showHyperplane}
              className="w-full accent-amber-600 cursor-pointer disabled:opacity-50"
            />
            <button
              onClick={() => setShowHyperplane(!showHyperplane)}
              className={`px-2 py-1 rounded text-[11px] font-medium transition-colors ${
                showHyperplane
                  ? 'bg-amber-100 text-amber-800 border border-amber-300'
                  : 'bg-slate-200 text-slate-600'
              }`}
            >
              {showHyperplane ? 'Visible' : 'Oculto'}
            </button>
          </div>
          <div className="text-[10px] text-slate-400 mt-1">
            El plano corta el espacio 3D dividiendo los puntos interiores y exteriores.
          </div>
        </div>
      </div>
    </div>
  );
};
