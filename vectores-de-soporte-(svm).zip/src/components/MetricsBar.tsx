import React from 'react';
import { SVMModel } from '../types';
import { Target, CheckCircle2, ShieldAlert, Cpu, Award } from 'lucide-react';

interface MetricsBarProps {
  model: SVMModel;
}

export const MetricsBar: React.FC<MetricsBarProps> = ({ model }) => {
  const totalPoints = model.points.length;
  const numSV = model.supportVectors.length;
  const svPercentage = totalPoints > 0 ? ((numSV / totalPoints) * 100).toFixed(0) : '0';

  const freeSVs = model.supportVectors.filter((sv) => sv.isFree).length;
  const boundedSVs = model.supportVectors.filter((sv) => sv.isBounded).length;

  return (
    <div
      id="metrics-bar"
      className="grid grid-cols-2 md:grid-cols-4 gap-3 bg-white rounded-xl border border-slate-200 p-3.5 shadow-xs"
    >
      {/* 1. Accuracy Metric */}
      <div className="flex items-center gap-3 p-2 rounded-lg bg-slate-50 border border-slate-100">
        <div className="w-10 h-10 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
          <CheckCircle2 className="w-5 h-5" />
        </div>
        <div>
          <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide">
            Exactitud (Accuracy)
          </div>
          <div className="text-lg font-black text-slate-800">
            {(model.accuracy * 100).toFixed(1)}%
          </div>
          <div className="text-[10px] text-slate-400">
            {model.confusionMatrix.tp + model.confusionMatrix.tn} de {totalPoints} clasificados
          </div>
        </div>
      </div>

      {/* 2. Support Vectors Count */}
      <div className="flex items-center gap-3 p-2 rounded-lg bg-slate-50 border border-slate-100">
        <div className="w-10 h-10 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center shrink-0">
          <Target className="w-5 h-5" />
        </div>
        <div>
          <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide">
            Vectores de Soporte
          </div>
          <div className="text-lg font-black text-slate-800">
            {numSV} <span className="text-xs font-normal text-slate-500">({svPercentage}%)</span>
          </div>
          <div className="text-[10px] text-slate-400">
            {freeSVs} en margen • {boundedSVs} con holgura
          </div>
        </div>
      </div>

      {/* 3. Margin Width or Dual Bias */}
      <div className="flex items-center gap-3 p-2 rounded-lg bg-slate-50 border border-slate-100">
        <div className="w-10 h-10 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center shrink-0">
          <Award className="w-5 h-5" />
        </div>
        <div>
          <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide">
            {model.marginWidth !== undefined ? 'Ancho de Margen (2/||w||)' : 'Término Sesgo (b)'}
          </div>
          <div className="text-lg font-black text-slate-800">
            {model.marginWidth !== undefined
              ? model.marginWidth.toFixed(3)
              : model.b.toFixed(3)}
          </div>
          <div className="text-[10px] text-slate-400 font-mono">
            {model.params.kernel === 'linear' && model.weights
              ? `w = [${model.weights[0].toFixed(2)}, ${model.weights[1].toFixed(2)}]`
              : `b = ${model.b.toFixed(3)}`}
          </div>
        </div>
      </div>

      {/* 4. Model Sparsity */}
      <div className="flex items-center gap-3 p-2 rounded-lg bg-slate-50 border border-slate-100">
        <div className="w-10 h-10 rounded-lg bg-sky-100 text-sky-700 flex items-center justify-center shrink-0">
          <Cpu className="w-5 h-5" />
        </div>
        <div>
          <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide">
            Escasez (Sparsity)
          </div>
          <div className="text-lg font-black text-slate-800">
            {totalPoints > 0 ? (100 - parseFloat(svPercentage)).toFixed(0) : 0}%
          </div>
          <div className="text-[10px] text-slate-400">
            Puntos con α = 0 (ignorados)
          </div>
        </div>
      </div>
    </div>
  );
};
