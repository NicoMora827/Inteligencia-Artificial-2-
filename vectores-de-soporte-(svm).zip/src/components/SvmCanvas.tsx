import React, { useRef, useEffect, useState, useCallback } from 'react';
import { Point2D, ClassLabel, SVMModel } from '../types';
import { Target, Trash2, Plus, Sparkles, Move, Info } from 'lucide-react';

interface SvmCanvasProps {
  model: SVMModel;
  points: Point2D[];
  activeClass: ClassLabel;
  onPointsChange: (newPoints: Point2D[]) => void;
  showHeatmap: boolean;
  showMargins: boolean;
  showAlphaLabels: boolean;
}

export const SvmCanvas: React.FC<SvmCanvasProps> = ({
  model,
  points,
  activeClass,
  onPointsChange,
  showHeatmap,
  showMargins,
  showAlphaLabels,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const [hoveredPoint, setHoveredPoint] = useState<{
    point: Point2D;
    canvasX: number;
    canvasY: number;
    alpha?: number;
    fVal?: number;
  } | null>(null);

  const [draggingPointId, setDraggingPointId] = useState<string | null>(null);
  const [dragStartPos, setDragStartPos] = useState<{ x: number; y: number } | null>(null);
  const [hasMoved, setHasMoved] = useState(false);

  // Coordinate transforms: Normalized [-1, 1] <-> Canvas Pixels
  const toCanvasCoords = useCallback(
    (nx: number, ny: number, width: number, height: number) => {
      const padding = 36;
      const effectiveW = width - padding * 2;
      const effectiveH = height - padding * 2;
      const px = padding + ((nx + 1) / 2) * effectiveW;
      const py = padding + ((1 - ny) / 2) * effectiveH; // flip Y
      return { px, py };
    },
    []
  );

  const toNormalizedCoords = useCallback(
    (px: number, py: number, width: number, height: number) => {
      const padding = 36;
      const effectiveW = width - padding * 2;
      const effectiveH = height - padding * 2;
      const nx = ((px - padding) / effectiveW) * 2 - 1;
      const ny = 1 - ((py - padding) / effectiveH) * 2;
      return {
        nx: Math.max(-1, Math.min(1, nx)),
        ny: Math.max(-1, Math.min(1, ny)),
      };
    },
    []
  );

  // Render Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const rect = container.getBoundingClientRect();
    const width = Math.floor(rect.width);
    const height = Math.floor(rect.height);

    if (width <= 0 || height <= 0) return;

    const dpr = window.devicePixelRatio || 1;
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, width, height);

    // 1. Draw Heatmap (Decision Field f(x, y))
    if (showHeatmap && points.length >= 2 && model.supportVectors.length > 0) {
      const gridRes = 70; // resolution for fast rendering
      const cellW = width / gridRes;
      const cellH = height / gridRes;

      for (let i = 0; i < gridRes; i++) {
        for (let j = 0; j < gridRes; j++) {
          const px = (i + 0.5) * cellW;
          const py = (j + 0.5) * cellH;
          const { nx, ny } = toNormalizedCoords(px, py, width, height);
          const f = model.evaluate(nx, ny);

          // Color scale:
          // f > 0: Blue/Indigo
          // f < 0: Coral/Red
          // Margin zone: abs(f) <= 1
          let fillStyle = '';
          const absF = Math.abs(f);
          const tanhScore = Math.tanh(f * 0.9); // smooth sigmoidal clipping between -1 and 1

          if (tanhScore > 0) {
            // Class +1 (Indigo/Blue)
            const alpha = 0.08 + Math.min(0.28, tanhScore * 0.28);
            fillStyle = `rgba(79, 70, 229, ${alpha.toFixed(3)})`;
          } else {
            // Class -1 (Coral/Red)
            const alpha = 0.08 + Math.min(0.28, Math.abs(tanhScore) * 0.28);
            fillStyle = `rgba(239, 68, 68, ${alpha.toFixed(3)})`;
          }

          // Extra subtle highlight in margin corridor
          if (absF <= 1.0) {
            ctx.fillStyle = `rgba(251, 191, 36, 0.07)`;
            ctx.fillRect(i * cellW, j * cellH, cellW + 0.5, cellH + 0.5);
          }

          ctx.fillStyle = fillStyle;
          ctx.fillRect(i * cellW, j * cellH, cellW + 0.5, cellH + 0.5);
        }
      }
    } else {
      // Plain subtle canvas background
      ctx.fillStyle = '#fafbfc';
      ctx.fillRect(0, 0, width, height);
    }

    // 2. Draw Subtle Grid Lines & Axes
    const padding = 36;
    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 1;
    ctx.setLineDash([]);

    // Outer bounding border
    ctx.strokeRect(padding, padding, width - padding * 2, height - padding * 2);

    // Center Axes (nx = 0, ny = 0)
    const center = toCanvasCoords(0, 0, width, height);
    ctx.strokeStyle = '#cbd5e1';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(padding, center.py);
    ctx.lineTo(width - padding, center.py);
    ctx.moveTo(center.px, padding);
    ctx.lineTo(center.px, height - padding);
    ctx.stroke();

    // Axis coordinate text marks
    ctx.fillStyle = '#94a3b8';
    ctx.font = '10px ui-monospace, SFMono-Regular, Menlo, monospace';
    ctx.textAlign = 'center';
    ctx.fillText('0', center.px - 8, center.py + 12);
    ctx.fillText('-1', padding, center.py + 14);
    ctx.fillText('+1', width - padding, center.py + 14);
    ctx.fillText('+1', center.px - 14, padding + 10);
    ctx.fillText('-1', center.px - 14, height - padding);

    // 3. Draw Contour Lines: Decision Boundary f(x)=0, and Margins f(x)=+1, f(x)=-1
    if (points.length >= 2 && model.supportVectors.length > 0) {
      drawContours(ctx, width, height, model, toNormalizedCoords, toCanvasCoords, showMargins);
    }

    // 4. Draw Support Vector Halos and Badges
    const svMap = new Map<number, (typeof model.supportVectors)[0]>();
    model.supportVectors.forEach((sv) => {
      svMap.set(sv.index, sv);
    });

    // 5. Draw Points
    points.forEach((pt, idx) => {
      const { px, py } = toCanvasCoords(pt.x, pt.y, width, height);
      const isSV = svMap.has(idx);
      const svInfo = svMap.get(idx);
      const isPos = pt.label === 1;

      // Draw Support Vector outer halo ring
      if (isSV && svInfo) {
        ctx.save();
        ctx.beginPath();
        ctx.arc(px, py, 14, 0, 2 * Math.PI);
        ctx.fillStyle = svInfo.isBounded
          ? 'rgba(234, 88, 12, 0.16)' // Orange halo for bounded (slack/outlier)
          : 'rgba(16, 185, 129, 0.18)'; // Green/Teal halo for free SV lying exactly on margin
        ctx.fill();

        ctx.lineWidth = 2;
        ctx.setLineDash(svInfo.isBounded ? [3, 2] : []);
        ctx.strokeStyle = svInfo.isBounded ? '#f97316' : '#10b981';
        ctx.stroke();
        ctx.restore();

        // Alpha multiplier badge if enabled
        if (showAlphaLabels) {
          ctx.save();
          const badgeText = `α=${svInfo.alpha.toFixed(2)}`;
          ctx.font = 'bold 9px ui-monospace, monospace';
          const textMetrics = ctx.measureText(badgeText);
          const badgeW = textMetrics.width + 6;
          const badgeH = 14;
          const bx = px + 10;
          const by = py - 18;

          ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
          ctx.beginPath();
          ctx.roundRect(bx, by, badgeW, badgeH, 3);
          ctx.fill();

          ctx.fillStyle = '#ffffff';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(badgeText, bx + badgeW / 2, by + badgeH / 2);
          ctx.restore();
        }
      }

      // Main Point Circle
      ctx.save();
      ctx.beginPath();
      ctx.arc(px, py, 8, 0, 2 * Math.PI);
      ctx.fillStyle = isPos ? '#4f46e5' : '#ef4444'; // Indigo vs Red
      ctx.shadowColor = isPos ? 'rgba(79, 70, 229, 0.35)' : 'rgba(239, 68, 68, 0.35)';
      ctx.shadowBlur = 4;
      ctx.fill();

      // Border stroke
      ctx.shadowBlur = 0;
      ctx.lineWidth = 2;
      ctx.strokeStyle = '#ffffff';
      ctx.stroke();

      // Inner icon '+' or '-'
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 11px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(isPos ? '+' : '−', px, py);
      ctx.restore();
    });

  }, [
    model,
    points,
    showHeatmap,
    showMargins,
    showAlphaLabels,
    toCanvasCoords,
    toNormalizedCoords,
  ]);

  // Handle Dragging & Clicking
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const px = e.clientX - rect.left;
    const py = e.clientY - rect.top;

    // Check if clicked near an existing point
    let clickedPoint: Point2D | null = null;
    for (const pt of points) {
      const { px: ppx, py: ppy } = toCanvasCoords(pt.x, pt.y, rect.width, rect.height);
      const dist = Math.hypot(px - ppx, py - ppy);
      if (dist <= 14) {
        clickedPoint = pt;
        break;
      }
    }

    if (clickedPoint) {
      // Right click or shift-click deletes point
      if (e.button === 2 || e.shiftKey) {
        onPointsChange(points.filter((p) => p.id !== clickedPoint!.id));
        return;
      }

      // Left click initiates drag
      if (e.button === 0) {
        setDraggingPointId(clickedPoint.id);
        setDragStartPos({ x: px, y: py });
        setHasMoved(false);
      }
    }
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const px = e.clientX - rect.left;
    const py = e.clientY - rect.top;

    // Drag point if actively dragging
    if (draggingPointId) {
      if (dragStartPos && Math.hypot(px - dragStartPos.x, py - dragStartPos.y) > 3) {
        setHasMoved(true);
      }
      const { nx, ny } = toNormalizedCoords(px, py, rect.width, rect.height);
      onPointsChange(
        points.map((p) => (p.id === draggingPointId ? { ...p, x: nx, y: ny } : p))
      );
      return;
    }

    // Hover detection for tooltip
    let found: Point2D | null = null;
    for (const pt of points) {
      const { px: ppx, py: ppy } = toCanvasCoords(pt.x, pt.y, rect.width, rect.height);
      if (Math.hypot(px - ppx, py - ppy) <= 12) {
        found = pt;
        const ptIdx = points.findIndex((p) => p.id === pt.id);
        const sv = model.supportVectors.find((s) => s.index === ptIdx);
        const fVal = model.evaluate(pt.x, pt.y);

        setHoveredPoint({
          point: pt,
          canvasX: ppx,
          canvasY: ppy,
          alpha: sv ? sv.alpha : 0,
          fVal,
        });
        break;
      }
    }

    if (!found) {
      setHoveredPoint(null);
    }
  };

  const handleMouseUp = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const px = e.clientX - rect.left;
    const py = e.clientY - rect.top;

    if (draggingPointId) {
      // If user simply clicked without moving, toggle point label or keep
      if (!hasMoved) {
        // Toggle label on simple click
        onPointsChange(
          points.map((p) => (p.id === draggingPointId ? { ...p, label: p.label === 1 ? -1 : 1 } : p))
        );
      }
      setDraggingPointId(null);
      setDragStartPos(null);
      setHasMoved(false);
      return;
    }

    // If clicked on empty space with Left Button, add new point of activeClass
    if (e.button === 0 && px >= 30 && px <= rect.width - 30 && py >= 30 && py <= rect.height - 30) {
      const { nx, ny } = toNormalizedCoords(px, py, rect.width, rect.height);
      const newPt: Point2D = {
        id: `user_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
        x: nx,
        y: ny,
        label: activeClass,
      };
      onPointsChange([...points, newPt]);
    }
  };

  const handleContextMenu = (e: React.MouseEvent) => {
    e.preventDefault(); // Prevent native browser context menu
  };

  return (
    <div
      ref={containerRef}
      id="svm-canvas-container"
      className="relative w-full h-[420px] md:h-[500px] bg-slate-50 rounded-xl overflow-hidden border border-slate-200 shadow-inner select-none cursor-crosshair"
    >
      <canvas
        ref={canvasRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onContextMenu={handleContextMenu}
        className="w-full h-full block"
      />

      {/* Interactive Canvas Overlay Controls / Legend */}
      <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-md px-3 py-2 rounded-lg border border-slate-200/80 shadow-xs flex items-center gap-3 text-xs pointer-events-none">
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-indigo-600 inline-block ring-2 ring-indigo-200" />
          <span className="font-semibold text-slate-700">Clase +1</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-red-500 inline-block ring-2 ring-red-200" />
          <span className="font-semibold text-slate-700">Clase −1</span>
        </div>
        <div className="w-px h-3.5 bg-slate-200" />
        <div className="flex items-center gap-1.5 text-slate-600">
          <span className="w-3 h-3 rounded-full border-2 border-emerald-500 bg-emerald-50 inline-block" />
          <span>Vector de Soporte</span>
        </div>
      </div>

      {/* Floating Canvas Quick Tips */}
      <div className="absolute bottom-3 left-3 bg-white/90 backdrop-blur-sm px-3 py-1.5 rounded-lg border border-slate-200/70 text-[11px] text-slate-500 flex items-center gap-2 pointer-events-none">
        <Move className="w-3.5 h-3.5 text-slate-400" />
        <span>Clic en lienzo para crear • Arrastra puntos para ver ajuste en vivo • Clic sobre punto para invertir clase</span>
      </div>

      {/* Tooltip on Point Hover */}
      {hoveredPoint && (
        <div
          className="absolute z-20 pointer-events-none bg-slate-900/95 text-white text-xs px-3 py-2 rounded-lg shadow-xl border border-slate-700 max-w-[200px]"
          style={{
            left: Math.min(hoveredPoint.canvasX + 14, (containerRef.current?.clientWidth || 400) - 210),
            top: Math.max(10, hoveredPoint.canvasY - 55),
          }}
        >
          <div className="flex items-center justify-between gap-2 border-b border-slate-700 pb-1 mb-1 font-semibold">
            <span className={hoveredPoint.point.label === 1 ? 'text-indigo-400' : 'text-red-400'}>
              Clase {hoveredPoint.point.label === 1 ? '+1' : '−1'}
            </span>
            <span className="text-[10px] text-slate-400 font-mono">
              ({hoveredPoint.point.x.toFixed(2)}, {hoveredPoint.point.y.toFixed(2)})
            </span>
          </div>
          <div className="text-[11px] space-y-0.5 text-slate-300">
            <div className="flex justify-between">
              <span className="text-slate-400">f(x):</span>
              <span className="font-mono font-bold text-amber-300">{hoveredPoint.fVal?.toFixed(3)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Multiplicador α:</span>
              <span className="font-mono font-bold text-emerald-400">
                {hoveredPoint.alpha !== undefined && hoveredPoint.alpha > 0.0001
                  ? hoveredPoint.alpha.toFixed(3)
                  : '0.000 (No es SV)'}
              </span>
            </div>
            {hoveredPoint.alpha !== undefined && hoveredPoint.alpha > 0.0001 && (
              <div className="text-[10px] text-emerald-300 italic pt-0.5">
                ★ Determina la frontera de decisión
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

/**
 * Draws contour lines for Decision Boundary f(x) = 0, and Margins f(x) = +1 and f(x) = -1
 * using grid marching squares interpolation
 */
function drawContours(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  model: SVMModel,
  toNormalizedCoords: (px: number, py: number, w: number, h: number) => { nx: number; ny: number },
  toCanvasCoords: (nx: number, ny: number, w: number, h: number) => { px: number; py: number },
  showMargins: boolean
) {
  const steps = 70;
  const dx = width / steps;
  const dy = height / steps;

  // Grid evaluation cache
  const grid: number[][] = Array.from({ length: steps + 1 }, () => new Array(steps + 1));
  for (let i = 0; i <= steps; i++) {
    for (let j = 0; j <= steps; j++) {
      const px = i * dx;
      const py = j * dy;
      const { nx, ny } = toNormalizedCoords(px, py, width, height);
      grid[i][j] = model.evaluate(nx, ny);
    }
  }

  // Draw Margins f(x) = +1 and f(x) = -1
  if (showMargins) {
    // Margin +1 (Indigo dashed)
    ctx.strokeStyle = 'rgba(79, 70, 229, 0.85)';
    ctx.lineWidth = 1.6;
    ctx.setLineDash([4, 4]);
    traceLevelContour(ctx, grid, 1.0, steps, dx, dy);

    // Margin -1 (Red dashed)
    ctx.strokeStyle = 'rgba(239, 68, 68, 0.85)';
    ctx.lineWidth = 1.6;
    ctx.setLineDash([4, 4]);
    traceLevelContour(ctx, grid, -1.0, steps, dx, dy);
  }

  // Draw Main Decision Boundary f(x) = 0 (Crisp dark solid line)
  ctx.strokeStyle = '#0f172a';
  ctx.lineWidth = 2.4;
  ctx.setLineDash([]);
  traceLevelContour(ctx, grid, 0.0, steps, dx, dy);
}

function traceLevelContour(
  ctx: CanvasRenderingContext2D,
  grid: number[][],
  level: number,
  steps: number,
  dx: number,
  dy: number
) {
  ctx.beginPath();

  for (let i = 0; i < steps; i++) {
    for (let j = 0; j < steps; j++) {
      const v00 = grid[i][j] - level;
      const v10 = grid[i + 1][j] - level;
      const v11 = grid[i + 1][j + 1] - level;
      const v01 = grid[i][j + 1] - level;

      const x0 = i * dx;
      const x1 = (i + 1) * dx;
      const y0 = j * dy;
      const y1 = (j + 1) * dy;

      // Bitmask for corners > 0
      let mask = 0;
      if (v00 > 0) mask |= 1;
      if (v10 > 0) mask |= 2;
      if (v11 > 0) mask |= 4;
      if (v01 > 0) mask |= 8;

      if (mask === 0 || mask === 15) continue; // No crossing

      const getInterp = (va: number, vb: number) => {
        const denom = va - vb;
        if (Math.abs(denom) < 1e-9) return 0.5;
        return Math.max(0, Math.min(1, va / denom));
      };

      // Midpoints on edges
      // Edge 0: Top (between (i,j) and (i+1,j))
      const topT = getInterp(v00, v10);
      const topX = x0 + topT * dx;
      const topY = y0;

      // Edge 1: Right (between (i+1,j) and (i+1,j+1))
      const rightT = getInterp(v10, v11);
      const rightX = x1;
      const rightY = y0 + rightT * dy;

      // Edge 2: Bottom (between (i,j+1) and (i+1,j+1))
      const bottomT = getInterp(v01, v11);
      const bottomX = x0 + bottomT * dx;
      const bottomY = y1;

      // Edge 3: Left (between (i,j) and (i,j+1))
      const leftT = getInterp(v00, v01);
      const leftX = x0;
      const leftY = y0 + leftT * dy;

      // Connect line segments based on marching squares table
      switch (mask) {
        case 1:
        case 14:
          ctx.moveTo(topX, topY);
          ctx.lineTo(leftX, leftY);
          break;
        case 2:
        case 13:
          ctx.moveTo(topX, topY);
          ctx.lineTo(rightX, rightY);
          break;
        case 3:
        case 12:
          ctx.moveTo(leftX, leftY);
          ctx.lineTo(rightX, rightY);
          break;
        case 4:
        case 11:
          ctx.moveTo(rightX, rightY);
          ctx.lineTo(bottomX, bottomY);
          break;
        case 5:
          ctx.moveTo(topX, topY);
          ctx.lineTo(leftX, leftY);
          ctx.moveTo(rightX, rightY);
          ctx.lineTo(bottomX, bottomY);
          break;
        case 6:
        case 9:
          ctx.moveTo(topX, topY);
          ctx.lineTo(bottomX, bottomY);
          break;
        case 7:
        case 8:
          ctx.moveTo(leftX, leftY);
          ctx.lineTo(bottomX, bottomY);
          break;
        case 10:
          ctx.moveTo(topX, topY);
          ctx.lineTo(rightX, rightY);
          ctx.moveTo(leftX, leftY);
          ctx.lineTo(bottomX, bottomY);
          break;
      }
    }
  }

  ctx.stroke();
}
