import React, { useState } from 'react';
import { BookOpen, ChevronDown, ChevronUp, Check, AlertCircle, Compass, Sparkles, Binary } from 'lucide-react';

export const TheoryGuide: React.FC = () => {
  const [openSection, setOpenSection] = useState<string | null>('que-es');

  const toggle = (id: string) => {
    setOpenSection(openSection === id ? null : id);
  };

  return (
    <div id="theory-guide" className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs space-y-3">
      <div className="flex items-center justify-between border-b border-slate-100 pb-3">
        <div className="flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-indigo-600" />
          <h3 className="font-bold text-slate-800 text-base">
            Fundamentos Teóricos: Máquinas de Vectores de Soporte (SVM)
          </h3>
        </div>
        <span className="text-xs bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded-full font-medium">
          Guía Interactiva
        </span>
      </div>

      <div className="space-y-2 text-xs">
        {/* Section 1: ¿Qué es un Vector de Soporte? */}
        <div className="border border-slate-200 rounded-lg overflow-hidden">
          <button
            onClick={() => toggle('que-es')}
            className="w-full text-left px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100/80 font-semibold text-slate-800 flex items-center justify-between transition-colors"
          >
            <span className="flex items-center gap-2">
              <Compass className="w-4 h-4 text-indigo-600" />
              1. ¿Qué es exactamente un Vector de Soporte?
            </span>
            {openSection === 'que-es' ? (
              <ChevronUp className="w-4 h-4 text-slate-500" />
            ) : (
              <ChevronDown className="w-4 h-4 text-slate-500" />
            )}
          </button>
          {openSection === 'que-es' && (
            <div className="p-3.5 bg-white text-slate-600 space-y-2 leading-relaxed border-t border-slate-100">
              <p>
                En una Máquina de Vectores de Soporte (SVM), los <strong>vectores de soporte</strong> son
                los puntos de datos de entrenamiento que se encuentran más cerca del hiperplano de
                decisión y que <em>«sostienen»</em> o definen la posición y orientación de la frontera.
              </p>
              <div className="p-2.5 bg-indigo-50/70 rounded-md border border-indigo-100 text-indigo-900">
                <div className="font-semibold flex items-center gap-1.5 mb-1 text-[11px]">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                  Propiedad clave de Escasez (Sparsity):
                </div>
                Si eliminas del dataset cualquiera de los puntos que <em>no</em> son vectores de soporte,
                el hiperplano de decisión calculado <strong>no cambiará en absoluto</strong>. Solo los
                vectores de soporte tienen multiplicador de Lagrange <code className="font-mono bg-white px-1 py-0.5 rounded">αᵢ &gt; 0</code>.
              </div>
            </div>
          )}
        </div>

        {/* Section 2: El Margen Máximo y la Geometría */}
        <div className="border border-slate-200 rounded-lg overflow-hidden">
          <button
            onClick={() => toggle('margen')}
            className="w-full text-left px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100/80 font-semibold text-slate-800 flex items-center justify-between transition-colors"
          >
            <span className="flex items-center gap-2">
              <Binary className="w-4 h-4 text-indigo-600" />
              2. Hiperplano Óptimo y Margen Máximo (2 / ||w||)
            </span>
            {openSection === 'margen' ? (
              <ChevronUp className="w-4 h-4 text-slate-500" />
            ) : (
              <ChevronDown className="w-4 h-4 text-slate-500" />
            )}
          </button>
          {openSection === 'margen' && (
            <div className="p-3.5 bg-white text-slate-600 space-y-2 leading-relaxed border-t border-slate-100">
              <p>
                A diferencia de otros clasificadores (como regresión logística o perceptrones que eligen
                cualquier línea divisoria), la SVM busca el <strong>hiperplano con máximo margen</strong>,
                es decir, la mayor separación física posible entre ambas clases.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 my-2 font-mono text-[11px]">
                <div className="p-2 bg-slate-50 rounded border border-slate-200">
                  <div className="font-bold text-slate-700">Frontera de Decisión:</div>
                  <div className="text-indigo-600">w · x − b = 0</div>
                </div>
                <div className="p-2 bg-slate-50 rounded border border-slate-200">
                  <div className="font-bold text-slate-700">Líneas de Margen:</div>
                  <div className="text-emerald-600">w · x − b = +1 (Clase +1)</div>
                  <div className="text-red-600">w · x − b = −1 (Clase −1)</div>
                </div>
              </div>
              <p>
                La distancia entre ambas líneas de margen es igual a{' '}
                <code className="font-mono bg-slate-100 px-1 py-0.5 rounded font-bold text-slate-800">
                  M = 2 / ||w||
                </code>
                . Por tanto, maximizar el margen equivale a minimizar{' '}
                <code className="font-mono bg-slate-100 px-1 py-0.5 rounded">½ ||w||²</code>.
              </p>
            </div>
          )}
        </div>

        {/* Section 3: Margen Blando y Parámetro C */}
        <div className="border border-slate-200 rounded-lg overflow-hidden">
          <button
            onClick={() => toggle('parametro-c')}
            className="w-full text-left px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100/80 font-semibold text-slate-800 flex items-center justify-between transition-colors"
          >
            <span className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-amber-600" />
              3. Margen Blando (Soft Margin) y el Parámetro C
            </span>
            {openSection === 'parametro-c' ? (
              <ChevronUp className="w-4 h-4 text-slate-500" />
            ) : (
              <ChevronDown className="w-4 h-4 text-slate-500" />
            )}
          </button>
          {openSection === 'parametro-c' && (
            <div className="p-3.5 bg-white text-slate-600 space-y-2 leading-relaxed border-t border-slate-100">
              <p>
                En el mundo real, los datos rara vez son perfectamente separables debido a ruido o
                solapamiento. Para permitir que algunos puntos caigan dentro del margen o se clasifiquen
                erróneamente sin romper el modelo, introducimos <strong>variables de holgura (slack) ξᵢ ≥ 0</strong>:
              </p>
              <div className="p-2 bg-slate-50 rounded border border-slate-200 font-mono text-[11px] text-center text-slate-800">
                min ½ ||w||² + C ∑ ξᵢ &emsp; sujeto a &emsp; yᵢ(w·xᵢ − b) ≥ 1 − ξᵢ
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 text-[11px]">
                <div className="p-2 rounded bg-amber-50 border border-amber-200 text-amber-900">
                  <strong>C Grande (Hard Margin):</strong> Penaliza fuertemente cualquier error.
                  Produce márgenes estrechos. Si hay ruido, puede sobreajustar (overfitting).
                </div>
                <div className="p-2 rounded bg-blue-50 border border-blue-200 text-blue-900">
                  <strong>C Pequeño (Soft Margin):</strong> Tolera puntos dentro del margen a cambio
                  de un margen más amplio y mayor robustez ante nuevos datos.
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Section 4: El Truco del Kernel */}
        <div className="border border-slate-200 rounded-lg overflow-hidden">
          <button
            onClick={() => toggle('kernel-trick')}
            className="w-full text-left px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100/80 font-semibold text-slate-800 flex items-center justify-between transition-colors"
          >
            <span className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-600" />
              4. El Truco del Kernel (Kernel Trick)
            </span>
            {openSection === 'kernel-trick' ? (
              <ChevronUp className="w-4 h-4 text-slate-500" />
            ) : (
              <ChevronDown className="w-4 h-4 text-slate-500" />
            )}
          </button>
          {openSection === 'kernel-trick' && (
            <div className="p-3.5 bg-white text-slate-600 space-y-2 leading-relaxed border-t border-slate-100">
              <p>
                ¿Cómo clasificar datos no lineales (como círculos concéntricos o XOR)?
                La idea revolucionaria de Vladimir Vapnik fue proyectar los datos a un espacio de
                características de mayor dimensión mediante una función <code className="font-mono bg-slate-100 px-1 py-0.5 rounded">Φ(x)</code> donde los datos se vuelven linealmente separables.
              </p>
              <p>
                El <strong>Truco del Kernel</strong> nos permite calcular el producto escalar en ese espacio
                de dimensión infinita sin necesidad de calcular explícitamente las coordenadas:{' '}
                <code className="font-mono font-bold text-indigo-700">K(x, z) = ⟨Φ(x), Φ(z)⟩</code>.
              </p>
              <div className="space-y-1.5 pt-1 text-[11px]">
                <div className="flex gap-2">
                  <span className="font-bold text-slate-700 w-24 shrink-0">• RBF / Gaussiano:</span>
                  <span>Mapea a un espacio de dimensión infinita. Parámetro γ controla el alcance de cada vector.</span>
                </div>
                <div className="flex gap-2">
                  <span className="font-bold text-slate-700 w-24 shrink-0">• Polinómico:</span>
                  <span>Genera combinaciones polinómicas (cruces x₁·x₂, potencias x₁², etc.).</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
