import { PresetDataset, Point2D } from '../types';

function createId(prefix: string, idx: number): string {
  return `${prefix}_${idx}_${Math.random().toString(36).substr(2, 4)}`;
}

// Generates linearly separable clusters
function getSeparableDataset(): Point2D[] {
  const points: Point2D[] = [];
  // Class +1 (top-right cluster)
  const posCenters = [
    { x: 0.35, y: 0.4 },
    { x: 0.55, y: 0.6 },
    { x: 0.3, y: 0.75 },
    { x: 0.65, y: 0.35 },
    { x: 0.5, y: 0.45 },
    { x: 0.25, y: 0.55 },
    { x: 0.7, y: 0.7 },
    { x: 0.45, y: 0.8 },
  ];
  posCenters.forEach((p, i) => {
    points.push({ id: createId('pos', i), x: p.x, y: p.y, label: 1 });
  });

  // Class -1 (bottom-left cluster)
  const negCenters = [
    { x: -0.35, y: -0.35 },
    { x: -0.55, y: -0.5 },
    { x: -0.25, y: -0.65 },
    { x: -0.65, y: -0.3 },
    { x: -0.45, y: -0.45 },
    { x: -0.3, y: -0.25 },
    { x: -0.7, y: -0.65 },
    { x: -0.5, y: -0.75 },
  ];
  negCenters.forEach((p, i) => {
    points.push({ id: createId('neg', i), x: p.x, y: p.y, label: -1 });
  });

  return points;
}

// Generates dataset with overlapping points to showcase Soft-Margin (C parameter)
function getOverlappingDataset(): Point2D[] {
  const points: Point2D[] = [];
  // Positives centered at x: 0.25, y: 0.2
  const posCoords = [
    { x: 0.2, y: 0.4 },
    { x: 0.4, y: 0.3 },
    { x: 0.3, y: 0.1 },
    { x: 0.5, y: 0.5 },
    { x: 0.15, y: 0.25 },
    { x: 0.6, y: 0.2 },
    { x: -0.1, y: 0.05 }, // Outlier in negative territory
    { x: 0.35, y: -0.05 },
    { x: 0.45, y: 0.45 },
  ];
  posCoords.forEach((p, i) => {
    points.push({ id: createId('pos', i), x: p.x, y: p.y, label: 1 });
  });

  // Negatives centered at x: -0.25, y: -0.2
  const negCoords = [
    { x: -0.3, y: -0.2 },
    { x: -0.4, y: -0.4 },
    { x: -0.15, y: -0.3 },
    { x: -0.5, y: -0.1 },
    { x: -0.25, y: -0.5 },
    { x: -0.1, y: -0.15 },
    { x: 0.1, y: 0.0 }, // Outlier in positive territory
    { x: -0.45, y: -0.35 },
    { x: -0.35, y: 0.1 },
  ];
  negCoords.forEach((p, i) => {
    points.push({ id: createId('neg', i), x: p.x, y: p.y, label: -1 });
  });

  return points;
}

// Generates concentric circles (ideal to showcase RBF kernel and 3D projection)
function getCirclesDataset(): Point2D[] {
  const points: Point2D[] = [];
  // Inner circle: Class +1, radius ~ 0.28
  const nInner = 12;
  for (let i = 0; i < nInner; i++) {
    const angle = (i / nInner) * 2 * Math.PI;
    const r = 0.25 + (Math.sin(i * 3) * 0.05);
    points.push({
      id: createId('inner', i),
      x: Math.cos(angle) * r,
      y: Math.sin(angle) * r,
      label: 1,
    });
  }

  // Outer ring: Class -1, radius ~ 0.7
  const nOuter = 18;
  for (let i = 0; i < nOuter; i++) {
    const angle = (i / nOuter) * 2 * Math.PI + 0.15;
    const r = 0.68 + (Math.cos(i * 2) * 0.06);
    points.push({
      id: createId('outer', i),
      x: Math.cos(angle) * r,
      y: Math.sin(angle) * r,
      label: -1,
    });
  }

  return points;
}

// Generates classic Two Moons dataset
function getMoonsDataset(): Point2D[] {
  const points: Point2D[] = [];
  const n = 12;

  // Upper moon: Class +1
  for (let i = 0; i < n; i++) {
    const theta = (i / (n - 1)) * Math.PI;
    const r = 0.5 + Math.sin(i * 1.5) * 0.04;
    points.push({
      id: createId('moon1', i),
      x: Math.cos(theta) * r - 0.25,
      y: Math.sin(theta) * r + 0.1,
      label: 1,
    });
  }

  // Lower moon: Class -1
  for (let i = 0; i < n; i++) {
    const theta = (i / (n - 1)) * Math.PI;
    const r = 0.5 + Math.cos(i * 1.7) * 0.04;
    points.push({
      id: createId('moon2', i),
      x: 0.25 - Math.cos(theta) * r,
      y: -Math.sin(theta) * r - 0.1,
      label: -1,
    });
  }

  return points;
}

// Generates classic XOR problem (4 quadrants)
function getXorDataset(): Point2D[] {
  const points: Point2D[] = [];
  const configs = [
    { cx: 0.5, cy: 0.5, label: 1 as const },
    { cx: -0.5, cy: -0.5, label: 1 as const },
    { cx: -0.5, cy: 0.5, label: -1 as const },
    { cx: 0.5, cy: -0.5, label: -1 as const },
  ];

  configs.forEach((cluster, cIdx) => {
    const offsets = [
      { ox: 0, oy: 0 },
      { ox: 0.12, oy: 0.1 },
      { ox: -0.1, oy: 0.12 },
      { ox: 0.08, oy: -0.11 },
    ];
    offsets.forEach((off, oIdx) => {
      points.push({
        id: createId(`xor_${cIdx}`, oIdx),
        x: cluster.cx + off.ox,
        y: cluster.cy + off.oy,
        label: cluster.label,
      });
    });
  });

  return points;
}

export const PRESET_DATASETS: PresetDataset[] = [
  {
    id: 'separable',
    name: 'Linealmente Separable',
    description: 'Dos clases limpiamente separadas. Permite visualizar el margen máximo estricto y los vectores de soporte limítrofes.',
    recommendedKernel: 'linear',
    recommendedC: 10,
    recommendedGamma: 1.0,
    points: getSeparableDataset(),
  },
  {
    id: 'overlapping',
    name: 'Margen Blando (Overlapping)',
    description: 'Puntos cercanos y solapados con ruido. Permite explorar el impacto de C y las variables de holgura (slack ξ_i).',
    recommendedKernel: 'linear',
    recommendedC: 1.0,
    recommendedGamma: 1.0,
    points: getOverlappingDataset(),
  },
  {
    id: 'circles',
    name: 'Círculos Concéntricos',
    description: 'Imposible de separar con hiperplano lineal en 2D. Se resuelve elegantemente con el kernel RBF o el truco del kernel 3D.',
    recommendedKernel: 'rbf',
    recommendedC: 10,
    recommendedGamma: 3.5,
    points: getCirclesDataset(),
  },
  {
    id: 'moons',
    name: 'Dos Lunas Entrelazadas',
    description: 'Frontera de decisión no lineal suave. Ilustra cómo el kernel Gaussiano se adapta a la geometría de los datos.',
    recommendedKernel: 'rbf',
    recommendedC: 20,
    recommendedGamma: 2.5,
    points: getMoonsDataset(),
  },
  {
    id: 'xor',
    name: 'Problema XOR',
    description: 'Cuatro cuadrantes alternados. Caso histórico donde clasificadores lineales fallan por completo; el kernel crea islas de decisión.',
    recommendedKernel: 'rbf',
    recommendedC: 10,
    recommendedGamma: 2.0,
    points: getXorDataset(),
  },
];
