import { ClassLabel, KernelType, Point2D, SupportVectorInfo, SVMModel, SVMParams } from '../types';

export function computeKernel(
  p1: { x: number; y: number },
  p2: { x: number; y: number },
  kernel: KernelType,
  gamma: number = 1.0,
  degree: number = 3,
  coef0: number = 1.0
): number {
  const dot = p1.x * p2.x + p1.y * p2.y;

  switch (kernel) {
    case 'linear':
      return dot;
    case 'rbf': {
      const dx = p1.x - p2.x;
      const dy = p1.y - p2.y;
      const distSq = dx * dx + dy * dy;
      return Math.exp(-gamma * distSq);
    }
    case 'poly':
      return Math.pow(dot + coef0, degree);
    case 'sigmoid':
      return Math.tanh(gamma * dot + coef0);
    default:
      return dot;
  }
}

/**
 * Train an SVM model using Simplified Sequential Minimal Optimization (SMO)
 * Formulates the dual quadratic programming problem:
 *   max sum(alpha_i) - 0.5 * sum_i sum_j (alpha_i * alpha_j * y_i * y_j * K(x_i, x_j))
 *   subject to: 0 <= alpha_i <= C and sum(alpha_i * y_i) = 0
 */
export function trainSVM(points: Point2D[], params: SVMParams): SVMModel {
  const n = points.length;

  // Fallback if there are fewer than 2 points or only one class
  const labels = points.map((p) => p.label);
  const hasPos = labels.includes(1);
  const hasNeg = labels.includes(-1);

  if (n < 2 || !hasPos || !hasNeg) {
    return createTrivialModel(points, params);
  }

  const { kernel, C, gamma, degree, coef0, tol, maxPasses } = params;

  // Precompute Kernel Gram Matrix: K_mat[i][j] = K(x_i, x_j)
  const K_mat: number[][] = Array.from({ length: n }, () => new Array(n));
  for (let i = 0; i < n; i++) {
    for (let j = i; j < n; j++) {
      const kVal = computeKernel(points[i], points[j], kernel, gamma, degree, coef0);
      K_mat[i][j] = kVal;
      K_mat[j][i] = kVal;
    }
  }

  const alphas = new Float64Array(n);
  let b = 0;
  let passes = 0;
  const maxIterations = Math.max(100, maxPasses * 40);
  let totalIterations = 0;

  // Decision function during training using cached alphas
  const computeF = (idx: number): number => {
    let sum = 0;
    for (let j = 0; j < n; j++) {
      if (alphas[j] > 1e-7) {
        sum += alphas[j] * labels[j] * K_mat[j][idx];
      }
    }
    return sum - b;
  };

  while (passes < maxPasses && totalIterations < maxIterations) {
    let numChangedAlphas = 0;
    totalIterations++;

    for (let i = 0; i < n; i++) {
      const Ei = computeF(i) - labels[i];

      // KKT condition check
      const condition1 = labels[i] * Ei < -tol && alphas[i] < C;
      const condition2 = labels[i] * Ei > tol && alphas[i] > 0;

      if (condition1 || condition2) {
        // Select random j != i
        let j = Math.floor(Math.random() * (n - 1));
        if (j >= i) j++;

        const Ej = computeF(j) - labels[j];

        const alphaIOld = alphas[i];
        const alphaJOld = alphas[j];

        // Compute lower and upper bounds L and H for alpha_j
        let L = 0;
        let H = 0;
        if (labels[i] !== labels[j]) {
          L = Math.max(0, alphas[j] - alphas[i]);
          H = Math.min(C, C + alphas[j] - alphas[i]);
        } else {
          L = Math.max(0, alphas[i] + alphas[j] - C);
          H = Math.min(C, alphas[i] + alphas[j]);
        }

        if (Math.abs(L - H) < 1e-6) continue;

        // Compute eta = 2*K(i, j) - K(i, i) - K(j, j)
        const eta = 2 * K_mat[i][j] - K_mat[i][i] - K_mat[j][j];
        if (eta >= 0) continue; // eta must be negative for standard quadratic maximum

        // Update alpha_j
        let alphaJNew = alphaJOld - (labels[j] * (Ei - Ej)) / eta;

        // Clip alpha_j to [L, H]
        if (alphaJNew > H) alphaJNew = H;
        else if (alphaJNew < L) alphaJNew = L;

        if (Math.abs(alphaJNew - alphaJOld) < 1e-5) continue;

        // Update alpha_i
        const alphaINew = alphaIOld + labels[i] * labels[j] * (alphaJOld - alphaJNew);

        // Update bias threshold b
        const b1 =
          b -
          Ei -
          labels[i] * (alphaINew - alphaIOld) * K_mat[i][i] -
          labels[j] * (alphaJNew - alphaJOld) * K_mat[i][j];

        const b2 =
          b -
          Ej -
          labels[i] * (alphaINew - alphaIOld) * K_mat[i][j] -
          labels[j] * (alphaJNew - alphaJOld) * K_mat[j][j];

        if (alphaINew > 0 && alphaINew < C) {
          b = b1;
        } else if (alphaJNew > 0 && alphaJNew < C) {
          b = b2;
        } else {
          b = (b1 + b2) / 2;
        }

        alphas[i] = alphaINew;
        alphas[j] = alphaJNew;
        numChangedAlphas++;
      }
    }

    if (numChangedAlphas === 0) {
      passes++;
    } else {
      passes = 0;
    }
  }

  // Identify Support Vectors
  const svThreshold = 1e-4;
  const supportVectors: SupportVectorInfo[] = [];

  for (let i = 0; i < n; i++) {
    const alphaVal = alphas[i];
    if (alphaVal > svThreshold) {
      const isBounded = Math.abs(alphaVal - C) < 1e-3;
      const isFree = alphaVal > svThreshold && !isBounded;
      supportVectors.push({
        index: i,
        point: points[i],
        alpha: alphaVal,
        isBounded,
        isFree,
      });
    }
  }

  // Refine bias threshold b using free support vectors if any
  const freeSVs = supportVectors.filter((sv) => sv.isFree);
  if (freeSVs.length > 0) {
    let bSum = 0;
    for (const sv of freeSVs) {
      let wx = 0;
      for (const otherSv of supportVectors) {
        wx += otherSv.alpha * otherSv.point.label * K_mat[otherSv.index][sv.index];
      }
      bSum += wx - sv.point.label;
    }
    b = bSum / freeSVs.length;
  }

  // For linear kernel, compute explicit primal weights w and margin width
  let weights: [number, number] | undefined = undefined;
  let marginWidth: number | undefined = undefined;

  if (kernel === 'linear') {
    let wx = 0;
    let wy = 0;
    for (const sv of supportVectors) {
      const coef = sv.alpha * sv.point.label;
      wx += coef * sv.point.x;
      wy += coef * sv.point.y;
    }
    weights = [wx, wy];
    const normW = Math.sqrt(wx * wx + wy * wy);
    marginWidth = normW > 1e-6 ? 2 / normW : 0;
  }

  // Evaluation function for any arbitrary 2D coordinate
  const evaluate = (x: number, y: number): number => {
    let sum = 0;
    const testPoint = { x, y };
    for (const sv of supportVectors) {
      const k = computeKernel(sv.point, testPoint, kernel, gamma, degree, coef0);
      sum += sv.alpha * sv.point.label * k;
    }
    return sum - b;
  };

  const predict = (x: number, y: number): ClassLabel => {
    return evaluate(x, y) >= 0 ? 1 : -1;
  };

  // Compute accuracy and confusion matrix
  let tp = 0;
  let fp = 0;
  let tn = 0;
  let fn = 0;

  for (const pt of points) {
    const pred = predict(pt.x, pt.y);
    if (pt.label === 1) {
      if (pred === 1) tp++;
      else fn++;
    } else {
      if (pred === -1) tn++;
      else fp++;
    }
  }

  const accuracy = n > 0 ? (tp + tn) / n : 0;

  return {
    params,
    points,
    alphas: Array.from(alphas),
    b,
    supportVectors,
    weights,
    marginWidth,
    accuracy,
    confusionMatrix: { tp, fp, tn, fn },
    evaluate,
    predict,
  };
}

function createTrivialModel(points: Point2D[], params: SVMParams): SVMModel {
  const majorityClass: ClassLabel =
    points.filter((p) => p.label === 1).length >= points.filter((p) => p.label === -1).length
      ? 1
      : -1;

  return {
    params,
    points,
    alphas: new Array(points.length).fill(0),
    b: 0,
    supportVectors: [],
    accuracy: points.length > 0 ? 0.5 : 1,
    confusionMatrix: { tp: 0, fp: 0, tn: 0, fn: 0 },
    evaluate: () => (majorityClass === 1 ? 1 : -1),
    predict: () => majorityClass,
  };
}
