export type ClassLabel = 1 | -1;

export interface Point2D {
  id: string;
  x: number; // Normalized range [-1, 1] or canvas coords
  y: number;
  label: ClassLabel;
}

export type KernelType = 'linear' | 'rbf' | 'poly' | 'sigmoid';

export interface SVMParams {
  kernel: KernelType;
  C: number;           // Regularization penalty (soft margin)
  gamma: number;       // RBF/Sigmoid bandwidth/spread
  degree: number;      // Polynomial degree
  coef0: number;       // Independent term for poly and sigmoid
  tol: number;         // Tolerance for stopping criterion
  maxPasses: number;   // Number of iterations without change
}

export interface SupportVectorInfo {
  index: number;
  point: Point2D;
  alpha: number;
  isBounded: boolean;  // alpha == C (violates margin or misclassified)
  isFree: boolean;     // 0 < alpha < C (lies exactly on margin)
}

export interface SVMModel {
  params: SVMParams;
  points: Point2D[];
  alphas: number[];
  b: number;
  supportVectors: SupportVectorInfo[];
  weights?: [number, number]; // Only for linear kernel: w = sum(alpha_i * y_i * x_i)
  marginWidth?: number;       // 2 / ||w|| for linear
  accuracy: number;
  confusionMatrix: {
    tp: number;
    fp: number;
    tn: number;
    fn: number;
  };
  evaluate: (x: number, y: number) => number;
  predict: (x: number, y: number) => ClassLabel;
}

export type PresetDatasetId = 'separable' | 'overlapping' | 'circles' | 'moons' | 'xor' | 'spiral';

export interface PresetDataset {
  id: PresetDatasetId;
  name: string;
  description: string;
  recommendedKernel: KernelType;
  recommendedC: number;
  recommendedGamma: number;
  points: Point2D[];
}
