import { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { SwissRollConfig, Point3D, PCAResult, ViewMode, CameraPreset, GuideStep } from './types';
import { generateSwissRoll } from './utils/math';
import { ThreeCanvas } from './components/ThreeCanvas';
import { ScatterPlot2D } from './components/ScatterPlot2D';
import { DidacticGuide, GUIDE_STEPS } from './components/DidacticGuide';
import { ControlsPanel } from './components/ControlsPanel';
import { MathExplainer } from './components/MathExplainer';
import {
  Sparkles,
  Layers,
  BookOpen,
  Sliders,
  HelpCircle,
  BrainCircuit,
  Compass,
  ArrowRight,
  Maximize2,
  Minimize2,
  X
} from 'lucide-react';

export default function App() {
  // Configuration for Swiss Roll generator
  const [config, setConfig] = useState<SwissRollConfig>({
    numPoints: 1000,
    noise: 0.1,
    turns: 1.5,
    height: 22,
    speed: 1,
  });

  // Generated points & computed PCA
  const [dataVersion, setDataVersion] = useState(0);
  const { points, pca } = useMemo(() => {
    return generateSwissRoll(config);
  }, [config, dataVersion]);

  // Projection animation & interaction states
  const [projectionProgress, setProjectionProgress] = useState<number>(0); // 0 (3D) -> 1 (2D)
  const [isAnimating, setIsAnimating] = useState<boolean>(false);
  const animationRef = useRef<number | null>(null);

  // 3D visual toggles
  const [showPCAPlane, setShowPCAPlane] = useState<boolean>(true);
  const [showEigenvectors, setShowEigenvectors] = useState<boolean>(true);
  const [showProjectionLines, setShowProjectionLines] = useState<boolean>(false);

  // 2D View mode: 'pca' | 'unrolled' | 'comparison'
  const [viewMode, setViewMode] = useState<ViewMode>('pca');

  // Interactive point selection
  const [selectedPointId, setSelectedPointId] = useState<number | null>(null);

  // Camera preset trigger
  const [cameraPresetTrigger, setCameraPresetTrigger] = useState<{
    preset: CameraPreset;
    nonce: number;
  } | null>(null);

  // Didactic Step state
  const [currentStep, setCurrentStep] = useState<number>(0);
  const [activeTab, setActiveTab] = useState<'guide' | 'controls' | 'math'>('guide');
  const [isHelpOpen, setIsHelpOpen] = useState<boolean>(false);

  // Smooth projection animation loop
  useEffect(() => {
    if (!isAnimating) {
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
      return;
    }

    let direction = 1;
    let lastTime = performance.now();

    const loop = (time: number) => {
      const dt = (time - lastTime) / 1000;
      lastTime = time;

      setProjectionProgress((prev) => {
        let next = prev + direction * dt * 0.45;
        if (next >= 1) {
          next = 1;
          direction = -1;
        } else if (next <= 0) {
          next = 0;
          direction = 1;
        }
        return next;
      });

      animationRef.current = requestAnimationFrame(loop);
    };

    animationRef.current = requestAnimationFrame(loop);

    return () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    };
  }, [isAnimating]);

  // Apply didactic guide step settings to the scene
  const handleApplyStepSettings = useCallback((step: GuideStep) => {
    if (step.cameraPreset) {
      setCameraPresetTrigger({ preset: step.cameraPreset, nonce: Date.now() });
    }
    if (step.projectionProgress !== undefined) {
      setProjectionProgress(step.projectionProgress);
      setIsAnimating(false);
    }
    if (step.showPCAPlane !== undefined) {
      setShowPCAPlane(step.showPCAPlane);
    }
    if (step.showEigenvectors !== undefined) {
      setShowEigenvectors(step.showEigenvectors);
    }
    if (step.showProjectionLines !== undefined) {
      setShowProjectionLines(step.showProjectionLines);
    }
    if (step.targetViewMode !== undefined) {
      setViewMode(step.targetViewMode);
    }
  }, []);

  // Camera trigger helper
  const handleSetCameraPreset = useCallback((preset: CameraPreset) => {
    setCameraPresetTrigger({ preset, nonce: Date.now() });
  }, []);

  // Regenerate random dataset
  const handleRegenerateData = useCallback(() => {
    setDataVersion((v) => v + 1);
    setSelectedPointId(null);
  }, []);

  // Quick projection animation trigger
  const handleTriggerAnimation = useCallback(() => {
    if (isAnimating) {
      setIsAnimating(false);
    } else {
      if (projectionProgress >= 0.99) {
        setProjectionProgress(0);
      }
      setIsAnimating(true);
    }
  }, [isAnimating, projectionProgress]);

  return (
    <div className="flex flex-col h-screen w-screen bg-slate-950 text-slate-100 overflow-hidden font-sans">
      {/* Top Header Bar */}
      <header className="h-14 shrink-0 px-4 border-b border-slate-800 bg-slate-900/90 backdrop-blur-md flex items-center justify-between z-20">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-gradient-to-tr from-sky-600 to-emerald-500 text-white shadow-md shadow-sky-500/20">
            <BrainCircuit className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-sm sm:text-base font-bold text-slate-100 flex items-center gap-2">
              <span>PCA en el Swiss Roll: Reducción 3D a 2D</span>
              <span className="hidden md:inline px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                Didáctico & Interactivo
              </span>
            </h1>
            <p className="text-[11px] text-slate-400 hidden sm:block">
              Comprende geométricamente cómo PCA encuentra el hiperplano óptimo y por qué colapsa en variedades no lineales
            </p>
          </div>
        </div>

        {/* Header Right Actions */}
        <div className="flex items-center gap-2">
          {/* Quick tab switch between Guide, Controls, Math */}
          <div className="flex items-center bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
            <button
              id="header-tab-guide"
              type="button"
              onClick={() => setActiveTab('guide')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-md font-medium transition-all ${
                activeTab === 'guide'
                  ? 'bg-sky-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Guía</span>
            </button>
            <button
              id="header-tab-controls"
              type="button"
              onClick={() => setActiveTab('controls')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-md font-medium transition-all ${
                activeTab === 'controls'
                  ? 'bg-sky-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>Controles</span>
            </button>
            <button
              id="header-tab-math"
              type="button"
              onClick={() => setActiveTab('math')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-md font-medium transition-all ${
                activeTab === 'math'
                  ? 'bg-sky-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Métricas</span>
            </button>
          </div>

          <button
            id="btn-open-help"
            type="button"
            onClick={() => setIsHelpOpen(true)}
            className="p-2 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
            title="¿Cómo funciona este laboratorio?"
          >
            <HelpCircle className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Main Dual Viewport Area */}
      <main className="flex-1 flex flex-col lg:flex-row p-3 gap-3 min-h-0 overflow-hidden">
        {/* Left Side: 3D Interactive Canvas (60% width on desktop) */}
        <section className="flex-1 min-h-[300px] lg:h-full flex flex-col relative rounded-xl shadow-lg">
          <ThreeCanvas
            points={points}
            pca={pca}
            projectionProgress={projectionProgress}
            showPCAPlane={showPCAPlane}
            showEigenvectors={showEigenvectors}
            showProjectionLines={showProjectionLines}
            selectedPointId={selectedPointId}
            onSelectPoint={setSelectedPointId}
            cameraPresetTrigger={cameraPresetTrigger}
          />
        </section>

        {/* Right Side: 2D Projected Space & Dynamic Tab Deck */}
        <section className="w-full lg:w-[460px] xl:w-[500px] flex flex-col gap-3 min-h-0 shrink-0">
          {/* 2D Projected Canvas Plot */}
          <div className="h-[260px] sm:h-[280px] lg:h-[48%] shrink-0">
            <ScatterPlot2D
              points={points}
              pca={pca}
              viewMode={viewMode}
              onChangeViewMode={setViewMode}
              selectedPointId={selectedPointId}
              onSelectPoint={setSelectedPointId}
            />
          </div>

          {/* Bottom Interactive Deck (Didactic Guide / Controls / Math Explainer) */}
          <div className="flex-1 min-h-0 overflow-y-auto pr-0.5">
            {activeTab === 'guide' && (
              <DidacticGuide
                currentStep={currentStep}
                onSetStep={setCurrentStep}
                onApplyStepSettings={handleApplyStepSettings}
                onAnimateProjection={handleTriggerAnimation}
                isAnimating={isAnimating}
              />
            )}

            {activeTab === 'controls' && (
              <ControlsPanel
                config={config}
                onChangeConfig={setConfig}
                projectionProgress={projectionProgress}
                onChangeProjectionProgress={(p) => {
                  setProjectionProgress(p);
                  setIsAnimating(false);
                }}
                isAnimating={isAnimating}
                onToggleAnimation={handleTriggerAnimation}
                showPCAPlane={showPCAPlane}
                onTogglePCAPlane={() => setShowPCAPlane(!showPCAPlane)}
                showEigenvectors={showEigenvectors}
                onToggleEigenvectors={() => setShowEigenvectors(!showEigenvectors)}
                showProjectionLines={showProjectionLines}
                onToggleProjectionLines={() => setShowProjectionLines(!showProjectionLines)}
                onSetCameraPreset={handleSetCameraPreset}
                onRegenerateData={handleRegenerateData}
              />
            )}

            {activeTab === 'math' && <MathExplainer pca={pca} />}
          </div>
        </section>
      </main>

      {/* Deep Dive Educational Modal / Help */}
      {isHelpOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-2xl w-full max-h-[85vh] overflow-y-auto p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <BrainCircuit className="w-5 h-5 text-sky-400" />
                <h2 className="text-base font-bold text-slate-100">
                  Conceptos Clave: PCA y Variedades (Manifolds)
                </h2>
              </div>
              <button
                id="btn-close-help"
                type="button"
                onClick={() => setIsHelpOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3.5 text-xs text-slate-300 leading-relaxed">
              <div>
                <h3 className="font-bold text-sm text-sky-300 mb-1">
                  1. ¿Qué es el Swiss Roll?
                </h3>
                <p>
                  El <strong>Swiss Roll</strong> (brazo de gitana o rollo suizo) es un dataset sintético clásico introducido en la literatura de Machine Learning (Tenenbaum et al., 2000) para ilustrar las limitaciones de los métodos lineales. Consiste en una superficie 2D plana enrollada en espiral dentro de un espacio 3D.
                </p>
              </div>

              <div>
                <h3 className="font-bold text-sm text-emerald-300 mb-1">
                  2. ¿Cómo funciona PCA geométricamente?
                </h3>
                <p>
                  El <strong>Análisis de Componentes Principales (PCA)</strong> encuentra los ejes ortogonales a lo largo de los cuales los datos tienen la mayor dispersión (varianza).
                  Para proyectar de 3D a 2D:
                </p>
                <ul className="list-disc list-inside space-y-1 mt-1 pl-2 text-slate-400">
                  <li>Calcula el centroide y centra la nube de puntos.</li>
                  <li>Obtiene los vectores propios <code className="text-emerald-300">v₁, v₂, v₃</code> de la matriz de covarianza.</li>
                  <li>Se queda con <code className="text-emerald-300">v₁ y v₂</code> (los que explican el ~95% de la varianza total) y descarta <code className="text-rose-400">v₃</code>.</li>
                  <li>Proyecta cada punto ortogonalmente sobre el plano formado por <code className="text-emerald-300">v₁ y v₂</code>.</li>
                </ul>
              </div>

              <div>
                <h3 className="font-bold text-sm text-amber-300 mb-1">
                  3. ¿Por qué PCA "aplasta" el Swiss Roll?
                </h3>
                <p>
                  Debido a que PCA es un método <strong>lineal</strong>, sólo puede proyectar puntos en una línea recta o plano plano. No puede "desenrollar" curvas. Al proyectar la espiral sobre un plano, las capas exteriores se aplastan directamente sobre las capas interiores, haciendo que puntos que estaban muy lejos a lo largo de la superficie del rollo (distancia geodésica) terminen superpuestos en el plano 2D.
                </p>
              </div>

              <div>
                <h3 className="font-bold text-sm text-purple-300 mb-1">
                  4. La Solución: Manifold Learning (Isomap, t-SNE, UMAP)
                </h3>
                <p>
                  Para preservar la geometría intrínseca del rollo, se crearon algoritmos no lineales como <strong>Isomap</strong> (que mide la distancia más corta sobre la superficie a través de un grafo de vecinos más cercanos) y <strong>t-SNE / UMAP</strong>. Estos algoritmos logran "desenrollar" la lámina plana como se muestra en la vista <em>"Desenrollado de Variedad"</em>.
                </p>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 flex justify-end">
              <button
                id="btn-modal-got-it"
                type="button"
                onClick={() => setIsHelpOpen(false)}
                className="px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold shadow-md transition-all"
              >
                ¡Entendido, volver al Laboratorio!
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
