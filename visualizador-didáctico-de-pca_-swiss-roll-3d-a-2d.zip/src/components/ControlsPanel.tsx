import { SwissRollConfig, CameraPreset } from '../types';
import {
  Sliders,
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  Eye,
  RefreshCw,
  Compass,
  Layers,
  Activity
} from 'lucide-react';

interface ControlsPanelProps {
  config: SwissRollConfig;
  onChangeConfig: (newConfig: SwissRollConfig) => void;
  projectionProgress: number;
  onChangeProjectionProgress: (progress: number) => void;
  isAnimating: boolean;
  onToggleAnimation: () => void;
  showPCAPlane: boolean;
  onTogglePCAPlane: () => void;
  showEigenvectors: boolean;
  onToggleEigenvectors: () => void;
  showProjectionLines: boolean;
  onToggleProjectionLines: () => void;
  onSetCameraPreset: (preset: CameraPreset) => void;
  onRegenerateData: () => void;
}

export function ControlsPanel({
  config,
  onChangeConfig,
  projectionProgress,
  onChangeProjectionProgress,
  isAnimating,
  onToggleAnimation,
  showPCAPlane,
  onTogglePCAPlane,
  showEigenvectors,
  onToggleEigenvectors,
  showProjectionLines,
  onToggleProjectionLines,
  onSetCameraPreset,
  onRegenerateData,
}: ControlsPanelProps) {
  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3.5 shadow-xl space-y-3.5 backdrop-blur-md">
      {/* Projection Progress Scrubber (Hero Control) */}
      <div className="space-y-1.5 bg-slate-950/80 p-3 rounded-xl border border-slate-800">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <Activity className="w-4 h-4 text-sky-400" />
            <span className="text-xs font-bold text-slate-200">
              Proyección 3D → 2D
            </span>
          </div>
          <span className="text-xs font-mono font-bold text-sky-400">
            {(projectionProgress * 100).toFixed(0)}%
          </span>
        </div>

        <div className="flex items-center gap-2 pt-1">
          <button
            id="btn-play-projection"
            type="button"
            onClick={onToggleAnimation}
            className={`p-2 rounded-lg text-xs font-semibold flex items-center justify-center transition-all ${
              isAnimating
                ? 'bg-amber-600 text-white shadow-md'
                : 'bg-sky-600 hover:bg-sky-500 text-white shadow-md'
            }`}
            title={isAnimating ? 'Pausar animación' : 'Reproducir transición 3D a 2D'}
          >
            {isAnimating ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
          </button>

          <input
            id="slider-projection-progress"
            type="range"
            min="0"
            max="1"
            step="0.01"
            value={projectionProgress}
            onChange={(e) => onChangeProjectionProgress(parseFloat(e.target.value))}
            className="flex-1 accent-sky-500 h-2 bg-slate-800 rounded-lg cursor-pointer"
          />

          <button
            id="btn-reset-projection"
            type="button"
            onClick={() => onChangeProjectionProgress(0)}
            className="p-2 rounded-lg text-xs text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 transition-colors"
            title="Volver al espacio original 3D"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="flex justify-between text-[10px] text-slate-400 px-1 pt-0.5">
          <span>0%: Espacio Original 3D</span>
          <span>100%: Plano PCA 2D</span>
        </div>
      </div>

      {/* Visual Overlays Toggles */}
      <div className="space-y-1.5">
        <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 block">
          Elementos Visuales 3D
        </span>
        <div className="grid grid-cols-3 gap-1.5 text-xs">
          <button
            id="btn-toggle-plane"
            type="button"
            onClick={onTogglePCAPlane}
            className={`px-2 py-1.5 rounded-lg border font-medium transition-all text-center flex flex-col items-center gap-1 ${
              showPCAPlane
                ? 'bg-sky-500/15 border-sky-500/40 text-sky-300'
                : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>Plano PCA</span>
            <span className="text-[10px] opacity-75">{showPCAPlane ? 'Visible' : 'Oculto'}</span>
          </button>

          <button
            id="btn-toggle-vectors"
            type="button"
            onClick={onToggleEigenvectors}
            className={`px-2 py-1.5 rounded-lg border font-medium transition-all text-center flex flex-col items-center gap-1 ${
              showEigenvectors
                ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300'
                : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>Ejes PC1-2-3</span>
            <span className="text-[10px] opacity-75">{showEigenvectors ? 'Visible' : 'Oculto'}</span>
          </button>

          <button
            id="btn-toggle-lines"
            type="button"
            onClick={onToggleProjectionLines}
            className={`px-2 py-1.5 rounded-lg border font-medium transition-all text-center flex flex-col items-center gap-1 ${
              showProjectionLines
                ? 'bg-amber-500/15 border-amber-500/40 text-amber-300'
                : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>Líneas Residuos</span>
            <span className="text-[10px] opacity-75">{showProjectionLines ? 'Visible' : 'Oculto'}</span>
          </button>
        </div>
      </div>

      {/* Camera Presets Quick Bar */}
      <div className="space-y-1.5">
        <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 block">
          Perspectivas de Cámara
        </span>
        <div className="grid grid-cols-4 gap-1 text-[11px]">
          <button
            id="btn-cam-default"
            type="button"
            onClick={() => onSetCameraPreset('default')}
            className="p-1.5 rounded-md bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 transition-colors text-center"
          >
            Isométrica
          </button>
          <button
            id="btn-cam-cross"
            type="button"
            onClick={() => onSetCameraPreset('cross_section')}
            className="p-1.5 rounded-md bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 transition-colors text-center"
          >
            Espiral
          </button>
          <button
            id="btn-cam-plane"
            type="button"
            onClick={() => onSetCameraPreset('pca_plane')}
            className="p-1.5 rounded-md bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 transition-colors text-center"
          >
            Plano PCA
          </button>
          <button
            id="btn-cam-top"
            type="button"
            onClick={() => onSetCameraPreset('top')}
            className="p-1.5 rounded-md bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 transition-colors text-center"
          >
            Superior
          </button>
        </div>
      </div>

      {/* Dataset Parameters Tuning */}
      <div className="space-y-2 pt-1 border-t border-slate-800/80">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">
            Parámetros del Dataset
          </span>
          <button
            id="btn-regenerate-data"
            type="button"
            onClick={onRegenerateData}
            className="flex items-center gap-1 text-[11px] text-sky-400 hover:text-sky-300 transition-colors"
          >
            <RefreshCw className="w-3 h-3" />
            <span>Regenerar</span>
          </button>
        </div>

        <div className="grid grid-cols-2 gap-3 text-xs">
          {/* Points count */}
          <div>
            <div className="flex justify-between text-[11px] text-slate-400 mb-1">
              <span>Puntos:</span>
              <span className="font-mono text-slate-200">{config.numPoints}</span>
            </div>
            <input
              id="slider-num-points"
              type="range"
              min="300"
              max="2000"
              step="100"
              value={config.numPoints}
              onChange={(e) => onChangeConfig({ ...config, numPoints: parseInt(e.target.value) })}
              className="w-full accent-sky-500 h-1.5 bg-slate-800 rounded cursor-pointer"
            />
          </div>

          {/* Noise level */}
          <div>
            <div className="flex justify-between text-[11px] text-slate-400 mb-1">
              <span>Ruido σ:</span>
              <span className="font-mono text-slate-200">{config.noise.toFixed(2)}</span>
            </div>
            <input
              id="slider-noise"
              type="range"
              min="0"
              max="1.5"
              step="0.05"
              value={config.noise}
              onChange={(e) => onChangeConfig({ ...config, noise: parseFloat(e.target.value) })}
              className="w-full accent-sky-500 h-1.5 bg-slate-800 rounded cursor-pointer"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
