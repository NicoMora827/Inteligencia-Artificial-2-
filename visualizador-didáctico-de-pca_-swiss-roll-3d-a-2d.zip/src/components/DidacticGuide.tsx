import { useState } from 'react';
import { GuideStep, CameraPreset, ViewMode } from '../types';
import {
  ChevronLeft,
  ChevronRight,
  Sparkles,
  BookOpen,
  ArrowRight,
  Eye,
  CheckCircle2,
  Lightbulb,
  Compass,
  Play,
  RotateCcw
} from 'lucide-react';

interface DidacticGuideProps {
  currentStep: number;
  onSetStep: (step: number) => void;
  onApplyStepSettings: (step: GuideStep) => void;
  onAnimateProjection: () => void;
  isAnimating: boolean;
}

export const GUIDE_STEPS: GuideStep[] = [
  {
    id: 0,
    title: '1. El Swiss Roll: Una Variedad 2D en Espacio 3D',
    subtitle: 'Dimensión Intrínseca vs. Dimensión Extrínseca',
    explanation:
      'Imagina una hoja de papel (2D) que ha sido enrollada como un brazo de reina o pionono en el espacio tridimensional (3D). Cada punto tiene 3 coordenadas (X, Y, Z), pero topológicamente sólo se necesitan 2 variables para describir la superficie: qué tan lejos vas por la espiral y qué altura tienes.',
    formula: 'x = t \\cos(t), \\quad y = h, \\quad z = t \\sin(t)',
    intuition:
      'Los colores corresponden a la posición a lo largo de la espiral. Los puntos de color similar son vecinos verdaderos en la superficie de la hoja.',
    cameraPreset: 'default',
    projectionProgress: 0,
    showPCAPlane: false,
    showEigenvectors: false,
    showProjectionLines: false,
    targetViewMode: 'pca',
  },
  {
    id: 1,
    title: '2. Centrado y Matriz de Covarianza',
    subtitle: 'El punto de partida del Análisis de Componentes Principales',
    explanation:
      'El primer paso matemático de PCA es restar la media \\mu = [\\bar{x}, \\bar{y}, \\bar{z}] a cada punto. Esto traslada el centro de gravedad del Swiss Roll al origen (0,0,0). Luego calculamos la matriz de covarianza 3\\times3, que cuantifica la dispersión y correlación mutua.',
    formula: '\\Sigma = \\frac{1}{n-1} X_c^T X_c',
    intuition:
      'Observa la esfera blanca en el centro: es el centroide. A partir de él se medirán todas las direcciones de varianza.',
    cameraPreset: 'cross_section',
    projectionProgress: 0,
    showPCAPlane: false,
    showEigenvectors: true,
    showProjectionLines: false,
    targetViewMode: 'pca',
  },
  {
    id: 2,
    title: '3. Los Ejes Principales (Eigenvectors)',
    subtitle: 'Buscando las direcciones de máxima varianza ortogonales',
    explanation:
      'Al diagonalizar la matriz de covarianza, encontramos 3 vectores propios ortogonales entre sí. PC1 (verde) captura la máxima varianza, PC2 (amarillo) la segunda mayor, y PC3 (rojo) la menor varianza.',
    formula: '\\Sigma v_i = \\lambda_i v_i, \\quad i \\in \\{1, 2, 3\\}',
    intuition:
      'La longitud de cada flecha es proporcional a su desviación estándar (\\sqrt{\\lambda_i}). PC1 y PC2 capturan más del 90% de la energía total del conjunto de datos.',
    cameraPreset: 'default',
    projectionProgress: 0,
    showPCAPlane: false,
    showEigenvectors: true,
    showProjectionLines: false,
    targetViewMode: 'pca',
  },
  {
    id: 3,
    title: '4. El Plano 2D de Proyección Óptima',
    subtitle: 'Descartando la dimensión con menor información (PC3)',
    explanation:
      'Para reducir de 3D a 2D, PCA construye un hiperplano bidimensional generado por los dos primeros vectores propios (PC1 y PC2). Este plano azul atraviesa el centroide y es el que minimiza la distancia cuadrática a todos los puntos.',
    formula: '\\text{Subespacio} = \\text{span}(v_1, v_2)',
    intuition:
      'Al alinear la cámara perpendicular al plano, verás la perspectiva exacta que PCA utiliza como pantalla de proyección.',
    cameraPreset: 'pca_plane',
    projectionProgress: 0,
    showPCAPlane: true,
    showEigenvectors: true,
    showProjectionLines: false,
    targetViewMode: 'pca',
  },
  {
    id: 4,
    title: '5. La Proyección Ortogonal en Acción (3D → 2D)',
    subtitle: 'Colapso ortogonal de los datos sobre el plano',
    explanation:
      'Cada punto del Swiss Roll se desplaza en línea recta (a lo largo del eje residual PC3) hasta chocar con el plano PC1-PC2. La distancia que recorre cada punto es su residuo o información perdida.',
    formula: 'p_{\\text{proy}} = \\mu + (x_c \\cdot v_1)v_1 + (x_c \\cdot v_2)v_2',
    intuition:
      'Presiona el botón de animación o mueve el control deslizante para ver cómo los puntos 3D colapsan físicamente en el plano 2D.',
    cameraPreset: 'default',
    projectionProgress: 1,
    showPCAPlane: true,
    showEigenvectors: true,
    showProjectionLines: true,
    targetViewMode: 'pca',
  },
  {
    id: 5,
    title: '6. La Gran Lección: ¿Por qué PCA "falla" con el Swiss Roll?',
    subtitle: 'La diferencia crucial entre Proyección Lineal y Variedad No-Lineal',
    explanation:
      'PCA es un método LINEAL: asume que los datos viven en un plano o hiperplano. Al proyectar el rollo, las capas externas se aplastan contra las capas internas. Puntos de colores muy distintos quedan superpuestos como si fueran vecinos.',
    formula: '\\text{Distancia Euclídea (aire)} \\neq \\text{Distancia Geodésica (superficie)}',
    intuition:
      '¡Compara con el botón "Desenrollado de Variedad"! Métodos no lineales como Isomap o t-SNE desenrollan el rollo preservando las distancias geodésicas en vez de aplastarlo.',
    cameraPreset: 'pca_plane',
    projectionProgress: 1,
    showPCAPlane: true,
    showEigenvectors: false,
    showProjectionLines: false,
    targetViewMode: 'unrolled',
  },
];

export function DidacticGuide({
  currentStep,
  onSetStep,
  onApplyStepSettings,
  onAnimateProjection,
  isAnimating,
}: DidacticGuideProps) {
  const step = GUIDE_STEPS[currentStep] || GUIDE_STEPS[0];

  const handleNext = () => {
    if (currentStep < GUIDE_STEPS.length - 1) {
      const nextIdx = currentStep + 1;
      onSetStep(nextIdx);
      onApplyStepSettings(GUIDE_STEPS[nextIdx]);
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      const prevIdx = currentStep - 1;
      onSetStep(prevIdx);
      onApplyStepSettings(GUIDE_STEPS[prevIdx]);
    }
  };

  const handleSelectStep = (idx: number) => {
    onSetStep(idx);
    onApplyStepSettings(GUIDE_STEPS[idx]);
  };

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-col justify-between shadow-xl backdrop-blur-md">
      {/* Step Pills Navigation */}
      <div>
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-sky-500/10 text-sky-400 border border-sky-500/20">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-sky-400 block">
                Guía Didáctica Paso a Paso
              </span>
              <span className="text-[11px] text-slate-400">
                Paso {currentStep + 1} de {GUIDE_STEPS.length}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1">
            {GUIDE_STEPS.map((s, idx) => (
              <button
                key={s.id}
                id={`step-dot-${idx}`}
                type="button"
                onClick={() => handleSelectStep(idx)}
                className={`w-6 h-6 rounded-full text-xs font-semibold flex items-center justify-center transition-all ${
                  currentStep === idx
                    ? 'bg-sky-500 text-white ring-2 ring-sky-400/40 shadow-sm'
                    : 'bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-slate-200'
                }`}
                title={s.title}
              >
                {idx + 1}
              </button>
            ))}
          </div>
        </div>

        {/* Step Content */}
        <div className="mt-3 space-y-3">
          <div>
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <span>{step.title}</span>
            </h3>
            <p className="text-xs font-medium text-sky-400 mt-0.5">
              {step.subtitle}
            </p>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed">
            {step.explanation}
          </p>

          {/* Mathematical Formula Callout */}
          {step.formula && (
            <div className="bg-slate-950/70 border border-slate-800/80 px-3 py-1.5 rounded-lg font-mono text-[11px] text-emerald-300 flex items-center justify-between">
              <span className="text-slate-400 text-[10px] uppercase font-sans font-semibold">Fórmula Clave:</span>
              <span className="tracking-wide">{step.formula}</span>
            </div>
          )}

          {/* Intuition Box */}
          <div className="bg-amber-500/10 border border-amber-500/20 rounded-lg p-2.5 flex items-start gap-2.5 text-xs text-amber-200/90">
            <Lightbulb className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <span className="leading-snug">{step.intuition}</span>
          </div>
        </div>
      </div>

      {/* Action and Navigation Footer */}
      <div className="pt-3 border-t border-slate-800 flex items-center justify-between gap-2 mt-3">
        <div className="flex items-center gap-2">
          {currentStep === 4 && (
            <button
              id="btn-guide-animate-projection"
              type="button"
              onClick={onAnimateProjection}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                isAnimating
                  ? 'bg-amber-600 text-white shadow-md'
                  : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-md hover:shadow-emerald-600/30'
              }`}
            >
              <Play className="w-3.5 h-3.5" />
              <span>{isAnimating ? 'Animando...' : 'Animar Proyección'}</span>
            </button>
          )}

          <button
            id="btn-reapply-camera"
            type="button"
            onClick={() => onApplyStepSettings(step)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700/60 transition-colors"
            title="Alinear la vista 3D para este paso didáctico"
          >
            <Compass className="w-3.5 h-3.5 text-sky-400" />
            <span className="hidden sm:inline">Enfocar Perspectiva</span>
          </button>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            id="btn-guide-prev"
            type="button"
            onClick={handlePrev}
            disabled={currentStep === 0}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white disabled:opacity-40 disabled:pointer-events-none transition-colors"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
            <span>Anterior</span>
          </button>

          <button
            id="btn-guide-next"
            type="button"
            onClick={handleNext}
            disabled={currentStep === GUIDE_STEPS.length - 1}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold bg-sky-600 text-white hover:bg-sky-500 disabled:opacity-40 disabled:pointer-events-none transition-all shadow-sm"
          >
            <span>Siguiente</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}
