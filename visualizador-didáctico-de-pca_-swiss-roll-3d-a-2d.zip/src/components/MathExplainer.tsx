import { useState } from 'react';
import { PCAResult } from '../types';
import { Calculator, BarChart3, ChevronDown, ChevronUp, Check, AlertCircle } from 'lucide-react';

interface MathExplainerProps {
  pca: PCAResult;
}

export function MathExplainer({ pca }: MathExplainerProps) {
  const [activeTab, setActiveTab] = useState<'variance' | 'matrix' | 'vectors'>('variance');

  const pc1Pct = (pca.explainedVarianceRatio[0] * 100).toFixed(1);
  const pc2Pct = (pca.explainedVarianceRatio[1] * 100).toFixed(1);
  const pc3Pct = (pca.explainedVarianceRatio[2] * 100).toFixed(1);
  const retained2DPct = (
    (pca.explainedVarianceRatio[0] + pca.explainedVarianceRatio[1]) *
    100
  ).toFixed(1);

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3.5 shadow-xl flex flex-col justify-between backdrop-blur-md">
      <div>
        {/* Header and Tab Selector */}
        <div className="flex items-center justify-between pb-2.5 border-b border-slate-800">
          <div className="flex items-center gap-1.5 text-xs font-bold text-slate-200">
            <Calculator className="w-4 h-4 text-emerald-400" />
            <span>Desglose Matemático del PCA</span>
          </div>

          <div className="flex items-center gap-1 bg-slate-950 p-0.5 rounded-lg border border-slate-800 text-[11px]">
            <button
              id="tab-variance"
              type="button"
              onClick={() => setActiveTab('variance')}
              className={`px-2 py-0.5 rounded-md font-medium transition-all ${
                activeTab === 'variance'
                  ? 'bg-slate-800 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Varianza
            </button>
            <button
              id="tab-matrix"
              type="button"
              onClick={() => setActiveTab('matrix')}
              className={`px-2 py-0.5 rounded-md font-medium transition-all ${
                activeTab === 'matrix'
                  ? 'bg-slate-800 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Covarianza Σ
            </button>
            <button
              id="tab-vectors"
              type="button"
              onClick={() => setActiveTab('vectors')}
              className={`px-2 py-0.5 rounded-md font-medium transition-all ${
                activeTab === 'vectors'
                  ? 'bg-slate-800 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Eigenvectors
            </button>
          </div>
        </div>

        {/* Tab 1: Variance Breakdown & Explained Information */}
        {activeTab === 'variance' && (
          <div className="mt-3 space-y-3 text-xs">
            {/* Retained 2D variance headline */}
            <div className="flex items-center justify-between p-2 rounded-lg bg-emerald-500/10 border border-emerald-500/25">
              <span className="text-slate-300 font-medium">Información Retenida en 2D (PC1 + PC2):</span>
              <span className="text-emerald-400 font-mono font-bold text-sm">
                {retained2DPct}%
              </span>
            </div>

            {/* Stacked Visual Bar */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px] text-slate-400">
                <span>Distribución de Varianza Explicada</span>
                <span>Total: 100%</span>
              </div>
              <div className="w-full h-3.5 bg-slate-950 rounded-md overflow-hidden flex border border-slate-800">
                <div
                  style={{ width: `${pc1Pct}%` }}
                  className="bg-emerald-500 h-full transition-all duration-500"
                  title={`PC1: ${pc1Pct}%`}
                />
                <div
                  style={{ width: `${pc2Pct}%` }}
                  className="bg-amber-500 h-full transition-all duration-500"
                  title={`PC2: ${pc2Pct}%`}
                />
                <div
                  style={{ width: `${pc3Pct}%` }}
                  className="bg-rose-500 h-full transition-all duration-500"
                  title={`PC3 (Perdida): ${pc3Pct}%`}
                />
              </div>
            </div>

            {/* Individual components list */}
            <div className="grid grid-cols-3 gap-2 font-mono text-[11px]">
              <div className="p-2 rounded-lg bg-slate-950/60 border border-emerald-500/30">
                <div className="text-emerald-400 font-bold flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-400" />
                  PC1 (Eje 1)
                </div>
                <div className="text-slate-100 text-xs mt-1">{pc1Pct}%</div>
                <div className="text-[10px] text-slate-400 mt-0.5">λ₁ = {pca.eigenvalues[0].toFixed(1)}</div>
              </div>

              <div className="p-2 rounded-lg bg-slate-950/60 border border-amber-500/30">
                <div className="text-amber-400 font-bold flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-amber-400" />
                  PC2 (Eje 2)
                </div>
                <div className="text-slate-100 text-xs mt-1">{pc2Pct}%</div>
                <div className="text-[10px] text-slate-400 mt-0.5">λ₂ = {pca.eigenvalues[1].toFixed(1)}</div>
              </div>

              <div className="p-2 rounded-lg bg-slate-950/60 border border-rose-500/30">
                <div className="text-rose-400 font-bold flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-rose-400" />
                  PC3 (Descartado)
                </div>
                <div className="text-slate-100 text-xs mt-1">{pc3Pct}%</div>
                <div className="text-[10px] text-slate-400 mt-0.5">λ₃ = {pca.eigenvalues[2].toFixed(1)}</div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Covariance Matrix (3x3) */}
        {activeTab === 'matrix' && (
          <div className="mt-3 space-y-2 text-xs">
            <p className="text-[11px] text-slate-400">
              Matriz simétrica 3×3 calculada a partir de los datos centrados:
            </p>
            <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 font-mono text-[11px]">
              <div className="grid grid-cols-3 gap-1 text-center">
                {pca.covarianceMatrix.map((row, rIdx) =>
                  row.map((val, cIdx) => (
                    <div
                      key={`${rIdx}-${cIdx}`}
                      className={`p-1 rounded ${
                        rIdx === cIdx
                          ? 'bg-sky-500/10 text-sky-300 font-bold border border-sky-500/20'
                          : 'text-slate-400'
                      }`}
                    >
                      {val.toFixed(1)}
                    </div>
                  ))
                )}
              </div>
            </div>
            <div className="flex items-center gap-2 text-[10px] text-slate-400">
              <span className="w-2 h-2 rounded-full bg-sky-400" />
              <span>Diagonal principal: Varianzas individuales Var(X), Var(Y), Var(Z)</span>
            </div>
          </div>
        )}

        {/* Tab 3: Eigenvectors Details */}
        {activeTab === 'vectors' && (
          <div className="mt-3 space-y-2 text-xs">
            <p className="text-[11px] text-slate-400">
              Direcciones unitarias ortogonales en el espacio 3D:
            </p>
            <div className="space-y-1.5 font-mono text-[11px]">
              {pca.eigenvectors.map((vec, idx) => {
                const colors = ['text-emerald-400 border-emerald-500/30', 'text-amber-400 border-amber-500/30', 'text-rose-400 border-rose-500/30'];
                return (
                  <div
                    key={idx}
                    className={`flex items-center justify-between p-1.5 rounded-md bg-slate-950/70 border ${colors[idx]}`}
                  >
                    <span className="font-bold">v{idx + 1} (PC{idx + 1}):</span>
                    <span>
                      [{vec[0].toFixed(2)}, {vec[1].toFixed(2)}, {vec[2].toFixed(2)}]
                    </span>
                  </div>
                );
              })}
            </div>
            <p className="text-[10px] text-slate-400">
              * Nota: v₁ · v₂ = 0 (son rigurosamente ortogonales a 90°).
            </p>
          </div>
        )}
      </div>

      {/* Summary Note */}
      <div className="mt-2 pt-2 border-t border-slate-800 text-[11px] text-slate-400 flex items-center gap-1.5">
        <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
        <span>El plano 2D retiene la mayor dispersión global posible.</span>
      </div>
    </div>
  );
}
