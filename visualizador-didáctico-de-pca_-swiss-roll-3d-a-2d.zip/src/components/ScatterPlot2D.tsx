import { useRef, useEffect, useState, useCallback } from 'react';
import { Point3D, PCAResult, ViewMode } from '../types';
import { Layers, Split, ArrowRightLeft, Info, HelpCircle } from 'lucide-react';

interface ScatterPlot2DProps {
  points: Point3D[];
  pca: PCAResult;
  viewMode: ViewMode;
  onChangeViewMode: (mode: ViewMode) => void;
  selectedPointId: number | null;
  onSelectPoint: (id: number | null) => void;
}

export function ScatterPlot2D({
  points,
  pca,
  viewMode,
  onChangeViewMode,
  selectedPointId,
  onSelectPoint,
}: ScatterPlot2DProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [hoveredPoint, setHoveredPoint] = useState<Point3D | null>(null);

  // Render 2D Scatter on Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container || points.length === 0) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const rect = container.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;

    canvas.width = width * dpr;
    canvas.height = height * dpr;
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;

    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, width, height);

    // Padding for axes & labels
    const padX = 54;
    const padY = 44;
    const plotW = width - padX * 2;
    const plotH = height - padY * 2;

    // Helper to calculate extents
    const isUnrolled = viewMode === 'unrolled';

    let xMin = Infinity, xMax = -Infinity;
    let yMin = Infinity, yMax = -Infinity;

    for (const p of points) {
      const xVal = isUnrolled ? p.unrolledX : p.pc1;
      const yVal = isUnrolled ? p.unrolledY : p.pc2;
      if (xVal < xMin) xMin = xVal;
      if (xVal > xMax) xMax = xVal;
      if (yVal < yMin) yMin = yVal;
      if (yVal > yMax) yMax = yVal;
    }

    // Add 10% margin
    const xSpan = Math.max(1e-4, xMax - xMin);
    const ySpan = Math.max(1e-4, yMax - yMin);
    const xMargin = xSpan * 0.08;
    const yMargin = ySpan * 0.08;
    const domainXMin = xMin - xMargin;
    const domainXMax = xMax + xMargin;
    const domainYMin = yMin - yMargin;
    const domainYMax = yMax + yMargin;

    const scaleX = (val: number) => padX + ((val - domainXMin) / (domainXMax - domainXMin)) * plotW;
    const scaleY = (val: number) => height - padY - ((val - domainYMin) / (domainYMax - domainYMin)) * plotH;

    // Background Grid
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 1;
    ctx.setLineDash([4, 4]);

    const numTicks = 6;
    for (let i = 0; i <= numTicks; i++) {
      // Vertical grid lines
      const gx = padX + (i / numTicks) * plotW;
      ctx.beginPath();
      ctx.moveTo(gx, padY);
      ctx.lineTo(gx, height - padY);
      ctx.stroke();

      // Horizontal grid lines
      const gy = padY + (i / numTicks) * plotH;
      ctx.beginPath();
      ctx.moveTo(padX, gy);
      ctx.lineTo(width - padX, gy);
      ctx.stroke();
    }
    ctx.setLineDash([]);

    // Zero-lines if in domain
    if (domainXMin <= 0 && domainXMax >= 0) {
      const zx = scaleX(0);
      ctx.strokeStyle = '#334155';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(zx, padY);
      ctx.lineTo(zx, height - padY);
      ctx.stroke();
    }
    if (domainYMin <= 0 && domainYMax >= 0) {
      const zy = scaleY(0);
      ctx.strokeStyle = '#334155';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(padX, zy);
      ctx.lineTo(width - padX, zy);
      ctx.stroke();
    }

    // Draw all points
    const activePointId = selectedPointId !== null ? selectedPointId : hoveredPoint?.id ?? null;

    for (const p of points) {
      const xVal = isUnrolled ? p.unrolledX : p.pc1;
      const yVal = isUnrolled ? p.unrolledY : p.pc2;
      const cx = scaleX(xVal);
      const cy = scaleY(yVal);

      const isSelected = p.id === activePointId;

      ctx.beginPath();
      ctx.arc(cx, cy, isSelected ? 6 : 3, 0, Math.PI * 2);
      ctx.fillStyle = p.hexColor;
      ctx.fill();

      if (isSelected) {
        ctx.lineWidth = 2.5;
        ctx.strokeStyle = '#ffffff';
        ctx.stroke();
      }
    }

    // Border around plot area
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 1;
    ctx.strokeRect(padX, padY, plotW, plotH);

    // Axis Labels
    ctx.fillStyle = '#94a3b8';
    ctx.font = '11px sans-serif';
    ctx.textAlign = 'center';

    if (isUnrolled) {
      ctx.fillText('Longitud de arco de la variedad desenrollada (Geodésica s)', width / 2, height - 12);
      ctx.save();
      ctx.translate(16, height / 2);
      ctx.rotate(-Math.PI / 2);
      ctx.fillText('Ancho del rollo (Eje Y intrínseco)', 0, 0);
      ctx.restore();
    } else {
      const pc1Pct = (pca.explainedVarianceRatio[0] * 100).toFixed(1);
      const pc2Pct = (pca.explainedVarianceRatio[1] * 100).toFixed(1);
      ctx.fillText(`Primer Componente Principal PC1 (${pc1Pct}% varianza)`, width / 2, height - 12);
      ctx.save();
      ctx.translate(16, height / 2);
      ctx.rotate(-Math.PI / 2);
      ctx.fillText(`Segundo Componente Principal PC2 (${pc2Pct}% varianza)`, 0, 0);
      ctx.restore();
    }
  }, [points, pca, viewMode, selectedPointId, hoveredPoint]);

  // Pointer move handler to find closest point
  const handlePointerMove = useCallback(
    (e: React.PointerEvent<HTMLCanvasElement>) => {
      const canvas = canvasRef.current;
      const container = containerRef.current;
      if (!canvas || !container || points.length === 0) return;

      const rect = canvas.getBoundingClientRect();
      const clientX = e.clientX - rect.left;
      const clientY = e.clientY - rect.top;

      const width = rect.width;
      const height = rect.height;
      const padX = 54;
      const padY = 44;
      const plotW = width - padX * 2;
      const plotH = height - padY * 2;

      const isUnrolled = viewMode === 'unrolled';

      let xMin = Infinity, xMax = -Infinity;
      let yMin = Infinity, yMax = -Infinity;
      for (const p of points) {
        const xVal = isUnrolled ? p.unrolledX : p.pc1;
        const yVal = isUnrolled ? p.unrolledY : p.pc2;
        if (xVal < xMin) xMin = xVal;
        if (xVal > xMax) xMax = xVal;
        if (yVal < yMin) yMin = yVal;
        if (yVal > yMax) yMax = yVal;
      }

      const xSpan = Math.max(1e-4, xMax - xMin);
      const ySpan = Math.max(1e-4, yMax - yMin);
      const xMargin = xSpan * 0.08;
      const yMargin = ySpan * 0.08;
      const domainXMin = xMin - xMargin;
      const domainXMax = xMax + xMargin;
      const domainYMin = yMin - yMargin;
      const domainYMax = yMax + yMargin;

      const scaleX = (val: number) => padX + ((val - domainXMin) / (domainXMax - domainXMin)) * plotW;
      const scaleY = (val: number) => height - padY - ((val - domainYMin) / (domainYMax - domainYMin)) * plotH;

      let closest: Point3D | null = null;
      let minDistSq = 144; // 12px detection radius

      for (const p of points) {
        const px = scaleX(isUnrolled ? p.unrolledX : p.pc1);
        const py = scaleY(isUnrolled ? p.unrolledY : p.pc2);
        const distSq = (px - clientX) * (px - clientX) + (py - clientY) * (py - clientY);
        if (distSq < minDistSq) {
          minDistSq = distSq;
          closest = p;
        }
      }

      setHoveredPoint(closest);
    },
    [points, viewMode]
  );

  const handleClick = useCallback(() => {
    if (hoveredPoint) {
      onSelectPoint(selectedPointId === hoveredPoint.id ? null : hoveredPoint.id);
    } else {
      onSelectPoint(null);
    }
  }, [hoveredPoint, selectedPointId, onSelectPoint]);

  return (
    <div
      ref={containerRef}
      className="relative w-full h-full select-none overflow-hidden rounded-xl border border-slate-800 bg-slate-950 flex flex-col"
    >
      {/* Header with Mode Toggle & Pedagogy Badge */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-slate-800/80 bg-slate-900/60 backdrop-blur-sm z-10">
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5 text-sky-400" />
            <span>Espacio Bidimensional 2D</span>
          </span>
          <span className="text-[11px] text-slate-400 hidden sm:inline">
            ({points.length} puntos)
          </span>
        </div>

        {/* View Mode Segmented Controls */}
        <div className="flex items-center gap-1 bg-slate-950 p-0.5 rounded-lg border border-slate-800">
          <button
            id="btn-view-pca"
            type="button"
            onClick={() => onChangeViewMode('pca')}
            className={`px-2.5 py-1 rounded-md text-xs font-medium transition-all ${
              viewMode === 'pca'
                ? 'bg-sky-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            Proyección PCA (Lineal)
          </button>
          <button
            id="btn-view-unrolled"
            type="button"
            onClick={() => onChangeViewMode('unrolled')}
            className={`px-2.5 py-1 rounded-md text-xs font-medium transition-all ${
              viewMode === 'unrolled'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            Desenrollado de Variedad (Isomap)
          </button>
        </div>
      </div>

      {/* Main Canvas Plot */}
      <div className="relative flex-1 w-full h-full min-h-0">
        <canvas
          ref={canvasRef}
          className="w-full h-full cursor-crosshair"
          onPointerMove={handlePointerMove}
          onPointerLeave={() => setHoveredPoint(null)}
          onClick={handleClick}
        />

        {/* Didactic Callout Overlay based on selected mode */}
        <div className="absolute top-2 left-16 right-3 pointer-events-none flex justify-end">
          {viewMode === 'pca' ? (
            <div className="max-w-md bg-amber-950/80 border border-amber-500/40 text-amber-200/90 text-[11px] p-2 rounded-lg backdrop-blur-md shadow-lg leading-relaxed">
              <strong className="text-amber-300 font-semibold block mb-0.5">⚠️ Limitación de PCA en el Swiss Roll:</strong>
              Al ser una proyección ortogonal lineal, las vueltas de la espiral se <em>aplastan unas sobre otras</em>. Observa cómo puntos de colores muy distintos (capas internas y externas) quedan encimados.
            </div>
          ) : (
            <div className="max-w-md bg-emerald-950/80 border border-emerald-500/40 text-emerald-200/90 text-[11px] p-2 rounded-lg backdrop-blur-md shadow-lg leading-relaxed">
              <strong className="text-emerald-300 font-semibold block mb-0.5">✨ Desenrollado Intrínseco (Manifold Learning):</strong>
              Al respetar la distancia geodésica a lo largo de la superficie del rollo, la variedad 2D se despliega de forma continua como un rectángulo plano sin superposiciones ni colapsos.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
