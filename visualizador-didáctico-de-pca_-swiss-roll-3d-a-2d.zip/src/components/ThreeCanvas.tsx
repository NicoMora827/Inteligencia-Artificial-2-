import { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { Point3D, PCAResult, CameraPreset } from '../types';
import { Maximize2, RotateCcw, Eye, Compass } from 'lucide-react';

interface ThreeCanvasProps {
  points: Point3D[];
  pca: PCAResult;
  projectionProgress: number; // 0 (original 3D) to 1 (projected on PCA plane)
  showPCAPlane: boolean;
  showEigenvectors: boolean;
  showProjectionLines: boolean;
  selectedPointId: number | null;
  onSelectPoint: (id: number | null) => void;
  cameraPresetTrigger?: { preset: CameraPreset; nonce: number } | null;
}

export function ThreeCanvas({
  points,
  pca,
  projectionProgress,
  showPCAPlane,
  showEigenvectors,
  showProjectionLines,
  selectedPointId,
  onSelectPoint,
  cameraPresetTrigger,
}: ThreeCanvasProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);

  // Three.js object references
  const pointsMeshRef = useRef<THREE.Points | null>(null);
  const pointsGeometryRef = useRef<THREE.BufferGeometry | null>(null);
  const pcaPlaneMeshRef = useRef<THREE.Mesh | null>(null);
  const eigenvectorsGroupRef = useRef<THREE.Group | null>(null);
  const projectionLinesMeshRef = useRef<THREE.LineSegments | null>(null);
  const selectedHighlightRef = useRef<THREE.Mesh | null>(null);
  const raycasterRef = useRef<THREE.Raycaster>(new THREE.Raycaster());
  const mouseRef = useRef<THREE.Vector2>(new THREE.Vector2(-1000, -1000));
  const hoveredIdRef = useRef<number | null>(null);

  const [hoveredPoint, setHoveredPoint] = useState<Point3D | null>(null);
  const [isRotatingAuto, setIsRotatingAuto] = useState(false);

  // Setup Scene, Camera, Renderer, Controls
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const width = container.clientWidth;
    const height = container.clientHeight;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x050814); // Deep sophisticated navy/slate
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(30, 24, 38);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.innerHTML = '';
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.maxDistance = 200;
    controls.minDistance = 5;
    controls.target.set(0, 0, 0);
    controlsRef.current = controls;

    // Ambient and Directional Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.85);
    scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0xffffff, 0.9);
    dirLight1.position.set(20, 40, 30);
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0x38bdf8, 0.4);
    dirLight2.position.set(-20, -20, -20);
    scene.add(dirLight2);

    // Subtle 3D Coordinate Grid
    const gridHelper = new THREE.GridHelper(50, 25, 0x1e293b, 0x0f172a);
    gridHelper.position.y = -15;
    scene.add(gridHelper);

    // Highlight marker for selected/hovered point
    const highlightGeo = new THREE.SphereGeometry(0.7, 16, 16);
    const highlightMat = new THREE.MeshBasicMaterial({ color: 0xffffff, wireframe: true });
    const highlightMesh = new THREE.Mesh(highlightGeo, highlightMat);
    highlightMesh.visible = false;
    scene.add(highlightMesh);
    selectedHighlightRef.current = highlightMesh;

    // Resize Observer
    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width: w, height: h } = entry.contentRect;
        if (w > 0 && h > 0) {
          camera.aspect = w / h;
          camera.updateProjectionMatrix();
          renderer.setSize(w, h);
        }
      }
    });
    resizeObserver.observe(container);

    // Animation Loop
    let animationFrameId: number;
    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);

      if (isRotatingAuto && controls) {
        controls.autoRotate = true;
        controls.autoRotateSpeed = 1.2;
      } else if (controls) {
        controls.autoRotate = false;
      }

      controls.update();
      renderer.render(scene, camera);
    };
    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      resizeObserver.disconnect();
      renderer.dispose();
      container.innerHTML = '';
    };
  }, []);

  // Update Points Geometry and Colors
  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene || points.length === 0) return;

    if (pointsMeshRef.current) {
      scene.remove(pointsMeshRef.current);
      pointsGeometryRef.current?.dispose();
    }

    const n = points.length;
    const positions = new Float32Array(n * 3);
    const colors = new Float32Array(n * 3);

    for (let i = 0; i < n; i++) {
      const p = points[i];
      // Interpolate between original 3D position and projected PCA position
      const px = (1 - projectionProgress) * p.x + projectionProgress * p.projX;
      const py = (1 - projectionProgress) * p.y + projectionProgress * p.projY;
      const pz = (1 - projectionProgress) * p.z + projectionProgress * p.projZ;

      positions[i * 3] = px;
      positions[i * 3 + 1] = py;
      positions[i * 3 + 2] = pz;

      colors[i * 3] = p.color[0];
      colors[i * 3 + 1] = p.color[1];
      colors[i * 3 + 2] = p.color[2];
    }

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    pointsGeometryRef.current = geometry;

    // Create a circular point texture using canvas for crisp anti-aliased dots
    const canvas = document.createElement('canvas');
    canvas.width = 64;
    canvas.height = 64;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.beginPath();
      ctx.arc(32, 32, 28, 0, Math.PI * 2);
      ctx.fillStyle = '#ffffff';
      ctx.fill();
      ctx.lineWidth = 4;
      ctx.strokeStyle = '#00000033';
      ctx.stroke();
    }
    const texture = new THREE.CanvasTexture(canvas);

    const material = new THREE.PointsMaterial({
      size: 1.1,
      vertexColors: true,
      map: texture,
      transparent: true,
      alphaTest: 0.1,
      opacity: 0.92,
      sizeAttenuation: true,
    });

    const pointsMesh = new THREE.Points(geometry, material);
    scene.add(pointsMesh);
    pointsMeshRef.current = pointsMesh;
  }, [points]);

  // Update Points Position during Projection Transition
  useEffect(() => {
    const geometry = pointsGeometryRef.current;
    if (!geometry || points.length === 0) return;

    const positions = geometry.attributes.position.array as Float32Array;
    const n = points.length;

    for (let i = 0; i < n; i++) {
      const p = points[i];
      const px = (1 - projectionProgress) * p.x + projectionProgress * p.projX;
      const py = (1 - projectionProgress) * p.y + projectionProgress * p.projY;
      const pz = (1 - projectionProgress) * p.z + projectionProgress * p.projZ;

      positions[i * 3] = px;
      positions[i * 3 + 1] = py;
      positions[i * 3 + 2] = pz;
    }

    geometry.attributes.position.needsUpdate = true;
  }, [projectionProgress, points]);

  // Update PCA Projection Plane
  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene) return;

    if (pcaPlaneMeshRef.current) {
      scene.remove(pcaPlaneMeshRef.current);
      pcaPlaneMeshRef.current.geometry.dispose();
      (pcaPlaneMeshRef.current.material as THREE.Material).dispose();
      pcaPlaneMeshRef.current = null;
    }

    if (!showPCAPlane || !pca) return;

    // Plane spanned by PC1 and PC2
    const v1 = new THREE.Vector3(...pca.eigenvectors[0]);
    const v2 = new THREE.Vector3(...pca.eigenvectors[1]);
    const normal = new THREE.Vector3(...pca.eigenvectors[2]).normalize();

    const planeSize = 44;
    const planeGeo = new THREE.PlaneGeometry(planeSize, planeSize, 12, 12);

    // Align plane orientation to normal vector
    const matrix = new THREE.Matrix4();
    const up = new THREE.Vector3(0, 0, 1);
    const quat = new THREE.Quaternion().setFromUnitVectors(up, normal);
    matrix.makeRotationFromQuaternion(quat);
    matrix.setPosition(new THREE.Vector3(...pca.mean));
    planeGeo.applyMatrix4(matrix);

    const planeMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.18,
      side: THREE.DoubleSide,
      depthWrite: false,
      roughness: 0.2,
    });

    const planeMesh = new THREE.Mesh(planeGeo, planeMat);

    // Add plane wireframe border
    const edges = new THREE.EdgesGeometry(planeGeo);
    const lineMat = new THREE.LineBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.6 });
    const line = new THREE.LineSegments(edges, lineMat);
    planeMesh.add(line);

    scene.add(planeMesh);
    pcaPlaneMeshRef.current = planeMesh;
  }, [showPCAPlane, pca]);

  // Update Eigenvectors Group (3D Arrows & Labels)
  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene) return;

    if (eigenvectorsGroupRef.current) {
      scene.remove(eigenvectorsGroupRef.current);
      eigenvectorsGroupRef.current = null;
    }

    if (!showEigenvectors || !pca) return;

    const group = new THREE.Group();
    const origin = new THREE.Vector3(...pca.mean);

    // Helper to create directional arrow
    const createArrow = (
      dir: [number, number, number],
      stdDev: number,
      color: number,
      label: string,
      percent: string
    ) => {
      const direction = new THREE.Vector3(...dir).normalize();
      const length = Math.max(10, Math.min(26, stdDev * 1.8));

      // ArrowHelper
      const arrow = new THREE.ArrowHelper(direction, origin, length, color, 2.5, 1.2);
      // Both directions to show the full axis
      const negDir = direction.clone().negate();
      const negArrow = new THREE.ArrowHelper(negDir, origin, length * 0.75, color, 1.5, 0.8);
      group.add(arrow);
      group.add(negArrow);

      // 3D Canvas Sprite for Label
      const canvas = document.createElement('canvas');
      canvas.width = 256;
      canvas.height = 96;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.fillStyle = '#0f172aee';
        ctx.strokeStyle = `#${color.toString(16).padStart(6, '0')}`;
        ctx.lineWidth = 4;
        ctx.roundRect(8, 8, 240, 80, 16);
        ctx.fill();
        ctx.stroke();

        ctx.font = 'bold 30px sans-serif';
        ctx.fillStyle = '#ffffff';
        ctx.textAlign = 'center';
        ctx.fillText(label, 128, 44);

        ctx.font = '22px sans-serif';
        ctx.fillStyle = `#${color.toString(16).padStart(6, '0')}`;
        ctx.fillText(percent, 128, 72);
      }

      const texture = new THREE.CanvasTexture(canvas);
      const spriteMat = new THREE.SpriteMaterial({ map: texture, depthTest: false });
      const sprite = new THREE.Sprite(spriteMat);
      sprite.scale.set(6, 2.25, 1);
      const labelPos = origin.clone().add(direction.clone().multiplyScalar(length + 3));
      sprite.position.copy(labelPos);
      group.add(sprite);
    };

    // PC1: Cyan/Emerald (Maximum variance)
    createArrow(
      pca.eigenvectors[0],
      Math.sqrt(pca.eigenvalues[0]),
      0x10b981,
      'PC1 (Eje 1)',
      `${(pca.explainedVarianceRatio[0] * 100).toFixed(1)}% var`
    );

    // PC2: Amber/Gold (Second variance)
    createArrow(
      pca.eigenvectors[1],
      Math.sqrt(pca.eigenvalues[1]),
      0xf59e0b,
      'PC2 (Eje 2)',
      `${(pca.explainedVarianceRatio[1] * 100).toFixed(1)}% var`
    );

    // PC3: Rose/Red (Lowest variance / Orthogonal error)
    createArrow(
      pca.eigenvectors[2],
      Math.sqrt(pca.eigenvalues[2]),
      0xf43f5e,
      'PC3 (Eje 3)',
      `${(pca.explainedVarianceRatio[2] * 100).toFixed(1)}% var`
    );

    // Add centroid sphere
    const centroidGeo = new THREE.SphereGeometry(0.8, 16, 16);
    const centroidMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const centroidMesh = new THREE.Mesh(centroidGeo, centroidMat);
    centroidMesh.position.copy(origin);
    group.add(centroidMesh);

    scene.add(group);
    eigenvectorsGroupRef.current = group;
  }, [showEigenvectors, pca]);

  // Update Projection Lines (from 3D points to their projection on PCA plane)
  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene) return;

    if (projectionLinesMeshRef.current) {
      scene.remove(projectionLinesMeshRef.current);
      projectionLinesMeshRef.current.geometry.dispose();
      (projectionLinesMeshRef.current.material as THREE.Material).dispose();
      projectionLinesMeshRef.current = null;
    }

    if (!showProjectionLines || points.length === 0) return;

    // Show projection lines for every 4th point to maintain clean high-fidelity rendering without clutter
    const step = Math.max(1, Math.floor(points.length / 250));
    const samplePoints: Point3D[] = [];
    for (let i = 0; i < points.length; i += step) {
      samplePoints.push(points[i]);
    }

    const positions = new Float32Array(samplePoints.length * 6);
    for (let i = 0; i < samplePoints.length; i++) {
      const p = samplePoints[i];
      // Start: original 3D position
      positions[i * 6] = p.x;
      positions[i * 6 + 1] = p.y;
      positions[i * 6 + 2] = p.z;
      // End: projected 2D position in 3D space
      positions[i * 6 + 3] = p.projX;
      positions[i * 6 + 4] = p.projY;
      positions[i * 6 + 5] = p.projZ;
    }

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));

    const material = new THREE.LineBasicMaterial({
      color: 0x94a3b8,
      transparent: true,
      opacity: 0.35,
    });

    const lines = new THREE.LineSegments(geometry, material);
    scene.add(lines);
    projectionLinesMeshRef.current = lines;
  }, [showProjectionLines, points]);

  // Update Highlight Marker for Selected Point
  useEffect(() => {
    if (!selectedHighlightRef.current) return;
    const activeId = selectedPointId !== null ? selectedPointId : hoveredPoint ? hoveredPoint.id : null;

    if (activeId === null) {
      selectedHighlightRef.current.visible = false;
      return;
    }

    const p = points.find((pt) => pt.id === activeId);
    if (!p) {
      selectedHighlightRef.current.visible = false;
      return;
    }

    // Current interpolated position
    const px = (1 - projectionProgress) * p.x + projectionProgress * p.projX;
    const py = (1 - projectionProgress) * p.y + projectionProgress * p.projY;
    const pz = (1 - projectionProgress) * p.z + projectionProgress * p.projZ;

    selectedHighlightRef.current.position.set(px, py, pz);
    selectedHighlightRef.current.visible = true;
  }, [selectedPointId, hoveredPoint, points, projectionProgress]);

  // Apply Camera Preset when requested
  useEffect(() => {
    if (!cameraPresetTrigger || !cameraRef.current || !controlsRef.current) return;
    const { preset } = cameraPresetTrigger;
    const camera = cameraRef.current;
    const controls = controlsRef.current;

    controls.target.set(pca.mean[0], pca.mean[1], pca.mean[2]);

    if (preset === 'default') {
      camera.position.set(30, 24, 38);
    } else if (preset === 'top') {
      // Top down along Y axis
      camera.position.set(pca.mean[0], 55, pca.mean[2]);
    } else if (preset === 'side') {
      // Side view showing roll height
      camera.position.set(50, pca.mean[1], pca.mean[2]);
    } else if (preset === 'cross_section') {
      // Looking directly down the spiral axis
      camera.position.set(pca.mean[0], pca.mean[1], 55);
    } else if (preset === 'pca_plane') {
      // Perpendicular to the PCA 2D plane (looking along PC3 normal)
      const normal = new THREE.Vector3(...pca.eigenvectors[2]).normalize();
      const eyePos = new THREE.Vector3(...pca.mean).add(normal.multiplyScalar(46));
      camera.position.copy(eyePos);
    }

    camera.lookAt(controls.target);
    controls.update();
  }, [cameraPresetTrigger, pca]);

  // Pointer Interaction (Hover & Click Raycasting)
  const handlePointerMove = useCallback(
    (e: React.PointerEvent<HTMLDivElement>) => {
      const container = containerRef.current;
      const camera = cameraRef.current;
      const pointsMesh = pointsMeshRef.current;
      if (!container || !camera || !pointsMesh) return;

      const rect = container.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      mouseRef.current.set(x, y);
      raycasterRef.current.setFromCamera(mouseRef.current, camera);
      raycasterRef.current.params.Points = { threshold: 1.2 };

      const intersects = raycasterRef.current.intersectObject(pointsMesh);
      if (intersects.length > 0 && intersects[0].index !== undefined) {
        const pointIdx = intersects[0].index;
        if (pointIdx < points.length) {
          hoveredIdRef.current = pointIdx;
          setHoveredPoint(points[pointIdx]);
          return;
        }
      }

      if (hoveredIdRef.current !== null) {
        hoveredIdRef.current = null;
        setHoveredPoint(null);
      }
    },
    [points]
  );

  const handleClick = useCallback(() => {
    if (hoveredPoint) {
      onSelectPoint(selectedPointId === hoveredPoint.id ? null : hoveredPoint.id);
    } else {
      onSelectPoint(null);
    }
  }, [hoveredPoint, selectedPointId, onSelectPoint]);

  return (
    <div className="relative w-full h-full select-none overflow-hidden rounded-xl border border-slate-800 bg-slate-950">
      {/* 3D WebGL Canvas Container */}
      <div
        ref={containerRef}
        className="w-full h-full cursor-grab active:cursor-grabbing"
        onPointerMove={handlePointerMove}
        onClick={handleClick}
      />

      {/* Floating Canvas Badges and Quick View Controls */}
      <div className="absolute top-3 left-3 flex flex-wrap items-center gap-2 pointer-events-none">
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-900/85 backdrop-blur-md border border-slate-700/60 text-xs font-semibold text-slate-200 shadow-md">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>Vista 3D Interactiva</span>
        </div>

        <div className="px-2.5 py-1 rounded-md bg-slate-900/85 backdrop-blur-md border border-slate-700/60 text-xs text-slate-300 shadow-md">
          {projectionProgress === 0 && 'Estado: Espacio Original 3D'}
          {projectionProgress > 0 && projectionProgress < 1 && `Colapso: ${(projectionProgress * 100).toFixed(0)}% hacia Plano PCA`}
          {projectionProgress === 1 && 'Estado: Proyectado 100% en Subespacio 2D'}
        </div>
      </div>

      {/* Camera Controls Bar */}
      <div className="absolute top-3 right-3 flex items-center gap-1.5 bg-slate-900/90 backdrop-blur-md border border-slate-700/70 p-1 rounded-lg shadow-lg">
        <button
          id="btn-toggle-auto-rotate"
          type="button"
          onClick={() => setIsRotatingAuto(!isRotatingAuto)}
          title={isRotatingAuto ? 'Pausar auto-rotación' : 'Auto-rotar cámara'}
          className={`p-1.5 rounded-md text-xs transition-colors ${
            isRotatingAuto ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
          }`}
        >
          <RotateCcw className={`w-3.5 h-3.5 ${isRotatingAuto ? 'animate-spin' : ''}`} />
        </button>
        <button
          id="btn-reset-camera"
          type="button"
          onClick={() => {
            if (cameraRef.current && controlsRef.current) {
              cameraRef.current.position.set(30, 24, 38);
              controlsRef.current.target.set(pca.mean[0], pca.mean[1], pca.mean[2]);
              controlsRef.current.update();
            }
          }}
          title="Restablecer posición de cámara"
          className="p-1.5 rounded-md text-xs text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
        >
          <Compass className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Point Inspector Overlay */}
      {(hoveredPoint || (selectedPointId !== null && points[selectedPointId])) && (
        <div className="absolute bottom-3 left-3 bg-slate-900/95 backdrop-blur-md border border-slate-700/80 rounded-lg p-3 text-xs shadow-xl max-w-xs pointer-events-none transition-all">
          {(() => {
            const p = hoveredPoint || points[selectedPointId!];
            return (
              <div className="space-y-1.5">
                <div className="flex items-center justify-between gap-2 border-b border-slate-800 pb-1.5">
                  <span className="font-semibold text-slate-200 flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full inline-block" style={{ backgroundColor: p.hexColor }} />
                    Punto #{p.id}
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    t = {p.t.toFixed(2)} rad
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-x-3 gap-y-1 font-mono text-[11px]">
                  <div>
                    <span className="text-slate-400 text-[10px] block">3D Original:</span>
                    <span className="text-slate-200">
                      ({p.x.toFixed(1)}, {p.y.toFixed(1)}, {p.z.toFixed(1)})
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[10px] block">Proyección PCA (2D):</span>
                    <span className="text-emerald-400">
                      PC1: {p.pc1.toFixed(1)}, PC2: {p.pc2.toFixed(1)}
                    </span>
                  </div>
                </div>
                <div className="text-[10px] text-slate-400 pt-0.5 border-t border-slate-800/80">
                  <span>Distancia residual ortogonal a PC3: </span>
                  <span className="text-rose-400 font-mono font-medium">{Math.abs(p.pc3).toFixed(2)}</span>
                </div>
              </div>
            );
          })()}
        </div>
      )}

      {/* Quick Legend in bottom right */}
      <div className="absolute bottom-3 right-3 hidden sm:flex items-center gap-2 bg-slate-900/85 backdrop-blur-md border border-slate-800 px-2.5 py-1.5 rounded-lg text-[11px] text-slate-400 pointer-events-none">
        <span className="text-slate-500">Arrastra para rotar • Rueda para zoom • Clic derecho para desplazar</span>
      </div>
    </div>
  );
}
