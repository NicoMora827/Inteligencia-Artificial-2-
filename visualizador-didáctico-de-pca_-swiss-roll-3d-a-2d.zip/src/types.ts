export interface Point3D {
  id: number;
  x: number;
  y: number;
  z: number;
  t: number; // parameter along the spiral [tMin, tMax]
  color: [number, number, number]; // RGB 0-1
  hexColor: string;
  // PCA projections
  pc1: number;
  pc2: number;
  pc3: number;
  // Reconstructed 3D position on PCA plane
  projX: number;
  projY: number;
  projZ: number;
  // Ideal manifold unrolled coordinates (arc length, width)
  unrolledX: number;
  unrolledY: number;
}

export interface PCAResult {
  mean: [number, number, number];
  covarianceMatrix: number[][]; // 3x3
  eigenvalues: [number, number, number];
  eigenvectors: [number, number, number][]; // 3 vectors of length 3: [v1, v2, v3]
  explainedVarianceRatio: [number, number, number];
  totalVariance: number;
}

export interface SwissRollConfig {
  numPoints: number;
  noise: number;
  turns: number; // e.g. 1.5 to 3.0
  height: number; // width along Y axis
  speed: number;
}

export type ViewMode = 'pca' | 'unrolled' | 'comparison';

export type CameraPreset = 'default' | 'top' | 'side' | 'pca_plane' | 'cross_section';

export interface GuideStep {
  id: number;
  title: string;
  subtitle: string;
  explanation: string;
  formula?: string;
  intuition: string;
  cameraPreset?: CameraPreset;
  projectionProgress?: number;
  showPCAPlane?: boolean;
  showEigenvectors?: boolean;
  showProjectionLines?: boolean;
  targetViewMode?: ViewMode;
}
