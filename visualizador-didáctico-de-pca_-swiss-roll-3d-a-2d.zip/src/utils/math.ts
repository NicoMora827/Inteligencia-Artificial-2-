import { Point3D, PCAResult, SwissRollConfig } from '../types';

// Turbo-like continuous colormap for scientific & intuitive visualization
export function turboColormap(t: number): [number, number, number] {
  // Clamp t to [0, 1]
  const val = Math.max(0, Math.min(1, t));
  
  // High quality 5-polynomial approximation for smooth gradient
  const r = Math.sin(val * Math.PI * 1.5 - 0.2) * 0.5 + 0.5;
  const g = Math.sin(val * Math.PI * 2.0 - 0.5) * 0.5 + 0.5;
  const b = Math.cos(val * Math.PI * 1.5) * 0.5 + 0.5;

  // Enhance vibrancy
  const rVibrant = Math.min(1, Math.max(0, 1.2 * r - 0.1 * g));
  const gVibrant = Math.min(1, Math.max(0, 1.1 * g));
  const bVibrant = Math.min(1, Math.max(0, 1.3 * b));

  return [rVibrant, gVibrant, bVibrant];
}

// Convert RGB [0-1] to Hex string
export function rgbToHex(r: number, g: number, b: number): string {
  const toHex = (n: number) => {
    const hex = Math.round(Math.max(0, Math.min(1, n)) * 255).toString(16);
    return hex.length === 1 ? '0' + hex : hex;
  };
  return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
}

// Analytical arc length of Archimedean spiral r = t: integral of sqrt(1 + t^2) dt
export function spiralArcLength(t: number): number {
  return 0.5 * (t * Math.sqrt(1 + t * t) + Math.log(t + Math.sqrt(1 + t * t)));
}

// Pseudo-random Gaussian using Box-Muller transform
function randomGaussian(): number {
  let u = 0;
  let v = 0;
  while (u === 0) u = Math.random();
  while (v === 0) v = Math.random();
  return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
}

// Generate Swiss Roll 3D points
export function generateSwissRoll(config: SwissRollConfig): { points: Point3D[]; pca: PCAResult } {
  const { numPoints, noise, turns, height } = config;
  const tMin = 1.5 * Math.PI;
  const tMax = tMin + turns * 2.0 * Math.PI;
  const arcMin = spiralArcLength(tMin);
  const arcMax = spiralArcLength(tMax);
  const totalArc = arcMax - arcMin;

  const rawPoints: { x: number; y: number; z: number; t: number; unrolledX: number; unrolledY: number; color: [number, number, number]; hexColor: string }[] = [];

  for (let i = 0; i < numPoints; i++) {
    // Generate t with slight non-uniformity or uniform distribution
    const tNorm = Math.random();
    // Using sqrt to distribute points more evenly across the spiral surface area
    const t = Math.sqrt(tNorm * (tMax * tMax - tMin * tMin) + tMin * tMin);
    
    // Width along Y axis
    const yVal = (Math.random() - 0.5) * height;

    // Spatial coordinates
    const xVal = t * Math.cos(t) + (noise > 0 ? randomGaussian() * noise : 0);
    const zVal = t * Math.sin(t) + (noise > 0 ? randomGaussian() * noise : 0);
    const yPerturbed = yVal + (noise > 0 ? randomGaussian() * noise * 0.5 : 0);

    // Color based on position along the spiral
    const colorParam = (t - tMin) / (tMax - tMin);
    const color = turboColormap(colorParam);
    const hexColor = rgbToHex(color[0], color[1], color[2]);

    // Unrolled manifold coordinates (arc length, width)
    const arc = spiralArcLength(t);
    const unrolledX = ((arc - arcMin) / totalArc - 0.5) * 30;
    const unrolledY = yVal;

    rawPoints.push({
      x: xVal,
      y: yPerturbed,
      z: zVal,
      t,
      unrolledX,
      unrolledY,
      color,
      hexColor,
    });
  }

  // Compute PCA
  const pca = computePCA(rawPoints.map(p => [p.x, p.y, p.z]));

  // Project points onto PCA coordinates and calculate 3D projection plane coordinates
  const points: Point3D[] = rawPoints.map((p, idx) => {
    const centered = [
      p.x - pca.mean[0],
      p.y - pca.mean[1],
      p.z - pca.mean[2],
    ];

    // Dot product with eigenvectors
    const pc1 = centered[0] * pca.eigenvectors[0][0] + centered[1] * pca.eigenvectors[0][1] + centered[2] * pca.eigenvectors[0][2];
    const pc2 = centered[0] * pca.eigenvectors[1][0] + centered[1] * pca.eigenvectors[1][1] + centered[2] * pca.eigenvectors[1][2];
    const pc3 = centered[0] * pca.eigenvectors[2][0] + centered[1] * pca.eigenvectors[2][1] + centered[2] * pca.eigenvectors[2][2];

    // Reconstruct 3D position on the 2D subspace defined by PC1 and PC2
    const projX = pca.mean[0] + pc1 * pca.eigenvectors[0][0] + pc2 * pca.eigenvectors[1][0];
    const projY = pca.mean[1] + pc1 * pca.eigenvectors[0][1] + pc2 * pca.eigenvectors[1][1];
    const projZ = pca.mean[2] + pc1 * pca.eigenvectors[0][2] + pc2 * pca.eigenvectors[1][2];

    return {
      id: idx,
      x: p.x,
      y: p.y,
      z: p.z,
      t: p.t,
      color: p.color,
      hexColor: p.hexColor,
      pc1,
      pc2,
      pc3,
      projX,
      projY,
      projZ,
      unrolledX: p.unrolledX,
      unrolledY: p.unrolledY,
    };
  });

  return { points, pca };
}

// Compute real PCA using Jacobi eigenvalue algorithm for 3x3 symmetric covariance matrix
export function computePCA(data: number[][]): PCAResult {
  const n = data.length;
  if (n === 0) {
    return {
      mean: [0, 0, 0],
      covarianceMatrix: [[1, 0, 0], [0, 1, 0], [0, 0, 1]],
      eigenvalues: [1, 0, 0],
      eigenvectors: [[1, 0, 0], [0, 1, 0], [0, 0, 1]],
      explainedVarianceRatio: [1, 0, 0],
      totalVariance: 1,
    };
  }

  // 1. Mean calculation
  const mean: [number, number, number] = [0, 0, 0];
  for (let i = 0; i < n; i++) {
    mean[0] += data[i][0];
    mean[1] += data[i][1];
    mean[2] += data[i][2];
  }
  mean[0] /= n;
  mean[1] /= n;
  mean[2] /= n;

  // 2. Covariance matrix (3x3)
  const cov: number[][] = [
    [0, 0, 0],
    [0, 0, 0],
    [0, 0, 0],
  ];

  for (let i = 0; i < n; i++) {
    const dx = data[i][0] - mean[0];
    const dy = data[i][1] - mean[1];
    const dz = data[i][2] - mean[2];

    cov[0][0] += dx * dx;
    cov[0][1] += dx * dy;
    cov[0][2] += dx * dz;

    cov[1][0] += dy * dx;
    cov[1][1] += dy * dy;
    cov[1][2] += dy * dz;

    cov[2][0] += dz * dx;
    cov[2][1] += dz * dy;
    cov[2][2] += dz * dz;
  }

  const factor = n > 1 ? 1 / (n - 1) : 1;
  for (let r = 0; r < 3; r++) {
    for (let c = 0; c < 3; c++) {
      cov[r][c] *= factor;
    }
  }

  // 3. Jacobi Eigensolver for 3x3 symmetric matrix
  const { eigenvalues: rawEvals, eigenvectors: rawEvecs } = jacobiEigensolver3x3(cov);

  // 4. Sort eigenvalues in descending order and align eigenvectors
  const indices = [0, 1, 2].sort((a, b) => rawEvals[b] - rawEvals[a]);
  const eigenvalues: [number, number, number] = [
    rawEvals[indices[0]],
    rawEvals[indices[1]],
    rawEvals[indices[2]],
  ];

  const eigenvectors: [number, number, number][] = [
    rawEvecs[indices[0]],
    rawEvecs[indices[1]],
    rawEvecs[indices[2]],
  ];

  // 5. Explained variance ratio
  const totalVariance = Math.max(1e-12, eigenvalues[0] + eigenvalues[1] + eigenvalues[2]);
  const explainedVarianceRatio: [number, number, number] = [
    eigenvalues[0] / totalVariance,
    eigenvalues[1] / totalVariance,
    eigenvalues[2] / totalVariance,
  ];

  return {
    mean,
    covarianceMatrix: cov,
    eigenvalues,
    eigenvectors,
    explainedVarianceRatio,
    totalVariance,
  };
}

// Classical Jacobi algorithm for 3x3 symmetric matrix
function jacobiEigensolver3x3(matrix: number[][]): {
  eigenvalues: [number, number, number];
  eigenvectors: [number, number, number][];
} {
  // Deep clone matrix
  const A: number[][] = [
    [matrix[0][0], matrix[0][1], matrix[0][2]],
    [matrix[1][0], matrix[1][1], matrix[1][2]],
    [matrix[2][0], matrix[2][1], matrix[2][2]],
  ];

  // Initialize eigenvectors as identity matrix
  const V: number[][] = [
    [1, 0, 0],
    [0, 1, 0],
    [0, 0, 1],
  ];

  const maxIterations = 50;
  const eps = 1e-10;

  for (let iter = 0; iter < maxIterations; iter++) {
    // Find largest off-diagonal element
    let p = 0;
    let q = 1;
    let maxOff = Math.abs(A[0][1]);

    if (Math.abs(A[0][2]) > maxOff) {
      p = 0;
      q = 2;
      maxOff = Math.abs(A[0][2]);
    }
    if (Math.abs(A[1][2]) > maxOff) {
      p = 1;
      q = 2;
      maxOff = Math.abs(A[1][2]);
    }

    if (maxOff < eps) {
      break;
    }

    // Compute Jacobi rotation
    const app = A[p][p];
    const aqq = A[q][q];
    const apq = A[p][q];

    const theta = 0.5 * Math.atan2(2 * apq, aqq - app);
    const c = Math.cos(theta);
    const s = Math.sin(theta);

    // Apply rotation to A
    const newApp = c * c * app - 2 * s * c * apq + s * s * aqq;
    const newAqq = s * s * app + 2 * s * c * apq + c * c * aqq;

    A[p][p] = newApp;
    A[q][q] = newAqq;
    A[p][q] = 0;
    A[q][p] = 0;

    const r = 3 - p - q; // the third index
    const apr = A[p][r];
    const aqr = A[q][r];

    A[p][r] = c * apr - s * aqr;
    A[r][p] = A[p][r];
    A[q][r] = s * apr + c * aqr;
    A[r][q] = A[q][r];

    // Accumulate transformation in V
    for (let i = 0; i < 3; i++) {
      const vip = V[i][p];
      const viq = V[i][q];
      V[i][p] = c * vip - s * viq;
      V[i][q] = s * vip + c * viq;
    }
  }

  // Extract eigenvalues from diagonal of A
  const eigenvalues: [number, number, number] = [A[0][0], A[1][1], A[2][2]];

  // Extract columns of V as eigenvectors
  const v1: [number, number, number] = [V[0][0], V[1][0], V[2][0]];
  const v2: [number, number, number] = [V[0][1], V[1][1], V[2][1]];
  const v3: [number, number, number] = [V[0][2], V[1][2], V[2][2]];

  return {
    eigenvalues,
    eigenvectors: [v1, v2, v3],
  };
}
